// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store/index'
import md5 from 'js-md5';
import Axios from './assets/js/axios.js';
import axios from 'axios'
import { imgUrl } from './assets/js/http.js';
import httpUrl from './assets/js/api.js';
import Mint from 'mint-ui'
// import { Radio } from 'vux'
import VueLazyload from 'vue-lazyload' //引入这个懒加载插件
import 'mint-ui/lib/style.css'
Vue.config.productionTip = false
Vue.prototype.$http = Axios;
Vue.prototype.imgBaseUrl = imgUrl;
Vue.prototype.apiJSON = httpUrl;
Vue.use(Mint)
Vue.prototype.apiCentet = 'https://center.mhsapp.com/'
// Vue.prototype.$http = axios;
// Vue.component('radio', Radio)
Vue.use(VueLazyload, {
	error: require('../static/img/login_03.png'),
	loading: require('../static/img/login_03.png'),
	preLoad: 1,
	attempt: 1
})
Vue.prototype.axios = axios
Vue.prototype.$md5 = md5;
import { Toast } from 'mint-ui'
Vue.prototype.global = {
		deviceMode: 2,
		appVersion: '2.8.8',
		appType: 1,
		userId: localStorage.uid
	},
	new Vue({
		el: '#app',
		router,
		store: store,
		template: '<App/>',
		components: {
			App
		}
	})

import Vue from 'vue'
import Router from 'vue-router'

// 首页
import Home from '@/pages/indexPage/home'
import ProductDetails from '@/pages/indexPage/productDetails'
import IconDetails from '@/pages/indexPage/IconDetails'

import SearchPage from '@/pages/indexPage/searchPage'
import Category from '@/pages/Category/category'
import CategorytDetails from '@/pages/Category/CategoryDetails'
import Evaluate from '@/pages/indexPage/evaluate'

// 购物车
import Cart from '@/pages/cartPage/cart'
import Payment from '@/pages/cartPage/payment'
import NoIdPayment from '@/pages/cartPage/noIdPayment'
import PaymentCompleted from '@/pages/cartPage/paymentCompleted'

// 茶圈子
import TcHome from '@/pages/teaCommunity/tcHome'
// import TcContent from '@/pages/teaCommunity/tcContent'
import TeaLife from '@/pages/teaCommunity/teaLife'
import Post from '@/pages/teaCommunity/post'
import MsgContent from '@/pages/teaCommunity/msgContent'
import Msgs from '@/pages/teaCommunity/msgs'

// 活动页
// import OnSale from '@/pages/activities/onSale'
import CBimg from '@/pages/activities/CBimg'
import Promotion from '@/pages/activities/promotion'
import Active815 from '@/pages/activities/Active815'

//登录注册
import Register from '@/pages/Login&Register/register'
import Login from '@/pages/Login&Register/login'
import MsgLogin from '@/pages/Login&Register/msgLogin'
import ResetPassword from '@/pages/Login&Register/resetPassword'

import MyHome from '@/pages/MyHome/MyHome'
// 个人中心
import MyInfo from '@/pages/mine/myInfo'
import MySet from '@/pages/mine/mySet'  //我的资料
import MyName from '@/pages/mine/MyName'  //实名认证
import MyTheSetup from '@/pages/SetupThe/myTheSetup'  //设置列表
import MyPassword from '@/pages/SetupThe/myPassword'  //密码管理
import MyPasswordEdit from '@/pages/SetupThe/myPasswordEdit'  //密码管理
import MyPasswordNew from '@/pages/SetupThe/myPasswordNew'  //新密码
import MyAboutUs from '@/pages/SetupThe/myAboutUs'  //关于我们


import MyCB from '@/pages/mine/myCB'
import MyOrder from '@/pages/mine/myOrder'
import MyCollection from '@/pages/mine/myCollection'
import Coupon from '@/pages/mine/coupon'
import HelpCenter from '@/pages/mine/HelpCenter'
import MyAddress from '@/pages/mine/myAddress'
import EditAddress from '@/pages/mine/editAddress'
import AddressEidt from '@/pages/mine/AddressEidt'
import Address from '@/pages/mine/Address'
import AddressCity from '@/pages/mine/AddressCity'
import AddressCounty from '@/pages/mine/AddressCounty'

import CommentsBox from '@/pages/mine/commentsBox'
import Preferences from '@/pages/mine/preferences'
import OrderNo from '@/pages/mine/OrderNo'

import Logistics from '@/pages/mine/logistics'

// 商城
import CBmall from '@/pages/CBmall/CBmall'
import CBmall1 from '@/pages/CBmall/CBmall1'
// import Mall from '@/pages/CBmall/mall'


//商家
import Seller from '@/pages/Seller/sellerHome'

//订单详情
import OrderDetails from '@/pages/Order/OrderDetails'  //订单详情
import Arefund from '@/pages/Order/Arefund'   //申请退款
import OrdersTrack from '@/pages/Order/OrdersTrack'   //订单轨迹

//我要推荐
import Myrecommend from '@/pages/Myrecommend/Myrecommend'   //app推荐用户
import MyrecommendMerchant from '@/pages/Myrecommend/MyrecommendMerchant'   //app推荐用户
import Myfans from '@/pages/Myrecommend/Myfans'   //我的粉丝



import MyTopromote from '@/pages/Myrecommend/MyTopromote'   //我要推广
//消息
import MessageHome from '@/pages/message/MessageHome'  //消息模块
import OrderMessage from '@/pages/message/OrderMessage'  //订单消息
import IntegralMessage from '@/pages/message/IntegralMessage'  //积分消息
import SystemMessage from '@/pages/message/SystemMessage'  //系统消息
// 入驻申请
import Apply from '@/pages/settled/apply'

//我的钱包
import MyWalletHome from '@/pages/MyWallet/MyWalletHome'  //钱包列表
import MyWalletDetails from '@/pages/MyWallet/MyWalletDetails'  //钱包明细

// 客服中心
import CustomerHome from '@/pages/MyCustomer/CustomerHome'  //客服中心
import helpCenterAccount from '@/pages/MyCustomer/helpCenterAccount'  //账号中心
import helpCenterPromote from '@/pages/MyCustomer/helpCenterPromote'  //账号中心
import helpCenterPay from '@/pages/MyCustomer/helpCenterPay'  //支付中心
import helpCenterVersion from '@/pages/MyCustomer/helpCenterVersion'  //版本中心
import helpCenterContact from '@/pages/MyCustomer/helpCenterContact'  //联系中心
//相关协议
import AgreementHome from '@/pages/MyAgreement/AgreementHome'  //协议列表

//积分转赠
import TransferredHome from '@/pages/Transferred/TransferredHome'  //积分转让
import TransferredDetails from '@/pages/Transferred/TransferredDetails'  //积分转让
import TransferredDetailsSell from '@/pages/Transferred/TransferredDetailsSell'  //积分转让
import TransferredSuccess from '@/pages/Transferred/TransferredSuccess'  //转让成功





Vue.use(Router)

export default new Router({
	mode: 'hash',
	hashbang: false,
	// base: '/vue/',
	routes: [
		// 首页
		{
			path: '/',
			component: Home
		}, {
			path: '/Category',
			component: Category
		}, {
			path: '/SearchPage',
			component: SearchPage
		},
		{
			path: '/ProductDetails/:productID',
			component: ProductDetails
		},
    //我的钱包
    {
      path: '/MyWalletHome',
      component: MyWalletHome
    },
    {
      path: '/MyWalletDetails/:WalleID',
      component: MyWalletDetails
    },
    //客服中心

    {
      path: '/CustomerHome',
      component: CustomerHome
    },
    {
      path: '/helpCenterAccount',    //账号中心
      component: helpCenterAccount
    },
    {
      path: '/helpCenterPromote',    //推广中心
      component: helpCenterPromote
    },
    {
      path: '/helpCenterPay',    //支付中心
      component: helpCenterPay
    },

    {
      path: '/helpCenterVersion',    //版本中心
      component: helpCenterVersion
    },
    {
      path: '/helpCenterContact',    //联系中心
      component: helpCenterContact
    },


//相关协议

    {
      path: '/AgreementHome',    //协议列表
      component: AgreementHome
    },
//我要推荐
    {
      path: '/Myrecommend',
      component: Myrecommend
    },
    {
      path: '/MyTopromote',
      component: MyTopromote
    },
    {
      path: '/MyrecommendMerchant',
      component: MyrecommendMerchant
    },
    {
      path: '/Myfans',
      component: Myfans
    },

//积分转赠
    {
      path: '/TransferredHome',
      component: TransferredHome
    },
    {
      path: '/TransferredDetails',
      component: TransferredDetails
    },
    {
      path: '/TransferredDetailsSell',
      component: TransferredDetailsSell
    },
    {
      path: '/TransferredSuccess',
      component: TransferredSuccess
    },

//消息
    {
      path: '/OrderMessage/:MessageID',
      component: OrderMessage
    },
    {
      path: '/IntegralMessage/:MessageID',
      component: IntegralMessage
    },
    {
      path: '/SystemMessage/:MessageID',
      component: SystemMessage
    },
		{
			path: '/IconDetails',
			name: 'IconDetails',
			component: IconDetails
		},

		{
			path: '/Evaluate/:orderId',
			component: Evaluate
		},
    //商家
    {
      path: '/Seller/:sellerId',
      component: Seller
    },
  //消息
    {
      path: '/MessageHome',
      component: MessageHome
    },

		//分类详情
		{
			path: '/CategorytDetails',
			component: CategorytDetails
		},
		// 购物车
		{
			path: '/Cart',
			component: Cart
		}, {
			path: '/Payment',
			component: Payment
		}, {
			path: '/NoIdPayment',
			component: NoIdPayment //填写资料
		}, {
			path: '/PaymentCompleted',
			component: PaymentCompleted
		},
		// 茶圈子
		{
			path: '/TcHome',
			component: TcHome
		}, {
			path: '/TeaLife/:themeId',
			component: TeaLife
		},
		 {
		  path: '/OrderDetails/:productID',
       name:'OrderDetails',
		  component: OrderDetails
		},
    {
      path: '/Arefund/:productID',
      name:'Arefund',
      component: Arefund
    },
    {
      path: '/OrdersTrack',
      name:'OrdersTrack',
      component: OrdersTrack
    },


		{
			path: '/MsgContent/:typeId',
			component: MsgContent
		}, {
			path: '/Msgs',
			component: Msgs
		},
		// 活动页
		// {
		//   path: '/onSale',
		//   component: OnSale
		// }
		, {
			path: '/Promotion/:id',
			component: Promotion
		}, {
			path: '/CBimg',
			component: CBimg
		},
		{
			path: '/Active815',
			component: Active815
		},
		//登录注册
		{
			path: '/Login',
			component: Login
		}, {
			path: '/MsgLogin',
			component: MsgLogin
		}, {
			path: '/Register',
			component: Register
		}, {
			path: '/ResetPassword',
			component: ResetPassword
		},
		// 个人中心
		{
			path: '/MyInfo',
			component: MyInfo
		},
		//我的首页MHS
		{
			path: '/MyHome',
			component: MyHome
		},
		{
			path: '/MySet',
			component: MySet
		},
    {
      path: '/MyName',
      component: MyName
    },
    {
      path: '/MyTheSetup',
      component: MyTheSetup
    },
    {
      path: '/MyPassword',
      component: MyPassword
    },
    {
      path: '/MyPasswordEdit',
      component: MyPasswordEdit
    },
    {
      path: '/MyPasswordNew',
      component: MyPasswordNew
    },
    {
      path: '/MyAboutUs',
      component: MyAboutUs
    },

    {
			path: '/MyCB',
			component: MyCB
		}, {
			path: '/MyOrder/:title/:tabNum',
			component: MyOrder
		}, {
			path: '/MyCollection',
			component: MyCollection
		}, {
			path: '/MyAddress',
			component: MyAddress
		}, {
			path: '/HelpCenter',
			component: HelpCenter
		},
		{
			path: '/EditAddress/:aId',
			component: EditAddress
		},
    {
      path: '/AddressEidt',
      component: AddressEidt,
      name:'AddressEidt',
    },

		{
			path: '/Address',
			component: Address
		},
		{
			path: '/AddressCity/:dataObj',
			name: 'AddressCity',
			component: AddressCity
		},
		{
			path: '/AddressCounty/:dataObj',
			name: 'AddressCounty',
			component: AddressCounty
		},

		{
			path: '/CommentsBox',
			component: CommentsBox
		}, {
			path: '/Coupon',
			component: Coupon
		}, {
			path: '/Preferences/:title/:id',
			component: Preferences
		},
		{
			path: '/OrderNo',
			component: OrderNo
		},

		{
			path: '/Logistics',
			component: Logistics
		},
		// 商城
		{
			path: '/CBmall',
			component: CBmall
		}, {
			path: '/CBmall1',
			component: CBmall1
		},
		// {
		//   path: '/Mall',
		//   component: Mall
		// },
		// 入驻申请
		{
			path: '/Apply',
			component: Apply
		}
	]
})

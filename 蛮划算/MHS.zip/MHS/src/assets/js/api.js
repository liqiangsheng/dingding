import baseUrl from './http.js';
var rootUrl = baseUrl.api;
var apiUrl = {
	//首页登录URL
	  "index_info": rootUrl+"/usLogin/1.0/", //首页信息
	// "index_login_out": rootUrl+"/logoutSuccess", //首页退出
    "index_usModifyPwd": rootUrl+"/usModifyPwd/1.0/", //找回密码
    "index_smsSend": rootUrl+"/smsSend/1.0/", //验证码
    "index_usRegist": rootUrl+"/usRegist/1.0/", //注册
    "index_atsTotalAccount": rootUrl+"/atsTotalAccount/1.0/", //我的钱包

//搜索
  "index_msHot": rootUrl+"/msHot/1.0/", //热门搜索
  "index_gsSearchWithOrdering": rootUrl+"/gsSearchWithOrdering/1.0/", //热门商品
  "index_msSearchB2CStore": rootUrl+"/msSearchB2CStore/1.0/", //搜索商家

//消息列表
  "index_ssQueryMessageTypeList": rootUrl+"/ssQueryMessageTypeList/1.0/", //消息列表
  "index_ssQueryMessageList": rootUrl+"/ssQueryMessageList/1.0/", //消息明细

//我的粉丝

"my_usFansList": rootUrl+"/usFansList/1.0/", //我的粉丝
"my_usReferrerInfomation": rootUrl+"/usReferrerInfomation/1.0/", //我的推荐人
 "my_accountWalletDetail": rootUrl+"/accountWalletDetail/1.0/", //我的钱包
 "my_accountScoreDetail": rootUrl+"/accountScoreDetail/1.0/", //钱包明细

//积分转赠
  "index_makeTransfer": rootUrl+"/makeTransfer/1.0/", //钱包明细
  "index_accountTotal": rootUrl+"/accountTotal/1.0/", //积分
  "index_integralTransfer": rootUrl+"/integralTransfer/1.0/", //普通转账确认
  "index_serllerTransfer": rootUrl+"/serllerTransfer/1.0/", //商家结算



//字典

    "index_bmsGetDictVersion": rootUrl+"/bmsGetDictVersion/1.0/", //字典版本号
  "index_bmsGetDicts": rootUrl+"/bmsGetDicts/1.1/", //字典


  //首页banner
  "index_ssQueryBannerList": rootUrl+"/indexActivity/1.0/", //首页信息



  //icnon入口
  "index_gsSearchWithOrdering": rootUrl+"/gsSearchWithOrdering/1.0/", //首页信息
  "index_Recommend": rootUrl+"/indexRecommend/1.0/", //为你推荐



//分类
    "Category_gsQueryGsCategory": rootUrl+"/gsQueryGsCategory/1.0/", //分类
    "Category_gsSearchWithOrdering": rootUrl+"/gsSearchWithOrdering/1.0/", //分类入口获取商品列表
    "usGetAddDeleteModifyAdress": rootUrl+"/usGetAddDeleteModifyAdress/1.0/",//添加地址

  //商品信息
  "Goods_gsBaseInfo": rootUrl+"/gsBaseInfo/1.0/",//商品详情轮播图
  "Goods_gsDetail": rootUrl+"/gsDetail/1.0/",//商品详情轮播图
  "Goods_addGoodsInCart": rootUrl+"/addGoodsInCart/1.0/",//商品加入购物车
  "Goods_cartGoods": rootUrl+"/cartGoods/1.0/",//获取购物车商品列表
  "Goods_orderCommit": rootUrl+"/orderCommit/1.0/",//获取购物车商品列表
  "Goods_cartCount": rootUrl+"/cartCount/1.0/",//获取购物车数量
  // "Goods_gsFavoriteGoods": rootUrl+"/gsFavoriteGoods/1.0/",//商品收藏
  "Goods_gsFavoriteGoods": rootUrl+"/gsFavoriteGoods/1.0/",//商品收藏
  "Goods_gsQueryFavoriteGoods": rootUrl+"/gsQueryFavoriteGoods/1.0/",//商品收藏列表
  "Goods_msGetFavorites": rootUrl+"/msGetFavorites/1.0/",//商家收藏列表
  "Goods_msFavoriteEdit": rootUrl+"/msFavoriteEdit/1.0/",//商家收藏



  "Goods_sellerInfo": rootUrl+"/sellerInfo/1.0/",//店铺
  "Goods_gsSearchBySellerId": rootUrl+"/gsSearchBySellerId/1.0/",//获取店铺商品


  "Goods_putGoodsIntoCart": rootUrl+"/putGoodsIntoCart/1.0/",//调整购物车中的商品数量
  "Goods_clearCart": rootUrl+"/clearCart/1.0/",//清空购物车
  "Goods_bsOrderSub": rootUrl+"/bsOrderSub/1.0/",//立即下单
  "Goods_orderSearch": rootUrl+"/bsOrderQuery/2.0/",//订单列表
   "Goods_bsOrderPay": rootUrl+"/bsOrderPay/1.0/",//支付
  "order_bsOrderInfo": rootUrl+"/bsOrderInfo/1.0/",//订单详情
  "order_bsOrderCancel": rootUrl+"/bsOrderCancel/1.0/",//取消订单
  "order_bsOrderTraceInfo": rootUrl+"/bsOrderTraceInfo/1.0/",//订单详情
  "order_bsOrderService": rootUrl+"/bsOrderService/1.0/",//申请退款
  "order_bsOrderTraceRecords": rootUrl+"/bsOrderTraceRecords/1.0/",//订单轨迹




   "order_toPay": rootUrl+"/toPay/1.0/",//立即支付







  //地址管理
  "usGetAddDeleteModifyAdress": rootUrl+"/usGetAddDeleteModifyAdress/1.0/",//地址管理
  "queryProvinces": rootUrl+"/queryProvinces/1.0/",//地址
















}
export default apiUrl;

import axios from 'axios'
import httpUrl from './http.js';
// import { Message } from 'element-ui';
import router from '../../router';
import { Toast } from 'mint-ui'

window.BASE_PATH = httpUrl.api;
//window.IMG_URL_PRE=httpUrl.imgUrl
window.IMG_URL_PRE='http://img.mhsapp.com/'
//window.IMG_URL_PRE='http://preimg.mhsapp.com/'



var headers = {
  'Content-Type': 'text/mhs-;charset=utf-8'
};
var instance = axios.create({
  baseURL: httpUrl.api,
  timeout: 50000,
  transformRequest: [function (data) {
     let ret = ''
    for (let it in data) {
        ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&'
      }
     return ret
  }],
  headers: {
    'Content-Type': 'text/mhs-;charset=utf-8',
    'auth':sessionStorage.getItem('auth')
  }
});
console.log(headers,'instance')
instance.interceptors.response.use(function (response) {
  if(response.data.code !== '000000'){
	    if(response.message!==''){
        Toast(response.data.message)
	    }
	    if(response.data.code == 'E100000' || response.data.code == 'E000015'){
	      router.push({name:'Login'});
	      sessionStorage.removeItem('mhsAuth')
	    }
		return false;
	}
  if(!sessionStorage.getItem('mhsAuth')){
      sessionStorage.setItem('mhsAuth',response.data.body.token)
      instance.defaults.headers['auth'] = sessionStorage.getItem('mhsAuth');
  }
  console.log(response.data,'reaaaa')
	return response.data.body || true;
}, function (error) {
  console.log(error,'error')
    // 对响应错误做点什么
    return Promise.reject(error);
});

export default instance

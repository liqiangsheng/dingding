<template>
  <div class="container">
    <Mheader :show='true'>
      <div slot="title">商家</div>
    </Mheader>
    <div class="home_top">
      <div class="title_seller">
        <div class="title_stockVolume">
          <div class="title_stockVolume_left">
            <img v-lazy="imgBaseUrl+sellerDataHome.headIco"/>
            <span>{{sellerDataHome.trueName}}</span>
            <div class="title_stockVolume_right">
              <span class="title_stockVolume_right"><b
                :class="{'bg-primary text-danger':isA,'bg-success text-white':!isA}" @click="doSomething()"></b></span>
            </div>
          </div>

        </div>
      </div>
      <div class="tab1">
        <div class="navbar-item" v-for="(item, index) in tab" @click="selected(index)" :key='index'
             :class="{isSelected:index == tabIndex}">{{ item.tabName }}
        </div>
      </div>
    </div>

    <div v-if="tabIndex == 0" class="productDescribe" >
      <div>
        <div class="nav_bat">
          <div style="height: 0.6rem;background: #f4f4f4;"></div>
          <nav class="nav-bar">
            <div :class="{active:isNewest}" @click="newestActive">销量</div>
            <div :class="{active:isHot}" @click="hotActive">最新</div>
            <div class="priceIcon" :class="{active:isPrice}" @click="isPriceActive">
              <b>价格</b>
            </div>
            <div :class="{active:isScreening}" @click="isScreeningActive">
              <img src="../../assets/images/seller/Grid_list@2x.png" alt="">
            </div>
          </nav>
        </div>
        <div style="margin-top: 13rem">
          <div class="forum-box" v-infinite-scroll="loadMore1" infinite-scroll-disabled="loading"
               infinite-scroll-distance="10">
            <div class="box mode">
              <div class="mode-box">

                <SellerGoodsMode v-for="(item,index) in sellerData" :key="item.index" :index="index"
                                 :path="item.goodsId"
                                 :imgUrl="item.imgUrl" :goodsName="item.goodsName" :appPrice="item.appPrice"
                                 :positiveRate="item.positiveRate" er="item.commentNumber">
                </SellerGoodsMode>
              </div>
            </div>
            <div class="loading" v-show="isLoading">
              <mt-spinner :type="3" color="#999"></mt-spinner>
              <span class="lm-margin-l-sm lm-text-grey">加载中...</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-if="tabIndex == 1">
      <div class="parameter">
        <div>
          <div class="nav_bat">
            <div style="height: 0.6rem;background: #f4f4f4;"></div>
            <nav class="nav-bar">
              <div :class="{active:isNewest}" @click="newestActive">销量</div>
              <div :class="{active:isHot}" @click="hotActive">最新</div>
              <div class="priceIcon" :class="{active:isPrice}" @click="isPriceActive">
                <b>价格</b>
              </div>
              <div :class="{active:isScreening}" @click="isScreeningActive">
                <img src="../../assets/images/seller/Grid_list@2x.png" alt="">
              </div>
            </nav>
          </div>
          <div style="margin-top: 13rem">
            <div class="forum-box" v-infinite-scroll="loadMore1" infinite-scroll-disabled="loading"
                 infinite-scroll-distance="10">
              <div class="box mode">
                <div class="mode-box">

                  <SellerGoodsMode v-for="(item,index) in sellerData" :key="item.index" :index="index"
                                   :path="item.goodsId"
                                   :imgUrl="item.imgUrl" :goodsName="item.goodsName" :appPrice="item.appPrice"
                                   :positiveRate="item.positiveRate" er="item.commentNumber">
                  </SellerGoodsMode>
                </div>
              </div>
              <div class="loading" v-show="isLoading">
                <mt-spinner :type="3" color="#999"></mt-spinner>
                <span class="lm-margin-l-sm lm-text-grey">加载中...</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
    <div v-if="tabIndex == 2">
      <div class="seller_dynamic">
        <div style="margin-top: 10.5rem">
          <div class="setHome">
            <div id="infoHomeup">
              <router-link to="/MyAddress">
                <mt-cell title="商家证件">
                  <img slot="icon" src="../../assets/images/SetupThe/dizhi@2x.png" >
                  <span><img src="../../assets/images/arrow.png" /></span>
                </mt-cell>
              </router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="more-comment" v-if="productDesc.length>0">
      <span @click="loadMore">{{moreContent}}</span>
    </div>
    <div class="more-comment" v-else>
    </div>
  </div>
</template>

<script>
  import SellerGoodsMode from './SellerGoodsMode'
  import Mheader from '../../components/Mheader'
  import {Toast} from 'mint-ui';

  export default {
    components: {
      Mheader,
      SellerGoodsMode
    },
    data() {
      return {
        BaseUrl: 'http://img.mhsapp.com/',
        sellerDataHome: "",
        isA: true,
        tabIndex: 0,
        sellerData: [],//商家的商品
        tab: [
          {tabName: "全部"},
          {tabName: "最新"},
          {tabName: "商家动态"}
        ],
        productDesc: [],//商品评论
        //评论下拉加载
        pageSize:0,
        DataList: [], //请求数据

        isNewest: true, //是否最新
        isHot: false, //是否最热
        isPrice: false,
        ordering: 'salesvolume',
        isScreening: false,
        pageIndex: 0,
        // pageSize: 20,
        isLoading: false, //是否显示加载中...
        loading: false,
        isData:true,
      }
    },
    methods: {
      sllerHome(){
        let data = {
          'body': {
            sellerId:this.$route.params.sellerId,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.Goods_sellerInfo, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            this.sellerDataHome=response.data.body
              console.log(this.sellerDataHome)
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },
      selected(i) {
        console.log(i)
        this.tabIndex = i
      },
      loadMore() {
        this.pageIndex++;
        this.getProductEstimates();
      },
      doSomething() {
        console.log(1111)
        this.isA = !this.isA
        if(this.isA==true){
          var  typeId='0'
        }else{
          var  typeId='1'
        }
        console.log(typeId,'typeId')
        let data = {
          'body': {
            sellerId: this.$route.params.sellerId,
            type: typeId,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.Goods_msFavoriteEdit, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            Toast('收藏成功')
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },
      getSeller() {
        let data = {
          'body': {
            sellerId: this.$route.params.sellerId,
            pageNum: this.pageSize,
            pageSize: 10

          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.Goods_gsSearchBySellerId, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if (response.data.code == '000000') {
            if (response.data.body.length > 0) {
              for (let i = 0; i < response.data.body.length; i++) {
                this.istemp = response.data.body
                let temp = response.data.body[i];
                this.sellerData.push(temp)
              }
              this.loading = false;
            } else {
              this.isLoading = false;
              Toast("暂无数据")
              this.isData=false
            }
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },
      loadMore1() {
        this.isLoading = true;
        this.pageSize++;
        if(this.isData==false) {
          Toast("暂无数据")
        } else {
          this.getSeller(1);
          this.isLoading = false;

        }

      },
      newestActive() {
        this.isHot = false;
        this.isNewest = true;
        this.isPrice = false;
        this.isScreening = false;
        this.pageSize = 1; //当前页码重置为1
        this.sellerData = []; //清空数据集合
        this.ordering = 'salesvolume'
        this.getSeller();
      },
      hotActive() {
        this.isNewest = false;
        this.isHot = true;
        this.isPrice = false;
        this.isScreening = false;
        this.pageSize = 1; //当前页码重置为1
        this.sellerData = []; //清空数据集合
        this.ordering = 'uptime'
        this.getSeller();
      },

      isPriceActive() {

        this.isPrice = true;
        this.isHot = false;
        this.isScreening = false;
        this.pageSize = 1; //当前页码重置为1
        this.sellerData = []; //清空数据集合
        this.ordering = 'price'
        this.getSeller();
      },
      isScreeningActive() {
        console.log('ppp')
      },


      goBack() {
        window.history.go(-1)
      },
      //获取热搜词汇
      getSearchValue() {
      },
    },
    mounted: function () {
      this.sllerHome()
      this.$nextTick(() => {
        // this.sellerDataHome = JSON.parse(sessionStorage.sellerDataHome)
        // console.log(this.sellerDataHome, '000')
         // this.getSeller()
      })
    }
  }
</script>

<style scoped>
  html{height: 100%;background: #f4f4f4}
  #infoHomeup img{width: 1rem}
  #infoHomeup span{;display:inline-block;padding-left: .4rem}
  .infoHome_text{margin-right: 1rem}
  #infoHomeup .mint-cell-wrapper{ background-size: 100% 0 !important;border-bottom: 1px solid #efefef}
  .home_top {
    position: fixed;
    width: 100%;
    top: 42px;
    z-index: 9999
  }

  .title_stockVolume {
    padding-top: 3rem;
    background: #927333;
  }

  .title_stockVolume_left {
    width: 100%;
    height: 3.6rem;
    line-height: 3rem;
    background: #927333;
    padding-left: 1rem
  }

  .title_stockVolume_left span {
    color: #fff;
    font-size: 0.65rem;
    padding-left: .4rem
  }

  .title_stockVolume_left img {
    width: 3rem;
    height: 3rem;
  }

  .title_stockVolume_right {
    float: right;
    text-align: right;
    padding-right: .6rem
  }

  .title_stockVolume b {
    display: inline-block;
    width: 24px;
    height: 24px;
    padding-right: .4rem
  }

  .title {
    font-size: 0.55rem;
    background-color: #fff;
  }

  .bg-primary {
    background-image: url("../../assets/images/productDetails/wsc1.png");
    background-size: 100% 100%
  }

  .bg-success {
    background-image: url("../../assets/images/productDetails/wsc2.png");
    background-size: 100% 100%
  }

  .tab1 {
    display: flex;
    background-color: #fff;
    border-bottom: 1px solid #eeeeee;
  }

  .tab1 > div {
    height: 1.6rem;
    line-height: 1.6rem;
    margin: 0 auto;
    text-align: center;
    width: 18.33%;
  }

  .isSelected {
    color: #dc032e !important;
    margin-bottom: 0 !important;
    border-bottom: 2px solid #dc032e !important;
  }

  .nav_bat {
    width: 100%;
    position: fixed;
    top: 34%;
  }
.nav_bat img{width: 0.8rem;margin-bottom: .5rem}
  .nav-bar {
    /*float: left;*/
    text-align: center;
    white-space: nowrap;
    overflow-x: scroll;
    overflow-y: hidden;
    display: flex;
    align-items: center;
    background-color: #fff;
    border: 1px solid #ececec;
    border-bottom: none;
  }

  .nav-bar .active {
    color: #ea002f;
    background-color: #fff;
  }

  .nav-bar > div {
    flex: 1;
    height: 1.8rem;
    line-height: 1.8rem;
  }

  .main-body {
    /* 加上这个才会有当数据充满整个屏幕，可以进行上拉加载更多的操作 */
    overflow: scroll;
  }

  .mode-list {
    background-color: #ffffff;
  }
</style>

<template>
	<div>
		<div>
			<Mheader :show='true'>
				<div slot="title">商品分类</div>
			</Mheader>
		</div>
		<div class="good">
			<div class="menu-wrapper" ref="menuWrapper">
				<ul>
					<li v-for="(item, index) in goods" class="menu-item border-1px " :class="{current:index==currentIndex1}" @click="selectMenu(index, $event)" ref="menuList">
						<span class="text">
           				 <span v-show="item.type>0" class=" icon" :class="classMap[item.type]"></span>{{item.cateName}}
						</span>
					</li>
				</ul>
			</div>
			<div style="width:0.3rem"></div>
			<div class="foods-wrapper" ref="foodWrapper">
				<ul>
					<li v-for="item in goods" class="food-list food-list-hook" ref="foodList">
						<ul>
							<li v-for="(food,index) in item.sub" class="food-item">
								<h1>
                  {{food.cateName}}
                </h1>
								<span v-for="item in food.sub" class="food-itemSapn" @click="selectFood(item,index, $event)">
                  {{item.cateName}}
                </span>
							</li>
						</ul>
					</li>
				</ul>
			</div>
			<div>
			</div>
		</div>
		<Mfooter :shopCurrent='true'></Mfooter>
	</div>
</template>
<script type="text/ecmascript-6">
	import Mfooter from '../../components/Mfooter'
	import Mheader from '../../components/Mheader'
	import BScroll from 'better-scroll';
	import data from '../../assets/js/data.json';
	const ERR_OK = 0;
	export default {
		props: {
			seller: {
				type: Object
			}
		},
		data() {
			return {
				currentIndex1: '0',
				uid: localStorage.getItem('uid'),
				goods: [],
				listHeight: [],
				scrolly: 0,
				selectedFood: {}
			};
		},
		created() {
			// this.goods = data.goods;
			this.$nextTick(() => {
				this._initScroll();
				this._calculateHeight();
			});
			this.classMap = ['decrease', 'discount', 'special', 'invoice', 'guarantee'];
		},
		mounted() {
			this.getCategory()
			this.$nextTick(() => {
				this._initScroll();
			});
		},
		computed: {
			currentIndex() {
				for(let i = 0; i < this.listHeight.length; i++) {
					let height = this.listHeight[i];
					let height2 = this.listHeight[i + 1];
					if(!height2 || (this.scrolly >= height && this.scrolly < height2)) {
						this._followScroll(i)
						return i;
					}
				}
				return 0;
			},
			selectFoods() {
				let foods = [];
				this.goods.forEach((good) => {
					good.foods.forEach((food) => {
						if(food.count) {
							foods.push(food);
						}
					});
				});
				return foods;
			}
		},
		methods: {

			getCategory() {
				let data = {
					'body': {
						typeId: 1,
						deep: 3,
					},
					'global': this.global
				}
				this.axios.post(this.apiJSON.Category_gsQueryGsCategory, JSON.stringify(data), {
					headers: {
						'content-Type': 'text/mhs-'
					}
				}).then((response) => {
					if(response.data.code == '000000') {
						this.goods = response.data.body
						// console.log(response.data.body,'goods')
					} else {
						Toast(response.data.message)
					}

				}).catch((error) => {

				});
			},

			_initScroll() {
				this.menuScroll = new BScroll(this.$refs.menuWrapper, {
					click: true
				});
				this.foodScroll = new BScroll(this.$refs.foodWrapper, {
					probeType: 3,
					click: true
				});
				this.foodScroll.on('scroll', (pos) => {
					// console.log(pos.y,'scroll')
					this.scrolly = Math.abs(Math.round(pos.y));
					// console.log(this.scrolly )
				});
			},
			_calculateHeight() {
				let foodList = this.$refs.foodWrapper.getElementsByClassName('food-list-hook');
				let height = 0;
				this.listHeight.push(height);
				for(let i = 0; i < foodList.length; i++) {
					let item = foodList[i];
					height += item.clientHeight;
					this.listHeight.push(height);
				}
			},
			_followScroll(index) {
				let menuList = this.$refs.menuList;
				let el = menuList[index];
				this.meunScroll.scrollToElement(el, 300, 0, -100);
			},
			selectMenu(index, event) {
				this.currentIndex1 = index
				if(!event._constructed) {
					// 去掉自带click事件的点击
					return;
				}
				let foodList = this.$refs.foodWrapper.getElementsByClassName('food-list-hook');
				let el = foodList[index];
				this.foodScroll.scrollToElement(el, 1300);
			},
			selectFood(item, event) {

				this.selectedFood = item;
				// this.$router.push({ path: '/CategorytDetails/' +item.cateId})
				sessionStorage.setItem("cateId", item.cateId);
				this.$router.push({
					path: '/IconDetails',
				})
				// this.$refs.food.show();
			},
			incrementTotal(target) {
				this.$refs.shopCart.drop(target);
			},
		},

		components: {
			Mfooter,
			Mheader
			//    shopCart,
			//    cartControl,
			//    food
		}
	};
</script>
<style lang="stylus" rel="stylesheet/stylus">
	@import '~style/goods.styl'
  header {
		top: 0;
		position: fixed;
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0 0.6rem;
		font-size: 0.75rem;
		height: 1.8rem;
		color: #000;
		///*background-color: #e60039;*/
	}

	.current {
		background-color: #000
	}

	.back {
		width: 1rem;
		height: 1rem;
		background-size: 100% 100%;
		/*background-image: url("../../assets/images/category/back.png");*/
	}

	.iconSach {
		width: 1rem;
		height: 1rem;
		background-size: 100% 100%;
		/*background-image: url("../../assets/images/category/search.png");*/
	}

	.margin-left {
		margin-left: 2%;
	}

	.mode-box .mode-list {
		border-radius: 0;
		/*text-align: center;*/
		font-size: 0.8rem;
		/*font-weight: 600;*/
		color: #000;
		background-size: 100% 100%;
	}

	.mode-list .cate-block {
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.4);
	}

	.cateNamespan {
		display flex;
		padding-right 1rem
	}

	.food-item h1 {
		padding: .6rem
	}

	.food-itemSapn {
		display: inline-block;
		text-align center;
		width 4rem;
		padding .4rem;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
		border-right 1px solid #f4f4f4;
		border-bottom 1px solid #f4f4f4;
		background #fff
	}
</style>

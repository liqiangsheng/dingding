<template>
	<div class="container">
		<header style="z-index: 9999000">
			<div class="back" @click="goBack">
				<img src="../../assets/images/back22.png" alt="">
			</div>
			<div class="search flex-alig-center">
				<img src="../../assets/images/home/987tea_search.png" alt="搜索">
				<input type="text" placeholder="搜索你喜欢的商品" v-model="searchName" />
			</div>
			<div class="icon" @click="searchProducts(1)">搜索</div>
		</header>
		<div>
			111

			<div class="nav_bat">
				<nav class="nav-bar">
					<div :class="{active:isNewest}" @click="newestActive">销量</div>
					<div :class="{active:isHot}" @click="hotActive">最新</div>
					<div class="priceIcon" :class="{active:isPrice}" @click="isPriceActive">
						<b>价格</b>
					</div>
					<div :class="{active:isScreening}" @click="isScreeningActive">筛选<span>▼</span>
					</div>
				</nav>
			</div>
		</div>

		<div style="margin-top: 1rem">
			<div class="forum-box" v-infinite-scroll="loadMore1" infinite-scroll-disabled="loading" infinite-scroll-distance="10">
				<div class="box mode">
					<div class="mode-box">
						<IconDetailsMode v-for="(item,index) in DataList" :key="item.index" :index="index" :path="item.goodsId" :imgUrl="item.imgUrl" :goodsName="item.goodsName" :appPrice="item.appPrice" :positiveRate="item.positiveRate" er="item.commentNumber">
						</IconDetailsMode>
					</div>
				</div>
				<div class="loading" v-show="isLoading">
					<mt-spinner :type="3" color="#999"></mt-spinner>
					<span class="lm-margin-l-sm lm-text-grey">加载中...</span>
				</div>
			</div>
		</div>
		<Mfooter :indexCurrent='true'></Mfooter>
	</div>
</template>

<script>
	import Mfooter from '../../components/Mfooter'
	import IconDetailsMode from '../../components/Mode/IconDetailsMode'
	import { Toast } from 'mint-ui'
	export default {
		components: {
			Mfooter,
			IconDetailsMode
		},
		data() {
			return {
				DataList: [], //请求数据
				targetS: {},
				Filte: {},
				isNewest: true, //是否最新
				isHot: false, //是否最热
				isPrice: false,
				ordering: 'salesvolume',
				isScreening: false,
				searchValue: [], //热搜词汇
				searchName: '', //搜索关键字
				pageIndex: 0,
				// pageSize: 20,
				isLoading: false, //是否显示加载中...
				pageSize: 0, //当前页码
				loading: false,
				cateId: '',
				productList: [], //搜索结果商品
				isSearch: false,
				recommend: [], //推荐商品
				oldSearch: '',
				uid: localStorage.getItem('uid'),
				//上下拉加载
				allLoaded: false,
				//是否自动触发上拉函数
				isAutoFill: false,
				wrapperHeight: 0,
				courrentPage: 0
			}
		},
		watch: {

		},
		created() {

		},
		mounted() {
			this.cateId = sessionStorage.getItem('cateId')

		},
		methods: {
			loadMore1() {
				this.loading = true;
				this.isLoading = true;
				this.pageSize++;
				if(this.isNewest) {
					this.getIconDetails(1);
				} else if(this.isHot) {
					// this.getLatestTopic(3);
				} else {
					// this.getThemeByThemeType();
				}

			},
			newestActive() {
				this.isHot = false;
				this.isNewest = true;
				this.isPrice = false;
				this.isScreening = false;
				this.pageSize = 1; //当前页码重置为1
				this.DataList = []; //清空数据集合
				this.ordering = 'salesvolume'
				this.getIconDetails();
			},
			hotActive() {
				this.isNewest = false;
				this.isHot = true;
				this.isPrice = false;
				this.isScreening = false;
				this.pageSize = 1; //当前页码重置为1
				this.DataList = []; //清空数据集合
				this.ordering = 'uptime'
				this.getIconDetails();
			},

			isPriceActive() {

				this.isPrice = true;
				this.isHot = false;
				this.isScreening = false;
				this.pageSize = 1; //当前页码重置为1
				this.DataList = []; //清空数据集合
				this.ordering = 'price'
				this.getIconDetails();
			},
			isScreeningActive() {
				this.isPrice = false;
				this.isScreening = true;
				this.pageSize = 1; //当前页码重置为1
				this.DataList = []; //清空数据集合
				// this.getIconDetails(4);
			},

			// "body":{"pageNum":1,"filter":{},"autoParam":{"filter":{"tag":["100005"]}},"pageSize":20}}
			getIconDetails() {
				let data = {
					'body': {
						filter: {},
						typeId: 2,
						pageNum: this.pageSize,
						pageSize: 10,
						cateId: this.cateId,
						ordering: this.ordering
					},
					'global': this.global
				}
				this.axios.post(this.apiJSON.Category_gsSearchWithOrdering, JSON.stringify(data), {
					headers: {
						'content-Type': 'text/mhs-'
					}
				}).then((response) => {
					if(response.data.code == '000000') {
						// console.log(response.data,'response.data')
						if(response.data.body.length > 0) {
							for(let i = 0; i < response.data.body.length; i++) {
								let temp = response.data.body[i];
								this.DataList.push(temp)
							}
							this.loading = false;
						} else {
							this.isLoading = false;
							Toast("暂无数据")
						}
						// this.DataList = response.data.body
						// console.log(this.DataList)
					} else {
						Toast(response.data.message)
					}

				}).catch((error) => {

				});
			},

			goBack() {
				window.history.go(-1)
			},
			//获取热搜词汇
			getSearchValue() {},
			loadMore() {
				this.loading = true;
				this.pageIndex++;
				this.searchProducts(this.pageIndex);
			},
			//搜索商品

		},

	}
</script>

<style scoped>
	header {
		position: fixed;
		top: 0;
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0 1rem 0 0.4rem;
		font-size: 0.75rem;
		height: 2.4rem;
		color: #fff;
		background-color: #fff;
	}
	
	.nav_bat {
		width: 100%;
		position: fixed;
		top: 53px;
	}
	
	.nav-bar {
		/*float: left;*/
		text-align: center;
		white-space: nowrap;
		overflow-x: scroll;
		overflow-y: hidden;
		display: flex;
		align-items: center;
		background-color: #fff;
		border: 1px solid #ececec;
		border-bottom: none;
	}
	
	.nav-bar .active {
		color: #ea002f;
		background-color: #fff;
	}
	
	.nav-bar>div {
		flex: 1;
		height: 1.8rem;
		line-height: 1.8rem;
	}
	
	.main-body {
		/* 加上这个才会有当数据充满整个屏幕，可以进行上拉加载更多的操作 */
		overflow: scroll;
	}
	
	.priceIcon {
		position: relative
	}
	
	.priceIcon span {
		font-size: .3rem
	}
	
	.priceIconSpan1 {
		position: absolute;
		left: 62%;
		top: 20%
	}
	
	.back {
		width: 1rem;
		height: 1rem;
		background-size: 100% 100%;
		background-image: url("../../assets/images/category/back.png");
	}
	
	.search {
		padding: 0.2rem 0.4rem;
		border-radius: 0.8rem;
		/*border: 1px solid #ececec;*/
		background-color: #ececec;
	}
	
	.search img {
		width: 1rem;
		margin-right: 0.2rem;
	}
	
	.search input {
		width: 9rem;
		font-size: 0.65rem;
		border: none;
		background-color: #ececec;
	}
	
	.icon {
		font-size: 0.65rem;
	}
	
	.box {
		padding: 0.1rem 0.4rem;
	}
	
	.title {
		display: flex;
		align-items: center;
	}
	
	.title>img {
		width: 0.8rem;
		height: 0.8rem;
	}
	
	.box .content {
		display: flex;
		flex-wrap: wrap;
		align-items: center;
	}
	
	.box .content .keyword {
		color: #999;
		padding: 0 0.2rem;
		margin: 0.4rem 0.4rem 0 0;
		border: 1px solid #888;
	}
	
	.mode-list {
		background-color: #ffffff;
	}
</style>
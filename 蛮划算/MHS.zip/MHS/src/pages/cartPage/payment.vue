<template>
	<div class="container">
		<Mheader :show='true'>
			<div slot="title">提交订单</div>
		</Mheader>
		<!--<router-link :to="{path:'/MyAddress/pay'}">-->
		<div class="address " @click="selectAddress">
			<div>
        <!--<div class="name1"> <span>收件人：</span>{{defaultData.acceptName}}</div>-->
        <!--<div class="name"><img src="../../assets/images/payment/location@2x.png" /><span>收货地址：</span></div>-->
				<!--<div class="mr">{{defaultData.isDefault ==true ? '默认' : ''}} </div>-->
			</div>
			<div v-if="!!!defaultData" >
				<div class="no_address">
          <span><img src="../../assets/images/payment/location@2x.png" /></span><span style="width: 98%">还没有收货地址</span><span><img src="../../assets/images/arrow.png" /></span>
        </div>
			</div>
			<div v-else>
        <div class="address_Name">收件人：<span>{{defaultData.acceptName}}</span><span>{{defaultData.mobile}}</span></div>
        <div class="address_img"><img src="../../assets/images/payment/location@2x.png" />收货地址：<span>{{defaultData.address}}</span></div>
        <b class="address_bg"></b>
				<!--<div class="add">{{defaultData.address}}</div>-->
			</div>
			<div>
				<!--<img src="../../assets/images/arrow.png" />-->
			</div>
		</div>

		<div class="product" v-for="(item,index) in orderData" :key='index'>

			<img class="product-img" :src="imgBaseUrl+item.ProductImg" />
			<div class="product-details">
				<div>
					<p>{{item.Name}}</p>
					<p class="lm-text-grey lm-font-xs">{{ item.ProductName }}</p>
					<p class="lm-text-grey lm-font-xs">赠送{{ item.Score }}积分</p>

				</div>

				<div>
					<span>
            <span class="lm-text-red">￥{{item.ProductSpecPrice}}</span>元
					<span v-if="teaBMall"> +
              <span class="lm-text-red">{{item.TeaBPrice}}</span>茶币</span>
					</span>
					<span>x{{item.ProductCount}}</span>
				</div>
			</div>
		</div>
    <div class="Noteinformation">
          <p>备注：<input type="text" placeholder="请输入备注信息(选填)"></p>
    </div>
    <div class="activity"  @click="choice(1)">
      <p><span class="activity_span">优惠活动：</span><span class="activity_span2">不参加活动</span><span><img src="../../assets/images/arrow.png" /></span></p>
    </div>

    <transition name="fade">
      <div class="choiceCat-model" v-if="choiceShow" @click="choice()"></div>
    </transition>
    <transition name="drop">
      <div class="choiceCat" v-if="choiceShow">
        <div class="choiceCat_one">优惠活动</div>
        <div>
          <!--<p> <input type="text" v-model="choice_integralValue"> <span  class="address_p_bg":class="timeBarType()"></span></p>-->
          <p>
            <mt-field label="使用积分" v-model="captcha" :disabled="true" id="jifenid">
              <img src="../../assets/images/myAddress/icon_@2x.png" height="45px" width="100px">
            </mt-field>

          </p>
        </div>
        <div class="choice_activity">
          <!--<p><input type="text" v-model="choice_activityValue"> <span  class="address_p_bg":class="timeBarType()">222</span></p>-->
          <p>
            <mt-field label="不参加活动" v-model="captcha2">
              <img src="../../assets/images/myAddress/icon_@2x.png" height="45px" width="100px">
            </mt-field>
          </p>
        </div>
      </div>
    </transition>

		<div class="lm-margin-b-sm lm-margin-t-sm">
			<div class="coupon" v-for="(dis,index) in discount" @click="chkFavInfo(index)" :key='index'>
				<div>{{dis.FavContent | discountContent}}</div>
				<div class="product-select" :class="{checked:isChecked == index}"></div>
			</div>
		</div>

		<div class="order-details lm-margin-b-lg">
			<div class="lm-margin-b-sm">订单明细：</div>
			<div class="details">
				<span>订单总价</span>
				<span>￥{{orderTotal}}</span>
			</div>
			<!--TODO:运费还未计算到总价格中去-->
			<div class="details">
				<span>运费</span>
				<span>{{freight}}</span>
			</div>
			<div class="details" v-if="teaBMall">
				<span>茶币</span>
				<span>{{teaBPrice}}</span>
			</div>
			<div class="details" v-else>
				<span>优惠</span>
				<span>{{subtract}}</span>
			</div>
			<div class="details">
				<span>总计</span>
				<span class="lm-text-red">￥{{total}}</span>
			</div>
		</div>
		<div class="hide" v-html="alipay"></div>
		<div class="pay">
			<div>
				<div>共选择
					<span class="lm-text-red">{{ProductCount}}</span>件商品</div>
				<div>总金额：
					<span class="lm-text-red">￥{{total}}</span> 元</div>
			</div>
			<div class="topay" :class="{disableTap:isOnce}" @click="oncePayment">立即付款</div>
		</div>

	</div>
</template>

<script>
	import Mheader from '../../components/Mheader'
	import { Toast } from 'mint-ui'

	export default {
		components: {
			Mheader
		},
		data() {
			return {
        captcha:'剩余0积分',
        captcha2:'',
				defaultAddress: '',
				ProductCount: '',
				orderDetails: [],
				isChecked: '',
				freight: 0, //运费
				payType: 0, //支付类型
				alipay: '', //ali支付form表单信息
				productOrderId: "0",
				discount: [], //优惠记录信息
				chkdiscount: '', //选中的优惠信息
				subtract: '0', //优惠折扣价格
				teaBMall: false,
        choiceShow:false,
				teaBPrice: '0',
				defaultData: '',
				orderData: [],
				GoodsId: "",
				Quantity: '',
				isOnce: false,
				orderNo: '', //订单号
        orderTime:'',//下单时间
			}
		},
		computed: {
			orderTotal() {
				let t = 0;
				this.orderDetails.forEach(function(item) {
					t += parseInt(item.ProductCount) * parseFloat(item.ProductSpecPrice);
				});
				return t;
			},
			total() {
				return parseFloat(this.orderTotal) + parseFloat(this.freight) + parseFloat(this.subtract);
			},
			addressDetail() {
				return this.defaultAddress.Province + this.defaultAddress.City + this.defaultAddress.Area + this.defaultAddress.Detail;
			}

		},
		filters: {
			discountContent(val) {
				let strs = val.split('【');
				let lastStr = strs[1].split('】');
				return strs[0] + lastStr[1];
			}
		},
		methods: {
      timeBarType(type) {
        if(type == true) return 'gray-bg';
        if(type == false) return 'blue-bg';
      },
      choice(val) {
        this.choiceShow = !this.choiceShow
      },
			//获取默认的收货地址
			getDefaultAddress() {
				let data = {
					'body': {
						type: '1',
						userId: localStorage.uid,
						pageNum: 1,
						pageSize: 20,
					},
					'global': this.global
				}
				this.axios.post(this.apiJSON.usGetAddDeleteModifyAdress, JSON.stringify(data), {
					headers: {
						'content-Type': 'text/mhs-',
						'auth': localStorage.auth
					}
				}).then((response) => {
					if(response.data.code == '000000') {
						this.defaultAddress = response.data.body
            console.log(this.defaultAddress,'defaultAddress')
            this.defaultData=this.defaultAddress[0]
						this.defaultAddress.forEach(item => {
							if(item.isDefault == true) {
								//  console.log(item,'0009')
								this.defaultData = item
							}

						})
					} else {
						Toast(response.data.message)
					}

				}).catch((error) => {

				});

			},

			//支付类型选择
			checkType(val) {
				this.payType = val;
			},
			//提交订单支付
			oncePayment() {
				let data = {
					'body': {
						userId: localStorage.uid,
						goodsInfos: this.goodsInfo,
						isCart: 0,
						remark: "",
						transType: "1", //  1购物  2生活  3充值
						tpType: '2', //  配送类型  1到店  2配送
						tpAddress: this.defaultData.address, //收货地址
						mobileNo: this.defaultData.mobile, //联系人电话
						consignee: this.defaultData.acceptName, //收件人
						addressId: this.defaultData.adressId, //地址id
					},
					'global': this.global
				}
				this.axios.post(this.apiJSON.Goods_bsOrderSub, JSON.stringify(data), {
					headers: {
						'content-Type': 'text/mhs-',
						'auth': localStorage.auth
					}
				}).then((response) => {
					if(response.data.code == '000000') {
						Toast('下单成功')
						this.orderNo = response.data.body.orderNo
            this.orderTime = response.data.body.orderTime


            this.deleteCat()
						sessionStorage.setItem("orderNo", JSON.stringify(this.orderNo));
            sessionStorage.setItem("orderTime", JSON.stringify(this.orderTime));
						this.$router.push({
							path: '/OrderNo'
						})

					} else {
						Toast(response.data.message)
					}
				}).catch((error) => {
					Toast(response.data.message)
				});

				//
				//
				//
				//
				// this.isOnce = true;
				// //定义地址参数
				// let str_address = {
				//   AddressId: this.defaultAddress.AdressId,
				//   Province: this.defaultAddress.Province,
				//   City: this.defaultAddress.City,
				//   Area: this.defaultAddress.Area,
				//
				// }
				// //定义参数
				// let sc = {
				//
				//   // TotalPrice: this.total,
				//   // PayType: this.payType,
				//   // ProductCount: this.ProductCount,
				//   // OrderFrom: this.teaBMall ? 4 : 2,//订单来源  2标识商城  4表示茶币商城
				//   // AddressId: this.defaultAddress.AdressId,
				//   // ProductSkus: this.orderDetails,
				//   // ProductOrderId: this.productOrderId,
				//   // OrderAddress: str_address,
				//   // OrderToPrice:[!!!this.chkdiscount?undefined:this.chkdiscount],
				//   // ExpandId: !!sessionStorage.getItem("PromotionKey") ? sessionStorage.getItem("PromotionKey") : sessionStorage.getItem("ExpandId")
				// }
				//
				// if (this.teaBMall) {
				//   this.taaBMallOrder(sc);
				// } else {
				//   this.mallOrder(sc);
				// }

			},
      //清空购物车
      deleteCat(){
        let data = {
          'body': {
            userId: localStorage.uid,
            typeId: 1,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.Goods_clearCart, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-',
            'auth': localStorage.auth
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            this.productlist = []
            this.cateDta = response.data.body;

            this.cateDta.forEach((item) => {
              this.seller = item.seller
              item.goodsGroup.forEach(items => {
                this.catData = items
                console.log(this.catData, 'this.catData=')

              })
              this.productlistData.push(item.goodsGroup)
            })
            this.productlistData.forEach(item => {
              this.productlist.push(item)
            })
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },
			//商城下单
			mallOrder(sc) {
				this.axios({
					url: this.url + '/api/Order/SaveOrder',
					method: 'post',
					data: {
						strSc: JSON.stringify(sc)
					},
					headers: {
						'Authorization': 'BasicAuth ' + localStorage.lut
					}
				}).then((res) => {
					if(!!res)
						if(res.data.Code == 200) {
							sessionStorage.removeItem("pay");
							sessionStorage.removeItem("PromotionKey") //移除推广位id
							sessionStorage.removeItem("ExpandId") //移除活动推广位id
							if(this.payType == 0) {
								this.isOnce = false;
								this.$router.push({
									path: '/paymentCompleted'
								})
							}
							if(this.payType == 2) {
								this.alipay = res.data.ExData;
								setTimeout(function() {
									this.isOnce = false;
									document.forms['alipaysubmit'].submit();
								}, 0)
							}
						} else {
							this.isOnce = false;
							Toast(res.data.Data);
						}

				})
			},
			//茶币商城下单
			taaBMallOrder(sc) {
				this.axios({
					url: this.url + '/api/Order/TeaBPay',
					method: 'post',
					data: {
						strSc: JSON.stringify(sc)
					},
					headers: {
						'Authorization': 'BasicAuth ' + localStorage.lut
					}
				}).then((res) => {
					if(!!res)
						if(res.data.Code == 200) {
							sessionStorage.removeItem("pay");
							localStorage.removeItem("PromotionKey") //移除推广位id
							localStorage.removeItem("ExpandId") //移除活动推广位id
							if(this.payType == 0) {
								this.isOnce = false;
								this.$router.push({
									path: '/paymentCompleted'
								})
							}
							if(this.payType == 2) {
								if(res.data.ExData == "0") {
									this.$router.push({
										path: '/paymentCompleted'
									})
								} else {
									this.alipay = res.data.ExData;
									setTimeout(function() {
										this.isOnce = false;
										document.forms['alipaysubmit'].submit();
									}, 0)
								}
							}
						} else {
							this.isOnce = false;
							Toast(res.data.Data);
						}

				})
			},
			selectAddress() {
				this.$router.push({
					path: '/MyAddress/'
				})
			},
			//获取优惠信息
			getPreOrderFavInfo() {
				//定义参数
				let sc = {
					TotalPrice: this.total,
					PayType: 0, //0是货到付款
					ProductCount: this.ProductCount,
					OrderFrom: 2, //订单来源  2标识商城
					AddressId: '0',
					ProductSkus: this.orderDetails,
					ProductOrderId: '0',
					OrderAddress: '',
					OrderToPrice: ''
				}
				this.axios({
					url: this.url + '/api/Order/LoadPreOrderFavInfo',
					method: 'post',
					data: {
						strSc: JSON.stringify(sc)
					},
					headers: {
						'Authorization': 'BasicAuth ' + localStorage.lut
					}
				}).then((res) => {
					if(res.data.Code == 200) {
						this.discount = res.data.Data;
						if(this.discount.length == 0) {
							this.subtract = '0';
						} else {
							this.subtract = '-' + this.discount[0].FavPrice;
						}
					} else {
						if(res.data.Data == '目前暂不支持同时购买多件商品，请分开购买') {
							let instance = Toast(res.data.Data);
							setTimeout(() => {
								instance.close();
								this.$router.replace({
									path: '/cart'
								})
							}, 1500);
						} else {
							Toast(res.data.Data);
						}
					}
				})
			},
			//选中优惠折扣方式
			chkFavInfo(index) {
				this.chkdiscount = this.discount[index];
				this.subtract = '-' + this.discount[index].FavPrice;
				this.isChecked = index;
			}
		},
		mounted() {
			this.$nextTick(() => {
				if(!!sessionStorage.pay) {
					//继续付款
					var sc = JSON.parse(sessionStorage.pay);
					this.productOrderId = sc.productOrderId;
					this.orderDetails = sc.skus;
					this.orderData = [];
					var arr = []
					this.orderDetails.forEach(item => {
						this.orderData.push(item)
						var obj = {}
						console.log(item,'item')
						obj.goodsId = item.ShoppingCarId;
						obj.num = item.ProductCount;
						arr.push(obj)
						// this.GoodsId.push(item.ProductId)
						// this.Quantity.push(item.ProductCount)
					})
					this.goodsInfo = arr;
					console.log(this.goodsInfo, 'this.goodsInfo')
					this.ProductCount = this.orderDetails.length;
					if(this.productOrderId != '0') {
						this.payType = sc.payType;
						this.defaultAddress = sc.receive;
					} else {
						//首次付款
						if(!!!this.$store.state.receiveAddress) {
							this.getDefaultAddress();
						}
					}
					if(sc.mallType != 'teaBMall') {
						this.teaBMall = false;
						// this.getPreOrderFavInfo();
					} else {
						let totalTeaB = 0;
						this.orderDetails.forEach(function(item) {
							totalTeaB += item.TeaBPrice;
						})
						this.teaBPrice = totalTeaB == 0 ? 0 : '-' + totalTeaB;
						this.teaBMall = true;
					}
				}

				//判断选择的地址是否为空
				if(!!this.$store.state.receiveAddress) {
					this.defaultData = this.$store.state.receiveAddress;
					console.log(this.defaultData, 'pppp')

				}

			})
		},
		beforeDestroy() {

		}

	}
</script>

<style>
	.hide {
		display: none;
	}
  .mint-cell-wrapper{background-image: -webkit-linear-gradient(top, #d9d9d9, #d9d9d9 0%, transparent 0%)}
  .mint-field-core{background: #fff !important;}
  .mint-cell:last-child{background-image:linear-gradient(0deg, #d9d9d9, #d9d9d9 0%, transparent 0%)}
	.address {
		align-items: center;
    padding: .5rem 0;
		background-color: #fff;
    /*border-bottom: 1px solid #eee;*/
    font-size: 0.6rem;
    color: #636363;

  }
  .address_bg{display: inline-block;width: 100%;height: .1rem;background-image: url("../../assets/images/OrderDetails/border.png")}

  #jifenid input{background: #fff !important;}
.Noteinformation{padding-left: .6rem;height: 2rem;line-height: 2rem;background: #fff;margin: .4rem 0}
 .Noteinformation input{height: 1.8rem;width: 80%;border: none;}
 .activity{margin: .4rem 0;background: #fff;padding-left: .6rem;height: 2rem;line-height: 2rem;}
 .activity_span{width: 70%}
 .activity_span2{color: #c6c6c6}
  .activity img{width: 1rem;margin-bottom: .5rem}
	.address+.address {
		border-top: 1px solid #eeeeee;
	}
  .address_p_bg{display:inline-block;width: 18px;margin-bottom: -0.1rem;height:18px;background: url("../../assets/images/myAddress/icon@2x.png") no-repeat;background-size: 100% 100%}
  .gray-bg{display:inline-block;width: 18px;margin-bottom: -0.1rem;height:18px;background: url("../../assets/images/myAddress/icon_@2x.png") no-repeat;background-size: 100% 100%}

	.address>div:first-child {
		padding-left: 0.5rem;
	}
  .address>div:first-child .name1 {
    width: 6rem;
    padding-left: 1.2rem;
    font-size: 0.55rem;
  }
	.address>div:first-child .name {
    width: 5rem;
		font-size: 0.55rem;
	}
  .address>div:first-child .name img {
    width: 1rem;
  }
  .no_address{display: flex;margin-top: .2rem}

  .no_address img{width: 1rem}
  .address_img img{width: 1rem}
  .address_Name{padding-left: 1rem;display: flex;height: 1.2rem}
  .address_Name span{flex: 1}
	.address>div:first-child .mr {
		margin-top: 0.3rem;
		width: 1.5rem;
		text-align: center;
		border-radius: 0.1rem;
		font-size: 0.5rem;
		color: #B4282D;
		border: 1px solid #e40038;
	}
  .tel{text-align: right}
	.address>div:nth-child(2) {
	}

	.address>div:nth-child(2) .add {
		margin-top: 0.2rem;
		font-size: 0.6rem;
		color: #999;
	}

	.address>div:last-child {
		width: 1rem;
		height: 1rem;
		margin-left: 0.7rem;
	}

	.pay-modes {
		padding: 0.4rem;
		background-color: #ffffff;
	}
/*//弹出框*/
  .choiceCat-model {
    top: 0;
    left: 0;
    position: fixed;
    width: 100%;
    height: 100%;
    z-index: 922;
    background-color: rgba(0, 0, 0, 0.3);
  }

  .choiceCat {
    width: 100%;
    height:6rem;
    bottom: 0;
    position: fixed;
    z-index: 933;
    background-color: #fff;
  }
  .choiceCat img{width: 0.8rem;height: 0.8rem}
.choiceCat_one{background: #f4f4f4;height: 1.8rem;line-height: 1.8rem;padding: 0;padding-left: .4rem}
  .choiceCat .choiceCat-img {
    width: 5rem;
    height: 5rem;
    border-radius: 0.2rem;
    padding: 0.1rem;
    background-color: #ffffff;
    border: 1px solid #ddd;
    box-shadow: 0 0 3px #ddd;
    top: -0.8rem;
    left: 0.5rem;
    position: absolute;
  }

  .choiceCat .choiceCat-p {
    line-height: 1.1rem;
    padding-left: 6rem;
    height: 5.4rem;
    font-size: 0.65rem;
    border-bottom: 1px solid #eee;
    color: #999;
  }

  .choiceCat .choiceCat-p>div:last-child {
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }
.choiceCat input{height: 1.9rem;width: 80%;border: none;font-size: 0.60rem;color: #535353;padding-left: .5rem}
.choiceCat p{border-bottom: 1px solid #f4f4f4}
.choice_integral{height: 2rem;line-height: 2rem;border-bottom: 1px solid #f4f4f4}
.choice_integral span{width:18%;float: right;display: inline-block}
.choice_activity{height: 2rem;line-height: 2rem}
  .pay-modes .pay-mode {
		display: flex;
		align-items: center;
	}

	.pay-modes .pay-mode>div {
		display: flex;
		align-items: center;
		min-width: 4.4rem;
		padding: 0.1rem;
		border-radius: 0.1rem;
		font-size: 0.6rem;
		border: 1px solid #999;
	}

	.pay-mode>div>img {
		margin-right: 0.2rem;
		width: 1.2rem;
		height: 1.2rem;
	}

	.pay-mode .active {
		color: #B4282D;
		border-color: #B4282D!important;
		/*background-color: #B4282D;*/
	}

	.product {
		display: flex;
		align-items: center;
		padding: 0.8rem;
		/*background-color: #f4f4f4;*/
	}

	.product .product-img {
		width: 3.2rem;
		height: 3.2rem;
		border: 1px solid #eeeeee;
		margin-right: 0.5rem;
	}

	.product .product-details {
		width: 100%;
		height: 3.2rem;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.product .product-details>div:last-child {
		display: flex;
		justify-content: space-between;
	}

	.coupon {
		display: flex;
		align-items: center;
		justify-content: space-between;
		font-size: 0.6rem;
		border-top: 1px solid #eee;
		padding: 0.4rem;
		background-color: #ffffff;
	}

	.order-details {
		padding: 0.4rem;
		background-color: #ffffff;
	}

	.order-details .details {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-bottom: 0.2rem;
	}

	.order-details .details>span:first-child {
		color: #999999;
		font-size: 0.6rem;
	}

	.pay {
		width: 100%;
		bottom: 0;
		position: fixed;
		height: 2.4rem;
		padding-left: 0.4rem;
		border-top: 1px solid #eeeeee;
		background-color: #fff;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.pay .topay {
		text-align: center;
		line-height: 2.4rem;
		color: #ffffff;
		width: 4.5rem;
		height: 100%;
		background-color: #e40038;
	}

	.product-select {
		width: 0.8rem;
		height: 0.8rem;
		margin-right: 0.4rem;
		background-image: url("../../assets/images/cart/unchecked.png");
		background-size: 100% 100%;
	}

	.checked {
		background-image: url("../../assets/images/cart/checked.png");
	}
</style>

<template>
  <div class="container">
    <Mheader>
      <div slot="title">订单轨迹</div>
      <!--<div slot="info" @click='saveUserInfo'>保存</div>-->
    </Mheader>
    <div class="order_track">
      <p><img class="product-img" :src="imgBaseUrl+OrdersTrackData.goodImg" /></p>
      <p><span>订单号：{{OrdersTrackData.orderNo}}</span></p>
    </div>
    <div class="box_track"></div>
    <div>
      <div class="timeline-demo">
        <timeline >
          <timeline-item v-for="(item,index) in logisticsData" :key="index">
            <h4 class="recent">{{item.content}}</h4>
            <p class="recent">{{item.time}}</p>
          </timeline-item>

        </timeline>

      </div>
    </div>
  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  import { Timeline, TimelineItem } from 'vux'
  export default {
    components: {
      Mheader,
      Timeline,
      TimelineItem,
    },
    data() {
      return {
        logisticsData:[],//物流轨迹
        workTask:[],
        OrdersTrackData:[],
        Imgurl:this.$route.params.imgUrl,
        productID:this.$route.params.productID,
      }
    },
    methods: {
        Track(){
          let data = {
            'body': {
              orderNo: this.OrdersTrackData.orderNo,
            },
            'global': this.global
          }
          this.axios.post(this.apiJSON.order_bsOrderTraceRecords, JSON.stringify(data), {
            headers: {
              'content-Type': 'text/mhs-'
            }
          }).then((response) => {
            if(response.data.code == '000000') {
              this.logisticsData=response.data.body
              console.log( this.logisticsData,'body')

            } else {
              Toast(response.data.message)
            }

          }).catch((error) => {

          });
        },

    },
    created(){

    },
    mounted: function() {
      this.$nextTick(() => {
        if(!!sessionStorage.OrdersTrackData){
          this.OrdersTrackData=JSON.parse(sessionStorage.OrdersTrackData)
          console.log(this.OrdersTrackData,'000')
        }
        this.Track()



      })
    }
  }
</script>

<style>
  .order_track{display: flex;height: 4rem;line-height: 4rem;padding: .3rem;background: #fff;border-top: 1px solid #eee}
  .order_track img{width: 3rem;margin-bottom: 1rem;margin-right: .4rem}
  .box_track{height: .6rem;background: #f4f4f4}
  .timeline-demo p {
    color: #b7b7b7;
    font-size: 0.55rem;
  }
  .timeline-demo :nth-child(1) h4 {
    color: #ffc950;
    font-size: 0.6rem;
    font-weight: normal;
  }
  .weui-icon-success-no-circle{
    color:#ffa73c !important ;
  }
  .vux-timeline-item-tail{background:#e2e2e2 !important}
  .vux-timeline-item-color{ background:#ffa73c !important}
  /*.timeline-demo .recent {*/
    /*color: #ffc950*/
  /*}*/
</style>

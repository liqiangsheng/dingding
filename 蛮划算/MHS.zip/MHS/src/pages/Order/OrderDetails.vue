<template>
  <div class="container">
    <Mheader :show='true'>
      <div slot="title">订单详情</div>
    </Mheader>
    <div>
      <div class="orderSuatus" @click="OrdersTrack">
         <p><img src="../../assets/images/OrderDetails/guiji@2x.png" alt=""><span v-html="contentData"></span></p>
      </div>
    </div>
    <div class="countdown" v-show="isShow">
      <div class="countdown_top">
        <p class="countdown_top_p">
          <img src="../../assets/images/OrderDetails/wait@2x.png" alt="">
        </p>
        <p  class="countdown_top_botom">等待付款</p>
        <p v-html="TimedataOVER"></p>
      </div>
      <!--<count-down v-on:start_callback="countDownS_cb(1)" v-on:end_callback="countDownE_cb(1)"-->
                  <!--:currentTime="newDataTime" :startTime="TimeData" :endTime="TimedataOVER"-->
                  <!--:tipText="'距离开始文字1'" :tipTextEnd="'距离结束文字1'" :endText="'结束自定义文字2'"-->
                  <!--:dayTxt="'天'" :hourTxt="'小时'" :minutesTxt="'分钟'" :secondsTxt="'秒'">-->
      <!--</count-down>-->
    </div>
    <div class="address " >
      <div>
        <div class="address_Name">收件人：<span>{{sellerData.consignee}}</span><span>{{sellerData.mobileNo}}</span></div>
        <div class="address_img"><img src="../../assets/images/payment/location@2x.png" /><span class="address_span" style="width: 3rem">收货地址：</span><span class="address_span">{{sellerData.tpAddress}}</span></div>
      </div>
      <b class="address_bg"></b>
    </div>

    <div class="sellerNanme">
      <p>{{sellmerchData.sellerName}}  <span v-if="sellmerchData.status==1" >{{ordeStatus}}</span></p>
    </div>
    <div    v-for="(item,index) in goodsData" :key='index'>
      <router-link :to="{path:'/ProductDetails/'+item.goodsId}">
        <div class="product">


      <img class="product-img" :src="imgBaseUrl+item.goodImg" />
      <div class="product-details">
        <div>
          <p>{{item.goodsName}}</p>
          <p class="lm-text-grey lm-font-xs">{{ item.attrConcat }}</p>
          <p class="lm-text-grey lm-font-xs Present"><span>赠送 {{ item.score }} 积分</span></p>
        </div>
        <div class="price">
          <span class="price_left ">￥{{item.appPrice}}元</span>
          <span class="price_right">x{{item.total}}</span>
        </div>
        <div>
          <p></p>
        </div>
      </div>
        </div>
      </router-link>
    </div>
    <div class="Noteinformation">
      <p>备注：<input type="text" placeholder="请输入备注信息(选填)"></p>
    </div>
    <div class="Noteinformation">
      <a :href="getGoodsHref(sellmerchData)">联系卖家</a>
    </div>
    <div class="order-details lm-margin-b-lg">
      <div class="details">
        <span>订单编号：</span>
        <span>{{sellerData.orderNo}}</span>
      </div>
      <div class="details">
        <span>下单时间：</span>
        <span>{{sellerData.orderTime}}</span>
      </div>


    </div>
    <div class="hide" v-html="alipay"></div>
    <div class="paydetails">
      <div  @click="CancelOrder" class="paydetails_left" v-show="isShow"><span>取消订单</span></div>
      <div  @click="oncePayment" class="paydetails_right" v-show="isShow">立即支付</div>
      <div  @click="ArefundOrder" class="paydetails_left paydetails_mory"  v-if="isOrderStatus=='6'">
        <router-link :to="{path:'/Arefund/'+path}">
        <span>申请退款</span>
        </router-link>

      </div>
    </div>

  </div>
</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  import CountDown from 'vue2-countdown'
  import { MessageBox } from 'mint-ui';
  export default {
    components: {
      Mheader,
      CountDown
    },
    data() {
      return {
        OrdersTrackData:'',
        imgUrl:'201806201820337282313152.jpg',
        path:this.$route.params.productID,
        contentData:'',//订单最新状态
        ordeStatus:'待付款',
        newDataTime:0,//当前时间
        TimeData:0,// 下单时间
        TimedataOVER:0,//结束时间
        hours:24,
        minutes:60,
        seconds:0,
        captcha:'剩余0积分',
        captcha2:'',
        defaultAddress: '',
        ProductCount: '',
        orderDetails: [],
        isChecked: '',
        time: 1,
        day: '',
        hour: '',
        minute: 0,
        second: 0,
        freight: 0, //运费
        payType: 0, //支付类型
        alipay: '', //ali支付form表单信息
        productOrderId: "0",
        discount: [], //优惠记录信息
        chkdiscount: '', //选中的优惠信息
        subtract: '0', //优惠折扣价格
        teaBMall: false,
        choiceShow:false,
        teaBPrice: '0',
        defaultData: '',
        orderData: [],
        GoodsId: "",
        Quantity: '',
        isOnce: false,
        orderNo_data:'',
        orderNo: '', //订单号
        sellerData:'',//商品数据
        sellmerchData:'',//商家
        goodsData:[],
        isShow:true,
        isOrderStatus:false,
        orderNoorderNo:'',
      }
    },
    computed: {


      orderTotal() {
        let t = 0;
        this.orderDetails.forEach(function(item) {
          t += parseInt(item.ProductCount) * parseFloat(item.ProductSpecPrice);
        });
        return t;
      },
      total() {
        return parseFloat(this.orderTotal) + parseFloat(this.freight) + parseFloat(this.subtract);
      },
      addressDetail() {
        return this.defaultAddress.Province + this.defaultAddress.City + this.defaultAddress.Area + this.defaultAddress.Detail;
      }

    },
    filters: {
      discountContent(val) {
        let strs = val.split('【');
        let lastStr = strs[1].split('】');
        return strs[0] + lastStr[1];
      },

    },
    watch:{
      second:{
        handler(newVal){
          this.num(newVal)
        }
      },
      minute:{
        handler(newVal){
          this.num(newVal)
        }
      }
    },
    methods: {
      //申请退款
      ArefundOrder(){

      },
      //跳转到物流轨迹
      OrdersTrack(){
        sessionStorage.setItem("OrdersTrackData", JSON.stringify(this.OrdersTrackData));
        this.$router.push({
          path: '/OrdersTrack'
        })
      },
      //订单的最新详情
      bsOrderTraceInfo(){
        let data = {
          'body': {
            orderNo: this.$route.params.productID,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.order_bsOrderTraceInfo, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if(response.data.code == '000000') {
           console.log(response.data.body,'body')
              this.contentData=response.data.body.content
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },
      getTime(fixedDate){
        var nowDate=parseInt((new Date().getTime())/1000);//当前时间；
        var addTotals = parseInt(fixedDate/1000) +86400;//下单时间+24小时后总秒数；
        var totalS =addTotals - nowDate;
        var secondTotal=totalS/1000;
        var h = parseInt((totalS / 3600) % 24)
        var m = parseInt((totalS / 60) % 60);
        var s = parseInt(totalS % 60);
        if(secondTotal >=0){
          return	"剩余时间" + h+"小时"+m+"分"+s+"秒"
        }else{
          return "活动已经过期"
        }


      },
      //取消订单
      CancelOrder(){
        MessageBox.confirm('是否取消订单?').then(action => {
          let data = {
            'body': {
              dealType:'1',
              orderNo: this.$route.params.productID,
            },
            'global': this.global
          }
          this.axios.post(this.apiJSON.order_bsOrderCancel, JSON.stringify(data), {
            headers: {'content-Type': 'text/mhs-','auth': localStorage.auth}
          }).then((response) => {
            if(response.data.code == '000000') {
              Toast('订单取消成功')
              this.orderData_item()
            } else {
              Toast(response.data.message)
            }

          }).catch((error) => {

          });
        });

      },
      getGoodsHref:function(sellmerchData){
        return 'tel:'+sellmerchData.sellmerchData
      },
      orderData_item(){
        let data = {
          'body': {
            orderNo: this.$route.params.productID,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.order_bsOrderInfo, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if(response.data.code == '000000') {
           this.sellerData=response.data.body
            this.sellmerchData=response.data.body.sellerInfo
            this.goodsData=response.data.body.shopInfoList
            this.OrdersTrackData=response.data.body.shopInfoList[0];
            var timestamp1 = new Date(response.data.body.orderTime);
           var that=this;
            this.invt = setInterval(() => {
              that.getTime(timestamp1)
              that.TimedataOVER=that.getTime(timestamp1)
              //此时的this指向是该vue组件，
            }, 1000)
            this.isOrderStatus=response.data.body.orderStatus
              if(this.isOrderStatus==3|| this.isOrderStatus==6){
                this.isShow=!this.isShow
                this.ordeStatus='已取消'
              }
              if(this.isOrderStatus==4){
                this.isShow=!this.isShow
                this.ordeStatus='超时支付取消'
              }
              if(this.isOrderStatus==18){
                this.isShow=!this.isShow
                this.ordeStatus='已完成'
              }
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },

      countDownS_cb: function (x) {
        console.log(x)
      },
      countDownE_cb: function (x) {
        console.log(x)
      },

      //时间格式
      formate(time) {
        if (time >= 10) {
          return time
        } else {
          return `0${time}`
        }
      },
      timeBarType(type) {
        if(type == true) return 'gray-bg';
        if(type == false) return 'blue-bg';
      },
      choice(val) {
        this.choiceShow = !this.choiceShow
      },
      //获取默认的收货地址
      getDefaultAddress() {
        let data = {
          'body': {
            type: '1',
            userId: localStorage.uid,
            pageNum: 1,
            pageSize: 20,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.usGetAddDeleteModifyAdress, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-',
            'auth': localStorage.auth
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            this.defaultAddress = response.data.body
            this.defaultAddress.forEach(item => {
              if(item.isDefault == true) {
                //  console.log(item,'0009')
                this.defaultData = item
              }

            })
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });

      },

      //支付类型选择
      checkType(val) {
        this.payType = val;
      },

      //提交订单支付
      oncePayment() {
        let data = {
          'body': {
            orderNos: [this.$route.params.productID]

          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.order_toPay, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-',
            'auth': localStorage.auth
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            Toast('下单成功')
            console.log(response.data.body,'response.data.body')
            this.orderNoorderNo = response.data.body.orderNo
            sessionStorage.setItem("orderNo", JSON.stringify(this.orderNoorderNo));
            this.$router.push({
              path: '/OrderNo'
            })

          } else {
            Toast(response.data.message)
          }
        }).catch((error) => {
          Toast(response.data.message)
        });

      },

    },
    mounted() {
      this.$nextTick(() => {
        this.orderData_item()
        this.bsOrderTraceInfo()
        //判断选择的地址是否为空
        if(!!this.$store.state.receiveAddress) {
          this.defaultData = this.$store.state.receiveAddress;
          console.log(this.defaultData, 'pppp')

        }

      })
    },
    beforeDestroy() {

    }

  }
</script>

<style scoped>
  html{background: #f4f4f4;}
  .hide {display: none; }
  .orderSuatus{font-size: 0.55rem;padding-left: .6rem;border-top: 1px solid #eee;border-bottom: 1px solid #eee;padding: .3rem;color: #999}
  .orderSuatus img{width: 1rem}
  .orderSuatus p{height: 1rem;line-height: 1rem}
  .orderSuatus p span{padding-left: .3rem}
  .mint-msgbox-confirm{color: #e40038 !important;}
  .sellerNanme{height: 2rem;line-height: 2rem;padding-left: .4rem;font-size: 0.6rem;background: #fff}
  .sellerNanme span{float: right;padding-right: .4rem;color: #e40038}
  .countdown{height: 3rem;line-height: 3rem;text-align: center;background: #f14a52;color: #fff;font-size: 0.55rem}
  .countdown i{color: #fff !important;}
  .Noteinformation{font-size: 0.55rem}
  .price{display: flex}
  .countdown_top{display: flex}
  .countdown_top_p{width: 3rem}
  .countdown_top img{width: 1.6rem;margin-bottom: .6rem}
  .countdown_top_botom{width: 5rem;text-align: left}
  .price_left{flex: 2;color: #e40038}
  .Present span{background: #ffba41;padding: .1rem;color: #fff;border-radius: .2rem}
  .mint-cell-wrapper{background-image: -webkit-linear-gradient(top, #d9d9d9, #d9d9d9 0%, transparent 0%)}
  .mint-field-core{background: #fff !important;}
  .mint-cell:last-child{background-image:linear-gradient(0deg, #d9d9d9, #d9d9d9 0%, transparent 0%)}
  .address {
    align-items: center;
    padding: .5rem 0;
    background-color: #fff;
    /*border-bottom: 1px solid #eee;*/
    /*width:100%;*/
    /*height:210px;*/
    /*border:41px solid #ddd;*/
    /*border-image:url('../../assets/images/OrderDetails/border.png') 70 repeat)*/
    font-size: 0.6rem;
    color: #636363;

  }
  .address_bg{display: inline-block;width: 100%;height: .1rem;background-image: url("../../assets/images/OrderDetails/border.png")}
  .address_span{
    height: 1.4rem;
    line-height: 1.6rem;
    overflow: hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
    width:140px;}
  #jifenid input{background: #fff !important;}
  .Noteinformation{padding-left: .6rem;height: 2rem;line-height: 2rem;background: #fff;margin: .4rem 0}
  .Noteinformation input{height: 1.8rem;width: 80%;border: none;}
  .activity{margin: .4rem 0;background: #fff;padding-left: .6rem;height: 2rem;line-height: 2rem;}
  .activity_span{width: 70%}
  .activity_span2{color: #c6c6c6}
  .activity img{width: 1rem;margin-bottom: .5rem}
  .address+.address {
    border-top: 1px solid #eeeeee;
  }
  .address_p_bg{display:inline-block;width: 18px;margin-bottom: -0.1rem;height:18px;background: url("../../assets/images/myAddress/icon@2x.png") no-repeat;background-size: 100% 100%}
  .gray-bg{display:inline-block;width: 18px;margin-bottom: -0.1rem;height:18px;background: url("../../assets/images/myAddress/icon_@2x.png") no-repeat;background-size: 100% 100%}
  .address>div{font-size: 0.55rem}
  .address>div:first-child {
    padding-left: 0.5rem;
  }
  .address>div:first-child .name1 {
    width: 6rem;
    padding-left: 1.2rem;
    font-size: 0.55rem;
  }
  .address>div:first-child .name {
    width: 5rem;
    font-size: 0.55rem;
  }
  .address>div:first-child .name img {
    width: 1rem;
  }
  .no_address{display: flex;margin-top: .2rem}

  .no_address img{width: 1rem}
  .address_img img{width: 1rem;margin-bottom: .4rem}
  .address_Name{padding-left: 1rem;display: flex;height: 1.2rem}
  .address_Name span{flex: 1}
  .address>div:first-child .mr {
    margin-top: 0.3rem;
    width: 1.5rem;
    text-align: center;
    border-radius: 0.1rem;
    font-size: 0.5rem;
    color: #B4282D;
    border: 1px solid #B4282D;
  }
  .tel{text-align: right}
  .address>div:nth-child(2) {
    margin-left: 0.8rem;
  }

  .address>div:nth-child(2) .add {
    margin-top: 0.2rem;
    font-size: 0.6rem;
    color: #999;
  }

  .address>div:last-child {
    width: 1rem;
    height: 1rem;
    margin-left: 0.7rem;
  }

  .pay-modes {
    padding: 0.4rem;
    background-color: #ffffff;
  }
  /*//弹出框*/
  .choiceCat-model {
    top: 0;
    left: 0;
    position: fixed;
    width: 100%;
    height: 100%;
    z-index: 922;
    background-color: rgba(0, 0, 0, 0.3);
  }

  .choiceCat {
    width: 100%;
    height:6rem;
    bottom: 0;
    position: fixed;
    z-index: 933;
    background-color: #fff;
  }
  .choiceCat img{width: 0.8rem;height: 0.8rem}
  .choiceCat_one{background: #f4f4f4;height: 1.8rem;line-height: 1.8rem;padding: 0;padding-left: .4rem}
  .choiceCat .choiceCat-img {
    width: 5rem;
    height: 5rem;
    border-radius: 0.2rem;
    padding: 0.1rem;
    background-color: #ffffff;
    border: 1px solid #ddd;
    box-shadow: 0 0 3px #ddd;
    top: -0.8rem;
    left: 0.5rem;
    position: absolute;
  }

  .choiceCat .choiceCat-p {
    line-height: 1.1rem;
    padding-left: 6rem;
    height: 5.4rem;
    font-size: 0.65rem;
    border-bottom: 1px solid #eee;
    color: #999;
  }

  .choiceCat .choiceCat-p>div:last-child {
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }
  .choiceCat input{height: 1.9rem;width: 80%;border: none;font-size: 0.60rem;color: #535353;padding-left: .5rem}
  .choiceCat p{border-bottom: 1px solid #f4f4f4}
  .choice_integral{height: 2rem;line-height: 2rem;border-bottom: 1px solid #f4f4f4}
  .choice_integral span{width:18%;float: right;display: inline-block}
  .choice_activity{height: 2rem;line-height: 2rem}
  .pay-modes .pay-mode {
    display: flex;
    align-items: center;
  }

  .pay-modes .pay-mode>div {
    display: flex;
    align-items: center;
    min-width: 4.4rem;
    padding: 0.1rem;
    border-radius: 0.1rem;
    font-size: 0.6rem;
    border: 1px solid #999;
  }

  .pay-mode>div>img {
    margin-right: 0.2rem;
    width: 1.2rem;
    height: 1.2rem;
  }

  .pay-mode .active {
    color: #B4282D;
    border-color: #B4282D!important;
    /*background-color: #B4282D;*/
  }

  .product {
    display: flex;
    align-items: center;
    padding: 0.8rem;
    background-color: #f4f4f4;
    font-size: 0.6rem;
    margin-bottom: .1rem;
  }

  .product .product-img {
    width: 3.4rem;
    height: 3.4rem;
    border: 1px solid #eeeeee;
    margin-right: 0.5rem;
  }

  .product .product-details {
    width: 100%;
    height: 3.2rem;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }

  .product .product-details>div:last-child {
    display: flex;
    justify-content: space-between;
  }
.product-details p{margin-bottom: .1rem}
  .coupon {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 0.6rem;
    border-top: 1px solid #eee;
    padding: 0.4rem;
    background-color: #ffffff;
  }

  .order-details {
    padding: 0.4rem;
    background-color: #ffffff;
  }

  .order-details .details {
    align-items: center;
    justify-content: space-between;
    margin-bottom: 0.2rem;
  }

  .order-details .details>span {
    color: #999999;
    font-size: 0.55rem;
  }

  .paydetails {
    width: 100%;
    bottom: 0;
    position: fixed;
    height: 2.4rem;
    padding-left: 0.4rem;
    border-top: 1px solid #eeeeee;
    background-color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .paydetails div {
    height: 1.6rem;
    line-height: 1.6rem;
    width: 4rem;
  }
  .paydetails_left{flex: 1;text-align: right}
  .paydetails_left span{display: inline-block;text-align: center;width: 4rem;border: 1px solid #9a9a9a;border-radius: .2rem}
  .paydetails_right{text-align: center;border: 1px solid #e40038;background: #e40038;color: #fff;border-radius: .2rem;margin: .6rem}
  .paydetails_mory{padding-right: .5rem}
  .product-select {
    width: 0.8rem;
    height: 0.8rem;
    margin-right: 0.4rem;
    background-image: url("../../assets/images/cart/unchecked.png");
    background-size: 100% 100%;
  }

  .checked {
    background-image: url("../../assets/images/cart/checked.png");
  }
</style>

<template>
<div class="container">
  <Mheader :show='true'>
    <div slot="title">申请退款</div>
  </Mheader>
  <div class="goodsBox"  v-for="(item,index) in goodsData" :key='index'>
      <div class="goodsBpx_left">
        <span><img alt="" v-lazy="imgBaseUrl+item.goodImg"></span>
        <!--<img alt="" v-lazy="imgBaseUrl+items.goodImg">-->
      </div>
    <div class="goodsBpx_right">
      <p> {{item.goodsName}}</p>
      <p> {{item.attrConcat}}</p>
      <p class="goodsBpx_right_p"> <span class="goodsBpx_right_spanLeft">￥{{item.appPrice}}</span> <span class="goodsBpx_right_span_right">x{{item.total}}</span></p>
    </div>
  </div>
  <div class="Arefund_reason">
    <p>请选择退款原因</p>
    <div>
      <mt-radio
        align="right"
        v-model="value"
        :options="options" @change="check" id="radio_goods">
      </mt-radio>
    </div>
  </div>
  <div class="Arefund_reason_botm">
    <p>退款金额 <span class="Arefund_reason_botm_span">{{payAmountData}}.00积分</span> </p>
    <p>退款原因 <input type="text" placeholder="选填"></p>
  </div>
  <div class="goods_btn">提交</div>

</div>
</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Checklist } from 'mint-ui';
  export default {
    components: {
      Mheader,
    },
    data() {
      return {
        payAmountData:'',
        goodsData:"",
        value: "",
        options : [
          {
            label: '不想要了',
            value: '0'
          },
          {
          label: '拍错了',
          value: '1'
        },
          {
            label: '选项B',
            value: '2'
          },
          {
            label: '七天无理由退货',
            value: '3'
          },
          {
            label: '收到商品破损',
            value: '4'
          },
          {
            label: '商品发错/漏发',
            value: '5'
          },
          {
            label: '商品需要维修',
            value: '6'
          },
          {
            label: '发票问题',
            value: '7'
          },
          {
            label: '太贵了',
            value: '8'
          }
          ]

      }
    },
    methods: {
      check: function(){
        console.log(this.value)
      },
      Arefund(){
        let data = {
          'body': {
            orderNo: this.$route.params.productID,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.order_bsOrderInfo, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            console.log(response.data.body,'body')
            this.payAmountData=response.data.body.payAmount
            this.goodsData=response.data.body.shopInfoList
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },

    },
    mounted: function() {
      this.$nextTick(() => {
      this.Arefund()
      })
    }
  }
</script>

<style>
  html{background: #f4f4f4}
.goodsBox{display: flex;padding: .5rem ;color: #999;background: #fff;font-size: 0.6rem}
.goodsBox img{width: 4rem}
  .goodsBpx_right{flex: 1;}
  .goodsBpx_right p{padding: .25rem}
  .goodsBpx_right_p{display: flex}
  .goodsBpx_right_spanLeft{flex: 1;color: #e40038}
  .Arefund_reason{margin-top: .4rem;background: #fff;font-size: 0.55rem}
  .Arefund_reason p{padding-left: .8rem;height:1.8rem;line-height: 1.8rem}
  #radio_goods span{font-size: 0.55rem !important;}
  #radio_goods .mint-radio-core{border: 1px solid #fff !important;}
  .Arefund_reason_botm{background: #fff;margin-top: .4rem;padding-left: .6rem;font-size: 0.55rem}
  .Arefund_reason_botm p{height: 1.6rem;line-height: 1.6rem}
  .Arefund_reason_botm input{height: 1.6rem;line-height: 1.6rem;border: none;width: 80%;padding-left: .5rem}
  .Arefund_reason_botm_span{color: #e40038;padding-left: .5rem}
  .goods_btn{width: 100%;height: 1.6rem;line-height: 1.6rem;background:#e40038;color: #fff;position: fixed;left: 0;bottom: 0;text-align: center;font-size: 0.6rem}
</style>

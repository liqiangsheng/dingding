<template>
  <div class="container">
    <Mheader>
      <div slot="title">商家结算</div>
    </Mheader>
    <div>
      <div class="getData_box">
        <p class="getData_transferInValue"> -{{getData.transferInValue}} </p>
        <p class="getData_p">转让成功后对方将收到您转让的积分</p>
      </div>
      <div class="getData_center">
        <p>
          <span>对方账户：</span>
          <span class="getData_center_span">  {{getData.transferMobile |newtel}}</span>
        </p>
        <p>
          <span>您将转出：</span>
          <span class="getData_center_span">{{getData.transferInValue}} 积分</span>
        </p>
        <p>
          <span>对方收入：</span>
          <span class="getData_center_span">{{getData.transferOutValue}} 积分</span>
        </p>
      </div>
    </div>
    <div class="getData_center_btn"  @click="handleClick">确认</div>



    <mt-popup
      v-model="popupVisible"
      position="bottom"
      modal=false id="pwdpush-box">
      <div class="pwdpush-box">
        <div   :class="pushShow?'':'write-phonenum-1000'">
          <div class="write-phonenum">
            <p class="write-phonenum_p">支付积分 {{getData.transferInValue}} </p>
            <ul class="write-input clearfix">
              <input type="password"  ref="input" maxlength="6" class="realInput" v-model="realInput"  @keyup="getNum()"   @keydown="delNum()">
              <li v-for="disInput in disInputs"><input type="password" maxlength="1"  v-model="disInput.value"></li>
            </ul>
            <mt-button size="large" style="margin-top:80px;" @click="goPay">确认支付</mt-button>
          </div>
        </div>
      </div>

    </mt-popup>


  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  import { Field ,Indicator} from 'mint-ui';
  import { Popup } from 'mint-ui';
  import md5 from 'js-md5';

  export default {
    components: {
      Mheader,
    },
    data() {
      return {
        getData:'',
        messagepacket:false,
        packets:[

        ],
        makeTransferDataSell:"",
        popupVisible:false,
        disInputs:[{value:''},{value:''},{value:''},{value:''},{value:''},{value:''}],
        realInput:'',
        pushShow:true
      }
    },
    methods: {
      handleClick(){
        this.realInput=''
        this.popupVisible = true

      },
      getNum(){
        for(var i=0;i<this.realInput.length;i++){
          this.disInputs[i].value=this.realInput.charAt(i)
          // 表示字符串中某个位置的数字，即字符在字符串中的下标。
        }
      },
      delNum(){
        var oEvent = window.event;
        if (oEvent.keyCode == 8) {
          if(this.realInput.length>0){
            this.disInputs[this.realInput.length-1].value=''
          }
        }
      },
      goPay(){
        console.log(this.realInput)
        let data = {
          'body': {
            amount:this.getData.transferInValue,
            password:md5(this.realInput),
            score:this.getData.transferInValue,
            sellerId:this.makeTransferDataSell.sellerId,
            sellerMobile:this.makeTransferDataSell.sellerMobile,
            transAmount:this.getData.transferOutValue,
            userType: 1
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_integralTransfer, JSON.stringify(data), {
          headers: {'content-Type': 'text/mhs-',auth:localStorage.auth}
        }).then((response) => {
          if (response.data.code == '000000') {
            this.discount=response.data.body.discount


          } else {
            Toast(response.data.message)

          }

        }).catch((error) => {

        });
      },
      enterPwd(){
        this.pushShow = true;

        this.$refs.input.focus()
      }
    },
    filters : {
      newtel (value1) {
        if(!value1) return ''
        let value2 = value1.toString().substr(0,3)
        value1 = value1.toString().substr(-4,4)
        value1 =value2+'*'.repeat(4)+value1
        let endMember = value1.substr(-1,1)
        if(endMember % 2){
          value1 = value1
        }else{
          value1 = value1
        }
        return value1
      }
    },
    mounted: function() {
      // this.headerNav(false)
      // this.bottomShow(false)
      this.$nextTick(() => {
        this.getData=JSON.parse(sessionStorage.getMakeData)
        this.makeTransferDataSell=JSON.parse(sessionStorage.makeTransferData)
        console.log(this.getData,'000')
        console.log(this.makeTransferDataSell,'makeTransferDataSell')

      })
    }
  }
</script>

<style >

  .enter-password{
    text-align: right;
    color:#1D890D;
    font-size: 18px;
    line-height: 2;
    margin-top:20px;
    padding-right: 20px;
  }
  .phonenum-show{
    background: rgba(0,0,0,0.6);
    position: absolute;
    bottom:0;
    right:0;
    bottom:0;
    left:0;
    z-index: -1;
    margin-top: 3rem;
  }
  .getback-title span{position: absolute;right:0;top:3px;width:15px;height:15px;display: inline-block;}
  .write-phonenum-1000{
    top:-1000px!important;
  }
  .write-phonenum{

    padding:60px 10px 0;
    background: #fff;
  }
  .write-phonenum p{
    font-size: 14px;
    margin-left:30px;
    line-height:2;
  }
  .write-phonenum_p{text-align: center}
  #pwdpush-box{width: 100% !important;}
  .write-phonenum p span{color: #3b90d1;}
  .write-input {width:312px; margin:10px auto; position: relative;}
  .write-input li{float: left;width:30px;height:30px; margin: 0 10px; border:1px solid #888888;}
  .write-input li input{-webkit-appearance: none;-moz-appearance: none;-ms-appearance: none;resize: none;outline: none;border:0;width:28px;line-height: 28px;
    text-align: center;height: 28px;font-size:16px;}
  .write-phonenum .mint-button--default{background: #3b90d1;color:#fff;font-family: "微软雅黑";font-size: 14px;width:80%;margin:10px auto;}
  .realInput{
    /* Keyword values */
    -webkit-appearance: none;
    -moz-appearance: none;
    -ms-appearance: none;
    resize: none;
    outline: none;
    border: 0;
    z-index: 3;
    position: absolute;
    width: 290px;
    height: 30px;
    line-height: 30px;
    background: none;
    display: block;
    left: 50%;
    margin-left: -145px;
    top: 34px;
    opacity: 0;
    font-size: 0px;
    caret-color: #fff;
    color: #000;
    text-indent: -5em;
    font-size: 30px;
    top:1px;
  }
  input[type="tel"]:disabled{background-color: #fff;}
  html{background: #f4f4f4}
.getData_box{padding: 2rem .4rem;text-align: center;background: #f4f4f4}
  .getData_transferInValue{color: #e50039;font-size: 1.4rem}
  .getData_p{padding: .4rem;font-size: 0.45rem;color: #999}
  .getData_center{padding: .6rem .4rem;background: #fff}
  .getData_center p{display: flex;padding: .2rem;color: #999;font-size: 0.55rem}
  .getData_center p span{flex: 1}
  .getData_center_span{text-align: right;padding-right: .4rem}
  .getData_center_btn{color: #e50039;width: 90%;margin: 0 auto;text-align: center;margin-top: 2rem;border: 1px solid #e50039;height: 1.4rem;line-height: 1.4rem;border-radius: 1rem}

</style>

<template>
  <div class="container">
    <Mheader id="header_myfans">
      <div slot="title">积分转赠送</div>
    </Mheader>
    <div class="myfans_box" style="height: 10rem">
      <div class="myfans_box_top">
        <p></p>
        <p class="myfans_box_num" style="color: #fff">{{getaccountTotalData.availableAmount}}</p>
      </div>
      <div >
        <div class="page-navbar" id="page-navbar">

          <mt-navbar class="page-part" v-model="selected">
            <mt-tab-item id="1" >
                <p class="page-navbar_b"  @click="toggle"><span :class="{ 'page-navbar_img_a' : isA, 'page-navbar_img_b': !isA}" @click="toggle"></span>普通转账</p>
            </mt-tab-item>
            <mt-tab-item id="2">
              <p class="page-navbar_b"><span class="page-navbar_img2"></span>
                商家结算</p>
            </mt-tab-item>
          </mt-navbar>
          <!-- tabcontainer -->
          <mt-tab-container v-model="selected">
            <mt-tab-container-item id="1">
              <div class="Trans_box">
                <p class="Trans_box_p">手机号码</p>
                <p class="Trans_box_p2"><span><img src="../../assets/images/TransferredHome/phone_nor@2x.png" alt=""></span>
                  <input type="text" placeholder="请输入手机号" v-model="transferMobile"></p>
                <p class="Trans_box_p">转让数量</p>
                <p class="Trans_box_p2"><span><img src="../../assets/images/TransferredHome/zhuanyongjifen_@2x.png" alt="" style="width: .7rem"></span>
                  <input type="text" placeholder="请输入转让数量" v-model="integralValue"></p>
                  <b>对方将收到<span class="Trans_box_span"> {{integralValue}}</span>积分</b>
              </div>
              <div class="Trans_btn"  @click="getMake(type=1)">下一步</div>

            </mt-tab-container-item>
            <mt-tab-container-item id="2">
              <div class="Trans_box">
                <p class="Trans_box_p">商铺编号</p>
                <p class="Trans_box_p2"><span><img src="../../assets/images/TransferredHome/phone_nor@2x.png" alt=""></span>
                  <input type="text" placeholder="请输入商铺编号" v-model="transferMobile" @blur='changeCount()'></p>
                <p class="Trans_box_p">结算数量</p>
                <p class="Trans_box_p2"><span><img src="../../assets/images/TransferredHome/zhuanyongjifen_@2x.png" alt="" style="width: .7rem"></span>
                  <input type="text" placeholder="请输入结算数量" v-model="integralValue"></p>
                <b>对方将收到<span class="Trans_box_span"> {{integralValue}}</span>积分</b>
              </div>
              <div class="Trans_btn"  @click="getMake(type=2)">下一步</div>
            </mt-tab-container-item>

          </mt-tab-container>
        </div>

      </div>
    </div>








  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'

  export default {
    components: {
      Mheader,
    },
    data() {
      return {

        fansCountdata:'',
        src: require("../../assets/images/myTopromote/login_03.png"),
        fansList:[],
        selected: '1',
        isA: false,
        isNewest: true, //是否最新
        pageSize: 0, //当前页码
        isLoading: false, //是否显示加载中...
        transferMobile:'',//手机号
        integralValue:0.00,//积分数
        getMakeData:'',
        getaccountTotalData:'',
        discount:'',//商家扣点
        discountVlaue:'',
        makeTransferData:'',
      }
    },
watch:{
  integralValue(value){
    console.log(this.discount,'discount')
    this.discountVlaue=value-(this.discount*0.01)
    console.log(this.discountVlaue,'discountVlaue')
  },
},
    methods: {
      changeCount() {
        let data = {
          'body': {
            integralValue: this.integralValue,  //积分
            transferMobile: this.transferMobile, //手机号
            userType: 2
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_makeTransfer, JSON.stringify(data), {
          headers: {'content-Type': 'text/mhs-',auth:localStorage.auth}
        }).then((response) => {
          if (response.data.code == '000000') {
            this.makeTransferData=response.data.body
          this.discount=response.data.body.discount
          } else {
            Toast(response.data.message)

          }

        }).catch((error) => {

        });
      },

        getaccountTotal(){
        let data = {
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_accountTotal, JSON.stringify(data), {
          headers: {'content-Type': 'text/mhs-',auth:localStorage.auth}
        }).then((response) => {
          if (response.data.code == '000000') {
            this.getaccountTotalData=response.data.body


          } else {
            Toast(response.data.message)

          }

        }).catch((error) => {

        });
      },
      toggle: function(){
        this.isA = !this.isA;
      },
      loadMore1() {
        this.loading = true;
        this.isLoading = true;
        this.pageSize++;
        if (this.isNewest) {
          this.getFans(this.pageSize);
        }

      },
      getMake(type){
        console.log(type,type)
        if(!!!this.integralValue){
          Toast("请输入积分")
          return;
        }
        if(!!!this.transferMobile){
          Toast("请输入手机号")
          return;
        }
        let data = {
          'body': {
            integralValue: this.integralValue,  //积分
            transferMobile: this.transferMobile, //手机号
            userType: 1
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_makeTransfer, JSON.stringify(data), {
          headers: {'content-Type': 'text/mhs-',auth:localStorage.auth}
        }).then((response) => {
          if (response.data.code == '000000') {
            this.getMakeData=response.data.body
            sessionStorage.setItem("getMakeData", JSON.stringify(this.getMakeData));
            if(type==1){
              this.$router.push({
                path: '/TransferredDetails'
              });
            }else{

              sessionStorage.setItem("makeTransferData", JSON.stringify(this.makeTransferData));
              this.$router.push({
                path: '/TransferredDetailsSell'
              });
            }


          } else {
            Toast(response.data.message)
            this.$router.push({
              path: '/Login'
            });
          }

        }).catch((error) => {

        });
      },

    },
    mounted: function() {
      this.getaccountTotal()
      this.$nextTick(() => {
      })
    }
  }
</script>

<style >
  html{background: #f4f4f4}
  #page-navbar .mint-tab-item-label{font-size: 0.65rem}
  #page-navbar .is-selected{
    border-bottom: 3px solid #e50039;
    color: #e50039;
    margin-bottom: -1px;}
  .Trans_btn{color: #e50039;width: 90%;margin: 0 auto;text-align: center;margin-top: 2rem;border: 1px solid #e50039;height: 1.4rem;line-height: 1.4rem;border-radius: 1rem}
  .Trans_box b{width: 100%;display: inline-block;text-align: right;height: 1rem;line-height: 1.2rem}
  .Trans_box_span{color: #e50039;font-weight: 700;padding: 0 .4rem}
  .Trans_box_p{padding-left: .4rem;}
  .Trans_box_p2{border-bottom: 1px solid #eee;}
  .Trans_box{width: 95%;margin: 0 auto;background: #fff;padding: .4rem;border: 1px solid #fff;border-radius: .3rem;margin-top: .3rem}
  .Trans_box p{height: 2rem;line-height: 2rem;font-size: 0.6rem}
  .Trans_box img{width: 1rem;margin-bottom: .5rem}
  .Trans_box input{height: 1.8rem;line-height: 1.8rem;border: none;padding-left: .4rem;font-size: 0.6rem}
  .page-navbar_img_b{margin-bottom: -.2rem;width: 1.2rem;height: 1.2rem;line-height:1.2rem;background: url("../../assets/images/TransferredHome/mine_sel@2x.png") no-repeat;background-size: 100% 100%}
  .page-navbar_img_a{margin-bottom: -.2rem;width: 1.2rem;height: 1.2rem;line-height:1.2rem;background: url("../../assets/images/TransferredHome/mine_nor@2x.png") no-repeat;background-size: 100% 100%}
  .page-navbar_img2{margin-bottom: -.2rem;width: 1.2rem;height: 1.2rem;background: url("../../assets/images/TransferredHome/store@2x.png") no-repeat;background-size: 100% 100%}
  .is-selected
  .page-navbar_b{font-size: 0.6rem;display: inline-block;height: 1rem !important;line-height: 1rem;padding-bottom: 1rem}

  #header_myfans{background: #f04b52;font-size: 0.55rem;color: #fff}
  .myfans_box{height: 11rem;background: url("../../assets/images/myTopromote/bg@3x.png") no-repeat;font-size: 0.55rem;background-size: 100% 100%}
  .myfans_box_top{width: 50%;margin: 0 auto;text-align: center;padding-top: 3rem}
  .myfans_box_top p {padding: .4rem;padding-bottom: 1rem}
  .myfans_box_num{font-size: 1.6rem}
  .myfans_box_bottom{display: flex;text-align: center}
  .myfans_box_bottom span{flex: 1}
  .myfans_box_right{border-right: 2px solid #ffc5cd}
  .myfans_box_right p{padding: .2rem}
  .myfans_box_botm p{padding: .2rem}
  .fans_data_box{padding: .6rem;display: flex;font-size: 0.55rem;color: #999}
  .fans_data_box_img{display: inline-block;width: 2rem;height:2rem;border:1px solid #fff;border-radius: 50%}
  .fans_data_box_img img{border-radius: 50%}
  .fans_data_box-center{flex: 1}
  .fans_data_box-center p{padding: .2rem}
  .fans_data_box-bottom p{padding: .6rem}
  .dialog_span{font-size: 0.55rem}
  .dialog_span_left{width: 2rem;height: 2rem}
</style>

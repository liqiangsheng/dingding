<template>
  <div class="container">
    <Mheader>
      <div slot="title">转让成功</div>
      <!--<div slot="info" @click='saveUserInfo'>保存</div>-->
    </Mheader>
    <div>
      <div class="getData_box">
        <p class="getData_transferIn"><img src="../../assets/images/TransferredHome/success@2x.png" alt=""> </p>
        <p class="getData_pS">转让成功!</p>
        {{getSuccess.transferUserId}}
      </div>
      <div class="getData_center">
        <p>
          <span>转让积分：</span>
          <span class="getData_center_span">  {{getSuccess.amount }}积分</span>
        </p>
        <p>
          <span>交易时间：</span>
          <span class="getData_center_span">  {{getSuccess.transferTime |formatDate }}</span>
        </p>
        <p>
          <span>对方账户：</span>
          <span class="getData_center_span">  {{getSuccess.targetUserName |newtel }}</span>
        </p>

        <p>
          <span>对方收入：</span>
          <span class="getData_center_span">{{getSuccess.amount}} 积分</span>
        </p>
        <p>
          <span>订单编号：</span>
          <span class="getData_center_span">{{getSuccess.transferNo}}</span>
        </p>
      </div>
    </div>

  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  import { Field ,Indicator} from 'mint-ui';
  import { Popup } from 'mint-ui';
  import md5 from 'js-md5';
  export default {
    components: {
      Mheader,
    },
    data() {
      return {
        getSuccess:'',
        messagepacket:false,
        packets:[

        ],
        popupVisible:false,
        disInputs:[{value:''},{value:''},{value:''},{value:''},{value:''},{value:''}],
        realInput:'',
        pushShow:true
      }
    },
    methods: {
      postMe(){
        console.log(1111111)
      },

    },
    filters: {
      formatDate: function (value) {
        let date = new Date(value);
        let y = date.getFullYear();
        let MM = date.getMonth() + 1;
        MM = MM < 10 ? ('0' + MM) : MM;
        let d = date.getDate();
        d = d < 10 ? ('0' + d) : d;
        let h = date.getHours();
        h = h < 10 ? ('0' + h) : h;
        let m = date.getMinutes();
        m = m < 10 ? ('0' + m) : m;
        let s = date.getSeconds();
        s = s < 10 ? ('0' + s) : s;
        return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s;
      },
      newtel (value1) {
        if(!value1) return ''
        let value2 = value1.toString().substr(0,3)
        value1 = value1.toString().substr(-4,4)
        value1 =value2+'*'.repeat(4)+value1
        let endMember = value1.substr(-1,1)
        if(endMember % 2){
          value1 = value1
        }else{
          value1 = value1
        }
        return value1
      }
    },


    mounted: function() {
      // this.headerNav(false)
      // this.bottomShow(false)
      this.$nextTick(() => {
        this.getSuccess=JSON.parse(sessionStorage.getSuccess)
        console.log(this.getSuccess,'000')

      })
    }
  }
</script>

<style >
.getData_transferIn img{width: 3rem}
  .enter-password{
    text-align: right;
    color:#1D890D;
    font-size: 18px;
    line-height: 2;
    margin-top:20px;
    padding-right: 20px;
  }
  .phonenum-show{
    background: rgba(0,0,0,0.6);
    position: absolute;
    bottom:0;
    right:0;
    bottom:0;
    left:0;
    z-index: -1;
    margin-top: 3rem;
  }
  .getback-title span{position: absolute;right:0;top:3px;width:15px;height:15px;display: inline-block;}
  .write-phonenum-1000{
    top:-1000px!important;
  }
  .write-phonenum{

    padding:60px 10px 0;
    background: #fff;
  }
  .write-phonenum p{
    font-size: 14px;
    margin-left:30px;
    line-height:2;
  }

  .write-phonenum_p{text-align: center}
  #pwdpush-box{width: 100% !important;}
  .write-phonenum p span{color: #3b90d1;}
  .write-input {width:312px; margin:10px auto; position: relative;}
  .write-input li{float: left;width:30px;height:30px; margin: 0 10px; border:1px solid #888888;}
  .write-input li input{-webkit-appearance: none;-moz-appearance: none;-ms-appearance: none;resize: none;outline: none;border:0;width:28px;line-height: 28px;
    text-align: center;height: 28px;font-size:16px;}
  .write-phonenum .mint-button--default{background: #3b90d1;color:#fff;font-family: "微软雅黑";font-size: 14px;width:80%;margin:10px auto;}
  .realInput{
    /* Keyword values */
    -webkit-appearance: none;
    -moz-appearance: none;
    -ms-appearance: none;
    resize: none;
    outline: none;
    border: 0;
    z-index: 3;
    position: absolute;
    width: 290px;
    height: 30px;
    line-height: 30px;
    background: none;
    display: block;
    left: 50%;
    margin-left: -145px;
    top: 34px;
    opacity: 0;
    font-size: 0px;
    caret-color: #fff;
    color: #000;
    text-indent: -5em;
    font-size: 30px;
    top:1px;
  }
  input[type="tel"]:disabled{background-color: #fff;}
  html{background: #f4f4f4}
.getData_box{padding: 2rem .4rem;text-align: center;background: #f4f4f4}
  .getData_transferInValue{color: #e50039;font-size: 1.4rem}
  .getData_pS{padding: .4rem;font-size: 0.65rem;color: #999}
  .getData_center{padding: .6rem .4rem;background: #fff}
  .getData_center p{display: flex;padding: .2rem;color: #999;font-size: 0.55rem}
  .getData_center p span{flex: 1}
  .getData_center_span{text-align: right;padding-right: .4rem}
  .getData_center_btn{color: #e50039;width: 90%;margin: 0 auto;text-align: center;margin-top: 2rem;border: 1px solid #e50039;height: 1.4rem;line-height: 1.4rem;border-radius: 1rem}

</style>

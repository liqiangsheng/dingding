<template>
  <div class="container">
    <Mheader :show='true'>
      <div >
        <div class="tabs">
          <div class="navbar-item" v-for="(item, index) in tab2" @click="selecteds(index)" :key='index' :class="{isSelected:index == tabIndexs}">{{ item.tabName }}
          </div>
      </div>
      </div>
    </Mheader>

    <div class="img-box">
      <mt-swipe :auto="3000" v-if="BaseInfoBanner.length>0">
        <mt-swipe-item v-for="(item,index) in BaseInfoBanner" :key="item.index">
          <img v-lazy="imgBaseUrl+item"  style="height: 100%"/>
        </mt-swipe-item>
      </mt-swipe>
    </div>
    <div class="buy-box">
      <div class="icon">
        <div>
          <img src="../../assets/images/productDetails/kf.png" alt="">
          <a :href="getGoodsHref(seller)">联系客服</a>
          <!--<a href="tel:17324394615">联系客服</a>-->
        </div>
      </div>
      <div class="icon">
        <div >
          <router-link :to="{path:'/seller/'+seller.sellerId}">
          <img src="../../assets/images/productDetails/daodian@3x.png" alt="">店铺
          </router-link >
        </div>
      </div>
      <div class="icon">
        <div>
          <router-link to="/Cart">
            <div class="cat" v-show="isShow">
              <span v-show="isShowCat">{{totalData}}</span>
              <img  src="../../assets/images/tabBar/shop_nor@2x.png" />购物车
            </div>
          </router-link>
        </div>
      </div>
      <div class="buy-mode" @click="choice(1)" v-show="isShow" style="background: #feba4f;color: #fff;font-size: 0.55rem">加入购物车</div>
      <div class="buy-mode right_mode" @click="choice(2)">立即购买</div>
    </div>



    <!-- tab-container -->
    <div>
      <div>

      </div>
      <div  class="productDescribe">
        <div class="title">
          <div></div>
          <div class="title_stockVolume">
            <span>{{goodsInfo.goodsName}}</span>
            <span class="title_stockVolume_right"><b :class="{'bg-primary text-danger':isA,'bg-success text-white':!isA}"   @click="doSomething()" ></b></span>
          </div>
          <div >
          <p class="integral">赠送{{AttributeData.score}}积分额度</p>
          <div class="title_lm-text-red">￥{{AttributeData.appPrice}}</div>
          <div class="title_stockVolume">
            <span> <strong>库存：</strong>{{stockVolumeData}}</span>
            <span><strong>销量：</strong>{{goodsInfo.salesVolume}}</span>
            <span  class="title_stockVolume_right"> <strong>浏览量：</strong>{{AttributeData.stockVolume}}</span>


          </div>

          </div>
          <div class="lm-text-grey">{{product.SaleComment}}</div>
        </div>
        <div class="cat_box">
          <div class="cat_box_bootm"  @click="choice(1)" >规格 <span class="cat_box-span">请选择规格数量</span></div>
          <!--<div class="cat_box_bootm"  @click="choice(1)" >已选 <span class="cat_box-span">{{AttributeData.attr}}</span>{{productNum}}件</div>-->
        </div>
        <div class="cat_box">
          <div class="cat_box_bootm"  @click="choice(1)" >参数 <span class="cat_box-span">参数详情</span></div>
          <!--<div class="cat_box_bootm"  @click="choice(1)" >已选 <span class="cat_box-span">{{AttributeData.attr}}</span>{{productNum}}件</div>-->
        </div>
        <div class="cat_box">
          <div class="cat_box_bootm"   >评价 <span class="cat_box-span">(45)</span></div>
          <!--<div class="cat_box_bootm"  @click="choice(1)" >已选 <span class="cat_box-span">{{AttributeData.attr}}</span>{{productNum}}件</div>-->
        </div>
        <div class="tab">
          <div class="navbar-item " v-for="(item, index) in tab" @click="selected(index)" :key='index' :class="{isSelected:index == tabIndex}">{{ item.tabName }}
          </div>
        </div>
        <div v-if="tabIndex ==0" class="productDescribe">

          <div class="parameter" v-html="gsDetail">
          </div>
        </div>
      </div>
      <div v-if="tabIndex == 1">
        <div class="evaluate-list" v-html="gsDetail">
        </div>
      </div>
      <div v-if="tabIndex == 2">
        <div class="evaluate-list">
          <div class="evaluate" v-for="(item,index) in productDesc" :key='index'>
            <div>
              <!--<span class=" lm-text-grey">{{item.UserName}}</span>-->
            </div>
            <div class="content lm-margin-t-sm">
              {{item.Content}}
            </div>
            <div class="evaluate-time lm-margin-t-xs">
              {{item.CrateTime | formatTime}}
            </div>
          </div>
        </div>
        <div class="more-comment" v-if="productDesc.length>0">
          <span @click="loadMore">{{moreContent}}</span>
        </div>
        <div class="more-comment" v-else>
          <span>暂无评论11111</span>
        </div>
      </div>
    </div>

    <transition name="fade">
      <div class="choice-model" v-if="choiceShow" @click="choice(isCar)">

      </div>
    </transition>

    <transition name="drop">
      <div class="choice" v-if="choiceShow">
        <div class="choice-img">
          <img :src="imgBaseUrl+BaseInfoBanner[0]" alt="">
        </div>
        <div class="choice-p">
          <div>
            <div class="choice-p-price ">￥{{AttributeData.appPrice}}</div>
            <div class="del" @click="close">
              <img src="../../assets/images/productDetails/del.png" />
            </div>
          </div>
          <div>库存 {{AttributeData.stockVolume}} 件</div>
          <div>赠送积分 {{AttributeData.score}}</div>
          <div>已选:{{AttributeData.attr}}</div>
        </div>
        <div class="choice-spec">
          <!--<div>规格</div>-->
          <div class="spec-box" v-for=' (items,index) in  attrList' :key='index'>
            <div class="spec-boxName"> {{items.name}}</div>
            <div class="spec-boxName_box">
              <ul class="spec" v-for=' (item,childIndex) in  items.specList' @click="checkSpec(childIndex,index)" :key='childIndex' :class="{active:item.active}">
                <li>{{item.specName}} </li>
              </ul>
            </div>

          </div>


          <div>
            <div>
            </div>
          </div>
        </div>
        <div class="choice-num">
          <div>购买数量</div>
          <div>
            <span @click="changeNum(-1)">-</span>
            <input readonly="readonly" type="text" v-model="productNum">
            <span @click="changeNum(1)">+</span>
          </div>
        </div>

        <div class="choice-btn" @click="addCar">确定</div>
      </div>
    </transition>

  </div>
</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui';

  export default {
    components: {
      Mheader
    },
    data() {
      return {
        sel: [],
        id: [],
        totalData:'',
        tagListData:'',
        isA:true,
        isShow:true,
        isShowCat:false,
        BaseInfoData: [],
        sellerDataHome:[],//商铺的信息
        BaseInfoBanner: [], //轮播数据
        goodsInfo: [],
        stockVolumeData:'',
        skuList: [],
        seller: [], //商家信息
        productSpecData: [], //选中的数据
        productSpecId: [], //选中的id
        skuListData: [],
        AttributeData: [], //属性规格
        gsDetail: [], //详情
        appPrice: '',
        tabIndex: 0,
        tabIndexs: 0,
        choiceShow: false,
        productNum: 1,
        sc: false,
        tab: [

          {
            tabName: "-商品详情-"
          }
        ],
        tab2: [
          {
            tabName: "商品"
          },
          {
            tabName: "详情"
          },
          {
            tabName: "评价"
          }
        ],
        product: '', //商品信息
        productSpec: [], //商品sku
        productDesc: [], //商品评论
        productParams: '', //商品参数
        //评论下拉加载
        pageIndex: 1,
        pageSize: 50,
        loading: true,
        moreContent: '点击查看更多...',
        //规格参数
        checkMsg: '请选择 规格',
        specId: '',
        specName: '',
        specImg: '',
        specPrice: 0,
        specStock: 0,
        productName: '',
        productId: '',
        checkIndex: -1,
        ind: -1,
        isCar: 0,
        productSpec: [], //不知道选啥
      }
    },
    filters: {
      teaB(value) {
        return parseInt((value) * 5);
      },
      formatTime(val) {
        let date = new Date(val);
        let y = date.getFullYear();
        let m = date.getMonth() + 1;
        m = m < 10 ? ('0' + m) : m;
        let d = date.getDate();
        d = d < 10 ? ('0' + d) : d;
        let h = date.getHours();
        let minute = date.getMinutes();
        minute = minute < 10 ? ('0' + minute) : minute;
        return y + '-' + m + '-' + d;
      }
    },
    computed: {

    },
    watch:{
      totalData(val){
        if(val==0){
          this.isShowCat = !this.isShowCat;
        }else{
          this.isShowCat = true;

        }
      }
    },
    methods: {
      watchScroll () {
        var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
        //  当滚动超过 50 时，实现吸顶效果
        // console.log(scrollTop,'scrollTop')
        if (scrollTop > 49) {
          this.navBarFixed = true
        } else {
          this.navBarFixed = false
        }
      },
      menu() {
        window.scrollTo(0,0);
      },
      //拨打电话
      getGoodsHref:function(seller){
        return 'tel:'+seller.mobile
      },
      //收藏商品
      doSomething(){
      this.isA=!this.isA
        // console.log(this.isA,'0')
        if(this.isA==true){
          var  typeId=2
        }else{
          var  typeId=1
        }
        // console.log(typeId,'typeId')
        let data = {
          'body': {
            goodsId: this.$route.params.productID,
            typeId: typeId,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.Goods_gsFavoriteGoods, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            Toast('收藏成功')
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
  },
      loadMore() {
        this.pageIndex++;
        this.getProductEstimates();
      },
      selected(i) {
        this.tabIndex = i
      },
      selecteds(i){
        this.tabIndexs = i
        if( this.tabIndexs==1){
          // console.log( this.tabIndexs,' this.tabIndex')

        }
      },
      choice(val) {
        //首次点击加载sku信息
        if(this.isCar == 0) {
          this.getProductSKU();
        }
        this.isCar = val;
        this.choiceShow = !this.choiceShow
      },
      close() {
        this.choiceShow = !this.choiceShow
      },

      //获取商品轮播信息
      getProduct() {
        let data = {
          'body': {
            goodsId: this.$route.params.productID,
            typeId: 1,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.Goods_gsBaseInfo, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            // console.log(response)

            // this.tagListData=response.data.body.tagList[0]
            // console.log(this.tagListData,'tagListData')
            if(this.tagListData.type==2){
              // console.log('yinc')
              this.isShow = !this.isShow;
            }
            this.BaseInfoData = response.data.body
            this.BaseInfoBanner = response.data.body.images
            this.goodsInfo = response.data.body.goodsInfo
            this.skuList = response.data.body.skuList
            this.seller = response.data.body.seller
            this.stockVolumeData=0
            this.skuList.forEach((item) => {
              this.stockVolumeData+= item.stockVolume;
            });

            this.attrList = response.data.body.attrList; //todo
            this.attrList.forEach((data, index) => {
              this.checkSpec(0, index, 1); //第一次默认选择第一个产品，最后一个参数表示第一次，不传默认点击事件
            });

          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },

      getgsDetai() {
        let data = {
          'body': {
            goodsId: this.$route.params.productID,
            typeId: 1,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.Goods_gsDetail, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            this.gsDetail = response.data.body.detail;
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },
      getCartCounti() {
        let data = {
          // 'global': this.global
          global:{
            deviceMode: 2,
            appVersion: '2.8.8',
            appType: 1,
            userId: localStorage.uid
          }
        }

        this.axios.post(this.apiJSON.Goods_cartCount, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-',
            'auth': localStorage.auth
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            // console.log(response.data.body,'00000')
            this.totalData=response.data.body.totalQuantity
                if(this.totalData==0){
                  this.isShowCat = !this.isShowCat;
                }

            // this.gsDetail = response.data.body.detail;
          } else {

            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },

      //获取商品SKU
      getProductSKU() {
        //设置默认选中第一个
        this.checkIndex = 0;
        this.productId = this.skuList[0].goodsId;
        this.productName = this.skuList[0].ProductName;
        this.specId = this.skuList[0].specList;
        this.specName = this.skuList[0].ShortName;
        this.specImg = this.BaseInfoBanner[0];
        this.specPrice = this.skuList[0].appPrice;
        this.specStock = this.skuList[0].stockVolume;
        // this.checkMsg = '已选：' + this.skuList[0].attr;

      },
      //进入店铺
      sellerHome(seller){
        let data = {
          'body': {
            sellerId: seller.sellerId,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.Goods_sellerInfo, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            this.sellerDataHome=response.data.body
            sessionStorage.setItem("sellerDataHome", JSON.stringify(this.sellerDataHome));
            // console.log(this.sellerDataHome,'this.sellerDataHome')
            this.$router.push({
              path: '/Seller'
            })
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },

      //选中商品规格
      checkSpec(childIndex, parentIndex, first) { //todo这个地方的
        let vm = this;
        vm.attrList.forEach((data, index) => {
          if(index == parentIndex) {
            data.specList.forEach((sonData, sonIndex) => {
              if(sonIndex == childIndex) {
                vm.$set(sonData, 'active', true);
                if(!first) { //点击的数据todo
                  vm.productSpec.splice(parentIndex, 1, sonData);
                } else { //这个是第一的数据
                  vm.productSpec.push(sonData); //这个地方的是要往规格旁边插入的列表，需要遍历
                }
              } else {
                vm.$set(sonData, 'active', false);
              }

            })
          }
        });
        this.productSpecData = vm.productSpec
        this.productSpecId = []
        this.productSpecData.forEach((item) => {
          this.productSpecId.push(item.specId)
        })
        this.twoArray()
      },
      twoArray() {
        for(var i = 0; i < this.skuList.length; i++) {
          var str = this.skuList[i].specList;
          var str2 = this.productSpecId;
          if(JSON.stringify(str.sort()) === JSON.stringify(str2.sort())) {
            this.AttributeData = this.skuList[i]
            // console.log(this.AttributeData, 'AttributeData')
          } else {}

        }

      },
      //数量变化
      changeNum(val) {
        //加
        if(val > 0) {
          if(parseInt(this.productNum) < parseInt(this.AttributeData.stockVolume)) {
            this.productNum++;
          } else {
            Toast('已经加到顶啦！');
          }
        } else {
          //减
          if(parseInt(this.productNum) > 1) {
            this.productNum--;
          } else {
            Toast('已经减到底啦！');
          }
        }
      },
      //确定的加入购物车或下单
      addCar() {
        if(this.checkIndex == -1) {
          Toast('请选择商品规格');
          return;
        }

        if(!!localStorage.auth) {
          // console.log(localStorage.auth, '000')
          //验证localStorage.lut是否在登录状态
          // this.axios.get(this.url + '/api/Login/CheckLogin?str=' + localStorage.lut).then((res) => {
          //   if (res.data.Code == 500) {
          //     //验证失败 清除localStorage
          //     localStorage.removeItem('lut');
          //   }
          // })
        }
        //加入购物车
        if(this.isCar == 1) {

          if(!!localStorage.auth) {
            let data = {
              'body': {
                userId: localStorage.uid,
                goodsId: this.AttributeData.goodsId, //商品id
                quantity: this.productNum, //商品数量
                goodsName: this.goodsInfo.goodsName, //商品名称
                goodsPrice: this.AttributeData.appPrice, //商品价格
                goodsScore: this.AttributeData.score, //商品可获赠积分
                goodsPid: this.goodsInfo.goodsId, //主商品id
                goodsImg: this.BaseInfoBanner[0], //商品图片
                goodsAttrs: this.AttributeData.attr, //商品属性
                sellerId: this.seller.sellerId, //商家id
                sellerName: this.seller.sellerName, //商家名称
                sellerMobile: this.seller.mobile, //商家联系方式
                sellerImg: this.seller.sellerImage, //商家图片
                typeId: 1,
              },
              global:{
                deviceMode: 2,
                appVersion: '2.8.8',
                appType: 1,
                userId: localStorage.uid
              }
            }
            this.axios.post(this.apiJSON.Goods_addGoodsInCart, JSON.stringify(data), {
              headers: {
                'content-Type': 'text/mhs-',
                'auth': localStorage.auth
              }
            }).then((response) => {
              if(response.data.code == '000000') {
                this.choiceShow = !this.choiceShow
                Toast('添加成功')
                this.getCartCounti()
              } else {
                Toast(response.data.message)
              }

            }).catch((error) => {

            });
          } else {
            Toast('要先登录才能加入购物车！！')
            this.$router.push({
              path: '/Login'
            })
          }
        }
        //立即下单
        if(this.isCar == 2) {
          if(!!localStorage.auth) { //用户登录的时候
            //定义下单参数
            let sku = [{
              ProductId: 0,
              Name: this.goodsInfo.goodsName,
              Score: this.AttributeData.score,
              ShoppingCarId: this.AttributeData.goodsId,
              // ProductId: this.productId,
              ProductSpecId: this.specId,
              ProductName: this.specName,
              ProductCount: this.productNum,
              ProductImg: this.specImg,
              ProductName: this.AttributeData.attr,
              ProductSpecPrice: this.specPrice
            }];
            let sc = {
              productOrderId: "0",
              skus: sku
            }
            sessionStorage.setItem("pay", JSON.stringify(sc));
            // console.log(sc,'sc')
            this.$router.push({
              path: '/Payment'
            })
          } else {
            //游客身份购买
            let skus = [];
            //定义购物车商品参数
            let sku = {
              ShoppingCarId: this.productId,
              Name: this.productName,
              Score: this.score,
              ShoppingCarId: this.productId,
              ProductSpecId: this.specId,
              ShortName: this.specName,
              Count: this.productNum,
              HeadImg: this.specImg,
              SalePrice: this.specPrice,
              AllStock: this.specStock
            }
            if(!!localStorage.tourist) {
              //购物车的localStorage.tourist已经存在商品了
              let sc = JSON.parse(localStorage.tourist);
              let pro = false;
              sc.skus.forEach(function(item) {
                if(item.ProductSpecId == sku.ProductSpecId) {
                  item.Count += sku.Count; //相同的商品就增加数量
                  pro = true;
                }
              });
              if(!pro) {
                sc.skus.push(sku);
              }
              localStorage.tourist = JSON.stringify(sc);
              this.$router.push({
                path: '/cart'
              })
            } else {
              skus.push(sku);
              let sc = {
                productOrderId: "0",
                skus: skus
              }
              localStorage.setItem("tourist", JSON.stringify(sc));
              this.$router.push({
                path: '/cart'
              })
            }
          }
        }
      },
      //该商品是否收藏了
      isFavourite() {
        if(!!localStorage.lut) {
          this.axios({
            url: this.url + '/api/Product/IsFavourite',
            method: 'post',
            data: {
              productId: this.$route.params.productID
            },
            headers: {
              'Authorization': 'BasicAuth ' + localStorage.lut
            }
          }).then((res) => {
            if(!!res) {
              if(res.data.Code == 200) {
                this.sc = !this.sc
              }
            }
          })

        }
      },
      //获取商品评论
      getProductEstimates() {
        if(this.loading) {
          this.axios.post(this.url + '/api/Product/ProductEstimates', {
            productId: this.$route.params.productID,
            rows: this.pageSize,
            page: this.pageIndex
          }).then((res) => {
            if(res.data.Code == 200) {
              if(this.pageIndex == 1) {
                this.productDesc = res.data.Data.List;
              } else {
                if(res.data.Data.List.length > 0) {
                  for(let i = 0; i < res.data.Data.List.length; i++) {
                    this.productDesc.push(res.data.Data.List[i])
                  }

                } else {
                  this.loading = false;
                  this.moreContent = "已经查看了所有的评论了！！！";
                }
              }
              this.tab[2].tabName = "评论(" + res.data.Data.records + ")"
            } else {
              Toast(res.data.Data);
            }
          })
        }

      },

    },
    created(){
      this.menu();
    },
    mounted() {

      window.addEventListener('scroll', this.watchScroll)
      this.$nextTick(() => {
        document.body.scrollTop = 0;
        this.getProduct();
        this.getgsDetai()
        if(!!!localStorage.auth){

        }else{
          this.getCartCounti()

        }
        // this.getParams();
        // this.getProductEstimates();
        this.isFavourite();
      });
    },
    beforeDestroy() {

      // this.getBrowse();
    }

  }
</script>

<style>
  html{height: 100%;background: #f4f4f4}
  .container{background: #f4f4f4}
  .integral {background:#ffb554;width: 130px!important;color: #fff;padding: .2rem;border-radius: 1rem;text-align: center;font-size: 0.55rem}
  .title_lm-text-red{color: #d7083e;padding: .2rem;border-radius: 1rem;font-size: 0.75rem;font-weight: 600}
  .title_stockVolume{display: flex;padding: .2rem}
  .title_stockVolume span{padding-left: .4rem;flex: 1}
  .title_stockVolume_right{float: right;text-align: right}
  .title_stockVolume b{display: inline-block;width: 24px;height:24px}
  .title_stockVolume strong{padding-right: .4rem}
  .cat_box{width: 100%;background: #f4f4f4;font-size: 0.55rem;color: #999}
  .cat_box_top{height: 1.6rem;line-height: 1.6rem;padding-left:.5rem;background: #fff;margin-top: .5rem}
  .cat_box_bootm{height: 1.6rem;line-height: 1.6rem;padding-left:.5rem;background: #fff;margin-top: .5rem}
  .cat_box-span{margin-left: .5rem}
  span {
    display: inline-block;
    /*background-color: #fff;*/
    color: #999;
    border-radius: 4px;
    /*border:1px solid #ccc;*/
  }

  .select {
    color: #e50039
  }

  .row {
    display: inline-block;
  }

  .img-box {
    height: 13rem;
  }

  .title {
    font-size: 0.55rem;
    background-color: #fff;
  }

  /*.title>div {*/
    /*margin: 1rem 0;*/
  /*}*/

  .title .old-price {
    font-size: 0.55rem;
    margin-left: 0.2rem;
    text-decoration: line-through;
  }

  .service {
    margin: 0.4rem 0;
    padding: 0 0.4rem;
    font-size: 0.65rem;
    background-color: #fff;
  }

  .service>div {
    padding: 0.3rem 0;
  }

  .service>div:first-child {
    border-bottom: 1px solid #eee;
  }

  .service>div:last-child {
    display: flex;
  }

  .service .fw {
    padding-top: 0.1rem;
    margin-right: 0.5rem;
  }

  .service .promise>div {
    display: flex;
    align-items: center;
    margin-top: 0.1rem;
    font-size: 0.55rem;
    color: #999;
  }
  .service .promise i {
    width: 0.55rem;
    height: 0.55rem;
    margin-right: 0.1rem;
    display: inline-block;
    background-size: 100% 100%;
    background-image: url("../../assets/images/productDetails/keyi.png");
  }
.bg-primary{ background-image: url("../../assets/images/productDetails/wsc1.png");background-size: 100% 100%}
.bg-success{background-image: url("../../assets/images/productDetails/wsc2.png");background-size: 100% 100%}
.buy-box {
    font-size: 0.55rem;
    display: flex;
    position: fixed;
    z-index: 911;
    bottom: 0;
    width: 100%;
    height: 2rem;
    text-align: center;
    border-top: 1px solid #eee;
    background-color: #fff;
  }

  .buy-box .icon {
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.45rem;
    width: 20%;
    height: 100%;
    /*border-right: 1px solid #ddd;*/
  }
  .buy-box .right_mode{position: absolute;right: 0}
  .buy-box .icon img {
    margin: 0 auto 0.06rem;
    display: block;
    width: 1rem;
    height: 1rem;
  }

  .buy-box .buy-mode {
    line-height: 2rem;
    width: 20%;
    height: 100%;
  }

  .buy-box .buy-mode:last-child {
    color: #fff;
    background-color: #e8003c;
    font-size: 0.55rem;
  }

  .tab {
    width: 100%;
    font-size: 0.55rem;
    /*display: flex;*/
    align-items: center;
    background-color: #fff;
    border-bottom: 1px solid #eeeeee;
    /*margin-top: 2.4rem;*/
  }
  .tabs {
    width: 50%;
    margin: 0 auto;
    font-size: 0.55rem;
    display: flex;
    align-items: center;
    background-color: #fff;
    border-bottom: 1px solid #eeeeee;
    /*margin-top: 2.4rem;*/
  }
  .tabs>div {
    height: 1.6rem;
    line-height: 1.6rem;
    text-align: center;
    width: 18%;
    margin: 0 auto;
  }
  .tab>div {
    height: 1.6rem;
    line-height: 1.6rem;
    text-align: center;
    width: 18%;
    margin: 0 auto;
  }

  .isSelected {
    color: #e8003c !important;
    margin-bottom: 0 !important;
    border-bottom: 1px solid #e8003c !important;
  }

  .productDescribe img {
    width: 100%;
  }
  .productDescribe{position: relative}
  /*参数页*/
  .cat{position: relative}
  .cat span{position: absolute;display: inline-block;width: 24px;height: 15px;background: red;color: #fff;line-height: 11px;opacity: 0.8}
  .parameter {
    font-size: 0.65rem;
    background-color: #fff;
    /*padding: 0.4rem;*/
    min-height: 15rem;
  }

  .parameter .parameter-list {
    padding: 0.3rem 0;
    border-bottom: 1px dashed #666;
  }
  /*选择规格*/

  .choice-model {
    top: 0;
    left: 0;
    position: fixed;
    width: 100%;
    height: 100%;
    z-index: 922;
    background-color: rgba(0, 0, 0, 0.8);
  }

  .choice {
    width: 100%;
    height: 19rem;
    bottom: 0;
    position: fixed;
    padding: 0.5rem 0.5rem 0;
    z-index: 933;
    background-color: #fff;
  }

  .choice .choice-img {
    width: 5rem;
    height: 5rem;
    border-radius: 0.2rem;
    padding: 0.1rem;
    background-color: #ffffff;
    border: 1px solid #ddd;
    box-shadow: 0 0 3px #ddd;
    top: -0.8rem;
    left: 0.5rem;
    position: absolute;
  }

  .choice .choice-p {
    line-height: 1.1rem;
    padding-left: 6rem;
    height: 5.4rem;
    font-size: 0.65rem;
    border-bottom: 1px solid #eee;
    color: #999;
  }

  .choice .choice-p>div:last-child {
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }

  .choice-p .choice-p-price {
    font-weight: 600;
    color: #d81e06;
    font-size: 0.75rem;
  }

  .choice-p>div:first-child {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .choice-p .del {
    width: 1rem;
    height: 1rem;
  }

  .choice .choice-spec {
    padding: 0.5rem 0 0.7rem;
    height: 8.8rem;
    overflow: auto;
  }

  .choice-spec .spec-box {
    margin-top: 0.5rem;
    font-size: 0.55rem;
    flex-direction: row;
    flex-wrap: wrap;
  }

  .spec-boxName_box {
    display: flex;
    padding: .4rem .4rem .4rem 0;
  }

  .choice-spec .spec-box .spec {
    padding: 0.2rem;
    margin-left: 0.5rem;
    font-size: 0.5rem;
    border-radius: 0.2rem;
    margin-bottom: 0.5rem;
    background-color: #fff;
    border: 1px solid #333;
    color: #666;
  }

  .spec li {
    width: 2rem;
    text-align: center;
    padding: .2rem
  }

  .spec-boxName {
    color: #999;
    font-size: 0.65rem;
    padding-left: .4rem
  }

  .choice-spec .spec-box .spec-checked {
    color: #ffffff;
    background-color: #fff;
  }

  .choice .choice-num {
    padding: 0.8rem 0;
    border-top: 1px solid #eee;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .choice-num>div:last-child {
    display: flex;
    align-items: center;
    border-radius: 0.1rem;
    border: 1px solid #bbb;
  }

  .choice-num input {
    text-align: center;
    width: 1.8rem;
    height: 1.2rem;
    border-top: none;
    border-bottom: none;
    border-left: 1px solid #bbb;
    border-right: 1px solid #bbb;
  }

  .choice-num span {
    width: 1rem;
    text-align: center;
    line-height: 1.2rem;
    height: 1.2rem;
    padding: 0 0.4rem;
    font-size: 0.8rem;
  }

  .choice .choice-btn {
    position: absolute;
    left: 0;
    bottom: 0;
    text-align: center;
    padding: 0.6rem 0;
    color: #ffffff;
    background-color: #d81e06;
    width: 100%;
  }
  /*评价列表*/

  .evaluate-list {
    /*background-color: #ffffff;*/
  }

  .evaluate-list .evaluate {
    padding: 0.4rem;
    font-size: 0.55rem;
    border-bottom: 1px solid #eeeeee;
  }

  .evaluate>div {
    display: flex;
    align-items: center;
  }

  .evaluate>div:first-child img {
    width: 1.4rem;
    height: 1.4rem;
    border-radius: 50%;
  }
  /*.mint-swipe-item .is-active img{width: 100%;height: 100% !important;}*/
  .evaluate .content {
    line-height: 0.8rem;
  }

  .evaluate .evaluate-time {
    width: 100%;
    justify-content: flex-end;
  }

  .drop-enter-active,
  .drop-leave-active {
    transition: all .4s;
  }

  .drop-enter,
  .drop-leave-active {
    bottom: -100%;
  }

  .choice-spec .spec-box .active {
    /*background: #d81e06;*/
    border: 1px solid #d81e06;
    color: #d81e06;
  }
</style>

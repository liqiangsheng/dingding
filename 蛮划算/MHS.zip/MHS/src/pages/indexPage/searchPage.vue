<template>
	<div class="container">
		<header>
			<div class="back" @click="goBack"></div>
      <div id="select_top">
        <select name="" v-model="selected"  @change="selectName()">
          <option value="1">商品</option>
          <option value="2">商家</option>
        </select>
      </div>

			<div class="search flex-alig-center">
				<img src="../../assets/images/home/search.png" alt="搜索">
				<input type="text" placeholder="搜索你喜欢的商品" v-model="searchName" />
			</div>

			<div class="icon_search" @click="searchProducts(1)">搜索</div>

		</header>
		<div class="box" v-if="!isSearch && searchValue.length>0">
			<div class="title_host">
				<span class="lm-margin-l-xs">热门搜索</span>
			</div>
			<div class="content lm-margin-t-xs">
				<div class="keyword" v-for="(item,index) in searchValue" :key='index' @click="chkSearchValue(index)">{{item.hotName}}</div>
			</div>
		</div>

		<div class="box mode" v-if="isSearch" v-infinite-scroll="loadMore" infinite-scroll-disabled="loading" infinite-scroll-distance="10">
			<div class="mode-box">
				<Mmode v-for="(item,index) in productList" :key="item.goodsId" :index="index" :path="item.goodsId"
               :imgSrc="item.imgUrl" :productName="item.goodsName" :productPrice="item.appPrice" :productCPSDiscount="item.score">

        </Mmode>
			</div>
		</div>

    <div class="box mode" v-if="isSearch" v-infinite-scroll="loadMore" infinite-scroll-disabled="loading" infinite-scroll-distance="10">
      <div>
        <sellMmode v-for="(item,index) in sellerProductList" :key="item.sellerId" :index="index" :path="item.sellerId"
               :imgSrc="item.headIco" :productName="item.trueName" :productSale="item.sale">

        </sellMmode>
      </div>
    </div>

		<div class="box" v-if="!isSearch && recommend.length>0">
			<div class="title">
				<img src="../../assets/images/home/search_07.png" />
				<span class="lm-margin-l-xs">推荐商品</span>
			</div>
			<div class="mode-box lm-margin-t-xs">
				<Mmode v-for="(item,index) in recommend" :key="item.ProductId" :index="index" :path="item.ProductId"
               :imgSrc="item.imgUrl" :productName="item.Name" :productPrice="item.SalePrice">
        </Mmode>
			</div>
		</div>

		<!--<Mfooter :indexCurrent='true'></Mfooter>-->
	</div>
</template>

<script>
	// import Mfooter from '../../components/Mfooter'
	import Mmode from '../../components/Mode/Mmode'
  import sellMmode from '../../components/Mode/sellMmode'


	import { Toast } from 'mint-ui'

	export default {
		components: {
			// Mfooter,
			Mmode,
      sellMmode
		},
		data() {
			return {
        selected:'1',
				searchValue: [], //热搜词汇
				searchName: '', //搜索关键字
				pageIndex: 0,
				pageSize: 20,
				loading: false,
				productList: [], //搜索结果商品
        sellerProductList:[],//搜索结果商家
				isSearch: false,
				recommend: [], //推荐商品
				oldSearch: ''
			}
		},
		methods: {
      selectName(){
        console.log(this.selected,'val')
      },
			goBack() {
				window.history.go(-1)
			},
			//获取热搜词汇
			getSearchValue() {
        let data = {
          'body': {
            type: 1,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_msHot, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            console.log(response.data.body,'body')
            this.searchValue = response.data.body;
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
				// if(!!sessionStorage.SearchValue) {
				// 	this.searchValue = JSON.parse(sessionStorage.SearchValue);
				// } else {
				// 	this.axios.get(this.url + '/api/Product/GetSearchValue').then((res) => {
				// 		if(res.data.Code == 200) {
				// 			sessionStorage.setItem("SearchValue", JSON.stringify(res.data.Data));
				// 			this.searchValue = res.data.Data;
				// 		}
				// 	})
				// }

			},
			loadMore() {
				this.loading = true;
				this.pageIndex++;
				this.searchProducts(this.pageIndex);
			},
			//搜索商品
			searchProducts(val) {
        console.log(val,'val')
        if(this.selected==1){
          if(!!!this.searchName) {
            this.isSearch = false;
            return;
          }

          let data = {
            'body': {
              filter: {
                keywords:this.searchName
              },
              pageNum:val,
              pageSize:this.pageSize
            },
            'global': this.global
          }
          this.axios.post(this.apiJSON.index_gsSearchWithOrdering, JSON.stringify(data), {
            headers: {
              'content-Type': 'text/mhs-'
            }
          }).then((response) => {
            if(response.data.code == '000000') {
              this.isSearch = true;
              this.oldSearch = this.searchName;
              if(val == 1) {
                this.productList = response.data.body;
                this.loading = false;
              } else {
                if(response.data.body.length > 0) {
                  for(let i = 0; i <  response.data.body.length; i++) {
                    this.productList.push(response.data.body[i])
                    console.log(this.productList,'this.productList')
                  }
                  this.loading = false;
                } else {
                  this.loading = true;
                }
              }
            } else {
              Toast(response.data.message)
            }

          }).catch((error) => {

          });
        }else{
          if(!!!this.searchName) {
            this.isSearch = false;
            return;
          }

          let data = {
            'body': {
              keywords:this.searchName,
              pageNum:val,
              pageSize:this.pageSize
            },
            'global': this.global
          }
          this.axios.post(this.apiJSON.index_msSearchB2CStore, JSON.stringify(data), {
            headers: {
              'content-Type': 'text/mhs-'
            }
          }).then((response) => {
            if(response.data.code == '000000') {
              this.isSearch = true;
              this.oldSearch = this.searchName;
              if(val == 1) {
                console.log(11)
                this.sellerProductList = response.data.body;
                this.loading = false;
              } else {
                if(response.data.body.length > 0) {
                  for(let i = 0; i < response.data.body.length; i++) {
                    this.sellerProductList.push(response.data.body[i])
                    console.log(this.sellerProductList,'this.sellerProductList')
                  }
                  this.loading = false;
                } else {
                  this.loading = true;
                }
              }
            } else {
              Toast(response.data.message)
            }

          }).catch((error) => {

          });
        }


			},
			//获取推荐商品
			getRecommendProduct() {
				// if(!!sessionStorage.Recommend) {
				// 	this.recommend = JSON.parse(sessionStorage.Recommend);
				// } else {
				// 	this.axios.get(this.url + '/api/Product/HotProducts').then((res) => {
				// 		if(res.data.Code == 200) {
				// 			sessionStorage.setItem("Recommend", JSON.stringify(res.data.Data));
				// 			this.recommend = res.data.Data;
				// 		}
				// 	})
				// }

			},
			//热搜词点击
			chkSearchValue(idx) {
				this.searchName = this.searchValue[idx].hotName;
				console.log(this.searchName,'searchName')
				this.searchProducts();
			}
		},
		mounted() {
			this.$nextTick(() => {
				this.getSearchValue();
				this.getRecommendProduct();
			})
		}
	}
</script>

<style>
  html{background: #f4f4f4}
	header {
		position: fixed;
		top: 0;
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0 0.8rem 0 0.4rem;
		font-size: 0.75rem;
		height: 2.2rem;
		color: #fff;
    border-bottom: 1px solid #eee;
		background-color:#fff ;
	}

	.back {
		width: 1rem;
		height: 1rem;
		background-size: 100% 100%;
		background-image: url("../../assets/images/back22.png");
	}
#select_top{
  background: #fff;
  width: 46px;
  height: 40px;
  border-radius: 5px;
  position: relative;
}
  #select_top  select{
    appearance:none !important;
    border:none;
    text-align: center;
    background:none !important;
  border: none;
  outline: none;
  width: 100%;
  height: 42px;
  line-height: 40px;
  appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
  }
  #select_top:after{
    content: "";
    width: 20px;
    height: 22px;
    background: url('../../assets/images/jiantou3.png') no-repeat center;
    position: absolute;
    right:0px;
    top: 20%;
    pointer-events: none;
  }
	.search {
		padding: 0.3rem 0.4rem;
		border-radius: 0.5rem;
		background-color: #f4f4f4;
	}

	.search img {
		width: 0.6rem;
		margin-right: 0.2rem;
	}

	.search input {
		/*width: 9rem;*/
		font-size: 0.65rem;
		border: none;
    background: #f4f4f4;
	}

	.icon_search {
    color:#e50039;
		font-size: 0.65rem;
	}

	.box {
    font-size: 0.55rem;
		padding: 0.7rem 0rem 0.7rem;
	}

	.title_host {
    height: 2rem;
    padding-left: .6rem;
    background: #f4f4f4;
		display: flex;
		align-items: center;
	}

	.title_host>img {
		width: 0.8rem;
		height: 0.8rem;
	}

	.box .content {
		display: flex;
		flex-wrap: wrap;
		align-items: center;
    background: #fff;
	}

	.box .content .keyword {
    text-align: center;
    width: 30.3%;
		color: #999;
		padding: 0 0.4rem;
		margin: 0.6rem 0.4rem 0.3rem 0;
		/*border: 1px solid #888;*/
	}

	.mode-list {
		background-color: #ffffff;
	}
</style>

<template>
  <div class="container">
    <header style="z-index: 9999000">
      <div class="back" @click="goBack">
        <img src="../../assets/images/back22.png" alt="">
      </div>
      <div class="search flex-alig-center">
        <router-link to="/SearchPage">
          <img src="../../assets/images/home/987tea_search.png" alt="搜索">
          <input type="text" placeholder="" v-model="searchName"/>
        </router-link>
      </div>
      <div class="icon" @click="searchProducts(1)">搜索</div>
    </header>
    <div>
      <div class="nav_bat">
        <nav class="nav-bar">
          <div :class="{active:isNewest}" @click="newestActive">销量</div>
          <div :class="{active:isHot}" @click="hotActive">最新</div>
          <div  :class="{active:isPrice}" @click="isPriceActive">
            <!--<b :class="{Price_bg_active:isChoose}" class="Price_bg">-->
              价格
              <span style="display: inline-block;width: 0.6rem;height: 100%" @click="imgClick(imgNum++)">
                    <img :src="topUp" style="display: inline-block;width: 0.6rem;height: 0.4rem;transform: transLateY(-0.6rem)" />
              </span>
            <!--</b>-->
          </div>
          <div :class="{active:isScreening}" @click="choice(1)">筛选<span class="Price_bg_span"><img src="../../assets/images/IconDetails/order4@2x.png" alt=""></span>
            <!--@click="isScreeningActive"-->
          </div>
        </nav>
      </div>
    </div>
    <transition name="fade">
      <div class="choice-model" v-if="screeningShow" @click=" screening()">

      </div>
    </transition>

    <transition name="drop">
      <div class="choice_screening" v-if="screeningShow">
        <p>价格区间</p>
        <p><input type="text" placeholder="最低价" v-model="lowestPrice"> — <input type="text" placeholder="最高价"
                                                                                v-model="highestPrice"></p>
        <p @click=" screening_sub()" class="choice_screening_p"><span class="choice_screening_p_span">全部分类</span><span>{{listValueData}}</span>
          <img src="../../assets/images/index_home/jiantou@2x.png" alt=""></p>
        <div class="choice_screening_btn">
          <span class="reset_btn">重置</span>
          <span class="determine_btn" @click=" determine_btn()">确定</span>
        </div>
      </div>
    </transition>

    <transition name="fade">
      <div class="choice-model" v-if="screeningShow_sub" @click=" screening_sub()">

      </div>
    </transition>
    <transition name="drop">
      <div class="choice_screening" v-if="screeningShow_sub">
        <div class="dealRecord-wrap" id="dealRecord-wrap">
          <div class="title-contant" v-for="(item,index) in CategoryData ">
            <div class="title" @click="showHide(index)">
              <h3>{{item.cateName}}</h3>
              <div class="number"><i></i></div>
            </div>
            <div class="contant" ref='abc' style="height: 0">
              <ul>
                <li v-for="i in item.sub" @click="listValue(i)">
                  {{i.cateName}}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </transition>
    <div style="margin-top: 4rem">
      <div class="forum-box" v-infinite-scroll="loadMore1" infinite-scroll-disabled="loading"
           infinite-scroll-distance="10">
        <div class="box mode">
          <div class="mode-box">
            <IconDetailsMode v-for="(item,index) in DataList" :key="item.index" :index="index" :path="item.goodsId"
                             :imgUrl="item.imgUrl" :goodsName="item.goodsName" :appPrice="item.appPrice"
                             :positiveRate="item.positiveRate" er="item.commentNumber">
            </IconDetailsMode>
          </div>
        </div>
        <div class="loading" v-show="isLoading">
          <mt-spinner :type="3" color="#999"></mt-spinner>
          <span class="lm-margin-l-sm lm-text-grey">加载中...</span>
        </div>
      </div>
    </div>
    <Mfooter :indexCurrent='true'></Mfooter>
  </div>
</template>

<script>
  import Mfooter from '../../components/Mfooter'
  import IconDetailsMode from '../../components/Mode/IconDetailsMode'
  import {Toast} from 'mint-ui'
  import {Sticky} from 'vux'

  export default {
    components: {
      Mfooter,
      Sticky,
      IconDetailsMode
    },
    data() {
      return {
        imgNum:1, //图片显示判断
        topUp:"./static/img/topUp.png", //初始化图片
        isChoose : false,
        lowestPrice: '',//最低价
        highestPrice: '',//最高价
        listValueData: '',//筛选完才数据
        listValueDataId: '',
        showSpace: false,
        CategoryData: [],//分类数据
        items: [
          {v: 'qqq', allNumber: 1},
          {v: 'aaa', allNumber: 2},
          {v: 'qqq', allNumber: 3},
        ],

        screeningShow: false,
        screeningShow_sub: false,
        DataList: [], //请求数据
        targetS: {},
        Filte: {},
        isNewest: true, //是否最新
        isHot: false, //是否最热
        isPrice: false,
        ordering: 'salesvolume',
        isScreening: false,
        searchValue: [], //热搜词汇
        searchName: '', //搜索关键字
        pageIndex: 0,
        // pageSize: 20,
        isLoading: false, //是否显示加载中...
        pageSize: 0, //当前页码
        loading: false,
        productList: [], //搜索结果商品
        isSearch: false,
        recommend: [], //推荐商品
        oldSearch: '',
        uid: localStorage.getItem('uid'),
        //上下拉加载
        allLoaded: false,
        //是否自动触发上拉函数
        isAutoFill: false,
        wrapperHeight: 0,
        courrentPage: 0
      }
    },
    created() {
    },
    beforeDestroy() {
    },
    mounted() {
      this.getCategory()

      if (!!sessionStorage.target) {
        this.Filte = sessionStorage.target

      }
    },
    methods: {
      imgClick(v){ //图片显示那张
         if(v%2 === 1){
           this.topUp = "./static/img/top.png";//初始化图片
         }else if(v%2 === 0){
           this.topUp = "./static/img/up.png";//初始化图片
         }else{
           this.topUp = "./static/img/topUp.png";//初始化图片
         }
      },
      //确定搜索
      determine_btn() {
        let data = {
          'body': {
            autoParam: this.Filte,
            cateId: this.listValueDataId,
            pageNum: this.pageSize,
            pageSize: 20,
            filter: {
              price: this.lowestPrice + "," + this.highestPrice    //最高价格  与最低价格   1,20
            },
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_gsSearchWithOrdering, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if (response.data.code == '000000') {
            this.screeningShow = !this.screeningShow
            if (response.data.body.length > 0) {
              this.DataList = []
              for (let i = 0; i < response.data.body.length; i++) {
                let temp = response.data.body[i];
                this.DataList.push(temp)
                // console.log(this.DataList,'this.DataList')
              }
              this.loading = false;
            } else {
              this.isLoading = false;
              Toast("暂无数据更多")
            }
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },
      listValue(i) {
        // console.log(i,'445')
        this.screeningShow_sub = !this.screeningShow_sub
        this.listValueData = i.cateName
        this.listValueDataId = i.cateId
      },

      showHide(index) {    //点击展开收起
        // console.log(index)
        let contant = document.getElementsByClassName('contant')[index];    //这里我们通过参数index来让浏览器判断你点击的是哪一个列表
        let height = contant.getBoundingClientRect().height;    //获取页面元素的当前高度
        document.getElementsByTagName('i')[index].style.transform = !!height ? 'rotateX(0deg)' : 'rotateX(360deg)';
        if (!!height) {
          // console.log( contant.style.height,'2')

          contant.style.height = height + 'px';
          let f = document.body.offsetHeight; //强制相应dom重绘，使最新的样式得到应用
          contant.style.height = '0px';
        } else {
          contant.style.height = 'auto';
          height = contant.getBoundingClientRect().height;
          contant.style.height = '0';
          let f = document.body.offsetHeight;
          contant.style.height = height + 'px';
        }
      },

      choice() {
        this.screeningShow = !this.screeningShow


      },
      screening() {
        this.screeningShow =false
        this.screeningShow_sub = !this.screeningShow_sub

      },
      screening_sub() {
        this.screeningShow_sub = !this.screeningShow_sub

      },
      loadMore1() {
        this.loading = true;
        this.isLoading = true;
        this.pageSize++;
        if (this.isNewest) {
          this.getIconDetails(this.pageSize);
        } else if (this.isHot) {
          // this.getLatestTopic(3);
        } else {
          // this.getThemeByThemeType();
        }

      },
      newestActive() {
        this.isHot = false;
        this.isNewest = true;
        this.isPrice = false;
        this.isScreening = false;
        this.pageSize = 1; //当前页码重置为1
        this.DataList = []; //清空数据集合
        this.ordering = 'salesvolume'
        this.getIconDetails();
      },
      hotActive() {
        this.isNewest = false;
        this.isHot = true;
        this.isPrice = false;
        this.isScreening = false;
        this.pageSize = 1; //当前页码重置为1
        this.DataList = []; //清空数据集合
        this.ordering = 'uptime'
        this.getIconDetails();
      },

      isPriceActive() {
        this.isChoose = !this.isChoose
        this.isPrice = true;
        this.isHot = false;
        this.isScreening = false;
        this.pageSize = 1; //当前页码重置为1
        this.DataList = []; //清空数据集合
        this.ordering = 'price'
        this.getIconDetails();
      },
      isScreeningActive() {
        this.isPrice = false;
        this.isScreening = true;
        this.pageSize = 1; //当前页码重置为1
        this.DataList = []; //清空数据集合
        // this.getIconDetails(4);
      },

      // "body":{"pageNum":1,"filter":{},"autoParam":{"filter":{"tag":["100005"]}},"pageSize":20}}
      getIconDetails() {
        let data = {
          'body': {
            filter: {},
            autoParam: this.Filte,
            pageNum: this.pageSize,
            pageSize: 10,
            ordering: this.ordering
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_gsSearchWithOrdering, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if (response.data.code == '000000') {
            if (response.data.body.length > 0) {
              for (let i = 0; i < response.data.body.length; i++) {
                let temp = response.data.body[i];
                this.DataList.push(temp)
              }
              this.loading = false;
            } else {
              this.isLoading = false;
              Toast("暂无数据更多")
            }
            // this.DataList = response.data.body
            // console.log(this.DataList)
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },
      //分类
      getCategory() {
        let data = {
          'body': {
            typeId: 1,
            deep: 2,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.Category_gsQueryGsCategory, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if (response.data.code == '000000') {
            this.CategoryData = response.data.body
            // console.log(this.CategoryData.length,'this.CategoryData')

          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },

      goBack() {
        window.history.go(-1)
      },
      //获取热搜词汇
      getSearchValue() {
      },
      loadMore() {
        this.loading = true;
        this.pageIndex++;
        this.searchProducts(this.pageIndex);
      },
      //搜索商品

    },

  }
</script>

<style scoped>
  #dealRecord-wrap {
    margin-bottom: 100px;
    font-size: 0.55rem;
    height: 100%;
    overflow: scroll
  }

  #dealRecord-wrap .title-contant {
    overflow: hidden;
  }

  /* 这个是重点 */
  #dealRecord-wrap .title {
    height: 2rem;
    border-bottom: 1px solid #eaeaea;
    font-size: 0.55rem
  }

  /*px*/
  h3 {
    height: 24px;
    font-size: 0.55rem;
    color: #333;
    display: flex;
    align-items: center;
    float: left;;
    margin-left: 10px;
  }

  .number {
    height: 84px;
    font-size: 24px;
    color: #666;
    display: flex;
    align-items: center;
    float: right;
  }

  /*.number i{display: inline-block;width: 20px;height: 20px;background: url('../../assets/images/index_home/jiantou@2x.png');background-repeat: no-repeat;background-size: 23px 13px;background-position: right 6px center;padding-right: 35px;display: flex;align-items: center; float: right;transform:rotateX(0deg);}*/

  .contant {
    background: #fff;
    transition: height 0.5s;
  }

  /* 这个也是重点 */
  ul li {
    padding: 0 24px;
    height: 2rem;
    display: flex;
    align-items: center;
  }

  ul li:not(:last-child) {
    border-bottom: 1px solid #f6f6f6; /*px*/
  }

  .choice_screening {
    width: 80%;
    height: 100%;
    bottom: 0;
    right: 0;
    position: fixed;
    padding: 0.5rem 0rem 0;
    z-index: 9999001;
    background-color: #fff;
  }

  .choice_screening p {
    font-size: 0.58rem;
    padding: .4rem
  }

  .choice_screening input {
    width: 4rem;
    height: 1.4rem;
    border: none;
    background: #eaeaea;
    text-align: center;
    border-radius: .3rem
  }

  .choice_screening_p {
    border: 1px solid #eee;
    border-left: none;
    border-right: none;
    display: flex
  }

  .choice_screening_p_span {
    flex: 2
  }

  .choice_screening_p img {
    width: 0.7rem;
    height: 0.7rem
  }

  .choice_screening_btn {
    width: 100%;
    position: absolute;
    bottom: 0;
    display: flex;
    text-align: center;
    font-size: 0.55rem
  }

  .choice_screening_btn span {
    flex: 1;
    display: inline-block;
    height: 2rem;
    line-height: 2rem
  }

  .determine_btn {
    background: #e50039;
    color: #fff
  }

  .reset_btn {
    background: #f4f4f4
  }

  header {
    position: fixed;
    top: 0;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 1rem 0 0.4rem;
    font-size: 0.75rem;
    height: 2.4rem;
    color: #fff;
    background-color: #fff;
  }

  .nav_bat {
    width: 100%;
    position: fixed;
    top: 53px;
  }

  .nav-bar {
    font-size: 0.55rem;
    /*float: left;*/
    text-align: center;
    white-space: nowrap;
    overflow-x: scroll;
    overflow-y: hidden;
    display: flex;
    align-items: center;
    background-color: #fff;
    border: 1px solid #ececec;
    border-bottom: none;
  }

  .nav-bar .active {
    color: #ea002f;
    background-color: #fff;
  }

  .nav-bar > div {
    flex: 1;
    height: 1.8rem;
    line-height: 1.8rem;
  }

  .main-body {
    /* 加上这个才会有当数据充满整个屏幕，可以进行上拉加载更多的操作 */
    overflow: scroll;
  }
  /*;*/
  .Price_bg{display: inline-block;width:2rem;height: 1.8rem;}
  .Price_bg_active span{width: 0.6rem;height: 0.4rem;background: url("../../assets/images/IconDetails/order2@2x.png")no-repeat;background-size: 100% 100%}
  .Price_bg span{width: 0.6rem;height: 0.4rem;background: url("../../assets/images/IconDetails/order1@2x.png")no-repeat;background-size: 100% 100%}
  .Price_bg_span img{width: 0.6rem;margin-bottom: .7rem}
  .priceIcon {
    position: relative;

  }

  .priceIcon span {
    font-size: .3rem
  }

  .priceIconSpan1 {
    position: absolute;
    left: 62%;
    top: 20%
  }

  .back {
    width: 1rem;
    height: 1rem;
    background-size: 100% 100%;
    background-image: url("../../assets/images/category/back.png");
  }

  .search {
    font-size: 0.55rem;
    padding: 0.1rem 0.2rem;
    border-radius: 0.8rem;
    padding-left: 0.8rem;

    /*border: 1px solid #ececec;*/
    background-color: #f4f4f4;
  }

  .search img {
    width: 0.8rem;
  }

  .search input {
    font-size: 0.55rem;
    border: none;
    background-color: #f4f4f4;
  }

  .icon {
    font-size: 0.65rem;
  }

  .box {
    padding: 0.1rem 0.4rem;
  }

  .title {
    display: flex;
    align-items: center;
  }

  .title > img {
    width: 0.8rem;
    height: 0.8rem;
  }

  .box .content {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
  }

  .box .content .keyword {
    color: #999;
    padding: 0 0.2rem;
    margin: 0.4rem 0.4rem 0 0;
    border: 1px solid #888;
  }

  .mode-list {
    background-color: #ffffff;
  }
</style>

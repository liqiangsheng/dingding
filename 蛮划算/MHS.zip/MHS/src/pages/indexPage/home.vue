<template>
	<div class="container">
		<header class="flex-alig-center">
			<div class="more">
				<router-link to="/Category">
					<img src="../../assets/images/home/scan.png" alt="更多">
				</router-link>
			</div>
			<div class="search flex-alig-center">
				<img src="../../assets/images/home/search.png" alt="搜索">
				<router-link to="/SearchPage">
					<input type="text" class="text" placeholder="请输入需要找的商品">
				</router-link>
			</div>
			<div class="more">
				<router-link to="/MessageHome">
					<img src="../../assets/images/home/message.png" alt="更多">
				</router-link>
			</div>
		</header>
		<div class="banner">
			<mt-swipe :auto="3000" v-if="Banners.length>0">
				<mt-swipe-item v-for="(item,index) in Banners" :key="item.index">
					<img v-lazy="imgBaseUrl+item.imgUrl" @click="jump(item.pageUrl)" />
				</mt-swipe-item>
			</mt-swipe>
		</div>
		<div>
			<MIcon :Icons="Icons"></MIcon>
			<MtopLine :News="News"></MtopLine>
		</div>
		<!--<x-button type="primary">primary</x-button>-->

		<!--助农惠农-->
		<div class=" mode" style="margin-top: .3rem">
			<div class="mode-box">
				<ActivityMmode v-for="(item,index) in Spreads" :key="item.goodsId" :index="index" :path="item.goodsId" :activityImg="item.activityImg" :img="item.img" :activityName="item.activityName" :activitySubhead="item.activitySubhead" :target="item.target"></ActivityMmode>
			</div>
		</div>
		<!--新品-->
		<div class=" mode">
			<div class="mode-box">
				<ProductyMmode v-for="(item,index) in SpreadsMHS" :key="item.goodsId" :index="index" :path="item.goodsId" :activityImg="item.activityImg" :img="item.img" :activityName="item.activityName" :activitySubhead="item.activitySubhead" :target="item.target"></ProductyMmode>
			</div>
		</div>
		<!--自营专区-->
		<!--自营专区-->

		<div class="mode">
			<div class="ProprietaryMmode" @click="ProprietaryMmode(selfSuData)">
				<div class="ProprietaryMmode_top"><b>自营专区</b> <span>更多 <img src="../../assets/images/index_home/jiantou@2x.png" alt=""></span></div>
				<div> <img v-lazy="imgBaseUrl+SelfSupportBaner" /></div>
			</div>
			<div class="mode-box">
				<ProprietaryMmode v-for="(item,index) in SelfSupport" :key="item.goodsId" :index="index" :path="item.goodsId" :imgUrl="item.imgUrl" :goodsName="item.goodsName" :salesVolume="item.salesVolume" :price="item.appPrice"></ProprietaryMmode>
			</div>
		</div>

		<!--活动专区-->
		<div class="mode">
			<div class="ProprietaryMmode" @click="ProprietaryMmode(selfSuData)">
				<div class="ProprietaryMmode_top"><b>活动专题</b> <span>更多<img src="../../assets/images/index_home/jiantou@2x.png" alt=""></span></div>
				<div style="height:7rem"> <img v-lazy="imgBaseUrl+TopicBaner" /></div>
			</div>
			<div class="mode-box">
				<ActivityProjectMmode v-for="(item,index) in Topic" :key="item.goodsId" :index="index" :path="item.goodsId" :imgUrl="item.imgUrl" :goodsName="item.goodsName" :price="item.appPrice" :productSales="item.sales"></ActivityProjectMmode>
			</div>
		</div>
		<!--为你推荐-->
		<div class="forum-box" v-infinite-scroll="loadMore" infinite-scroll-disabled="loading" infinite-scroll-distance="10">
			<div class="box mode" style="margin-top: .4rem">
				<div class="title flex-alig-center">
					<b class="box_title"> 一 为你推荐 一</b>
				</div>
				<div class="mode-box">
					<RecommendMmode v-for="(item,index) in RecommendData" :key="index" :index="index" :path="item.goodsId" :imgUrl="item.imgUrl" :goodsName="item.goodsName" :appPrice="item.appPrice" :score="item.score"></RecommendMmode>
				</div>
			</div>
			<div class="loading" v-show="isLoading">
				<mt-spinner :type="3" color="#999"></mt-spinner>
				<span class="lm-margin-l-sm lm-text-grey">加载中...</span>
			</div>
		</div>
		<Mfooter :indexCurrent='true'></Mfooter>
	</div>
</template>

<script>
	// import { XButton } from 'vux'
	import Mfooter from '../../components/Mfooter'
	import MIcon from '../../components/MIcons'
	import MtopLine from '../../components/Mode/MtopLine.vue'
	import Mmode from '../../components/Mode/Mmode'
	// import Mmode from '../../components/Mmode'
	import ProprietaryMmode from '../../components/Mode/ProprietaryMmode'
	import ActivityProjectMmode from '../../components/Mode/ActivityProjectMmode'
	import ActivityMmode from '../../components/Mode/ActivityMmode'
	import RecommendMmode from '../../components/Mode/RecommendMmode'
	import ProductyMmode from '../../components/Mode/ProductyMmode'
	import { Toast } from 'mint-ui'

	export default {
		name: 'index',
		components: {
			Mfooter,
			MIcon,
			MtopLine,
			ProprietaryMmode, //自营专区
			ActivityProjectMmode, //活动专题
			ActivityMmode,
			ProductyMmode,
			RecommendMmode, //为你推荐
			Mmode,
			// XButton
		},
		data() {
			return {
				HomeDeta: [], //index首页数据
				Banners: [], //banner
				Icons: [],
				News: [],
				Spreads: [], //助农惠农
				SpreadsMHS: [], //第三项，第四项
				SelfSupport: [], //自营专区
        selfSuData:[],
				SelfSupportBaner: '', //自营专区banner
				Topic: [], //活动专区
        TopiData:[],
				TopicBaner: '', //活动专区banner
				RecommendData: [], //为你推荐
				ownTag: 'c996e6f4a4614793a42f89428eab7039',
				giftsTag: '068cf06410bd48629a01a98fd514e9bc',
				ownTea: [],
				isLoading: false, //是否显示加载中...
				pageSize: 0, //当前页码
				isNewest: true, //是否最新,
				giftsTea: [],
				pageIndex: 1,
				// pageSize: 12,
				day: 0,
				hour: 0,
				minute: 0,
				second: 0,
				flag: false,
				time: '', //好茶推荐倒计数结束时间
				key: 'MallIndexBannerImg', //banner位置key
				isShowBanner: false,
				PopularKey: 'PopularSelling', //人气热卖
				theme: '', //置顶的话题
				Popular1: '', //人气热卖1
				Popular2: '', //人气热卖2
				Popular3: '', //人气热卖3
				Popular4: '' //人气热卖4
			}
		},
		methods: {

		  //字典
      getindex_bmsGetDictVersion() {
        let data = {
          global: {
            deviceMode: '2',
            appVersion: '2.9.1',
            appType: '1'
          }
        }
        this.axios.post(this.apiJSON.index_bmsGetDicts, JSON.stringify(data), {
          headers: {'content-Type': 'text/mhs-', auth: localStorage.auth}
        }).then((response) => {
          if (response.data.code == '000000') {
            localStorage.setItem("discount", JSON.stringify(response.data.body));
          } else {
            Toast(response.data.message)

          }

        }).catch((error) => {

        });
      },
      // banner跳转
      jump(val) {
        if (!!val) {
          //this.$router.push({path: val})
          window.location.href = val;
        }
      },

      //上拉加载
      loadMore() {
        this.loading = true;
        this.isLoading = true;
        this.pageSize++;
        if (this.isNewest) {
          this.getrecommendList(1);
        } else if (this.isHot) {
          // this.getLatestTopic(3);
        } else {
          // this.getThemeByThemeType();
        }

      },
      //自营专区
      ProprietaryMmode(selfSuData) {
        let target = selfSuData.data.target.params
        console.log(target, 'ProprietaryMmode')
        sessionStorage.setItem("target", JSON.stringify(target));
        this.$router.push({
          path: '/IconDetails',
        })
      },
      //获取banner
      getBannerList() {
        let data = {
          'body': {
            typeId: 3,
            bannerType: 3,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_ssQueryBannerList, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if (response.data.code == '000000') {
            this.HomeDeta = response.data.body
            this.HomeDeta.forEach((item, index) => {
              if (item.type == 'banners') {
                this.Banners = item.data
                console.log(this.Banners)
              }
              if (item.type == 'portals') {
                this.Icons = item.data
              }
              if (item.type == 'news') {
                this.News = item.data
                // console.log(this.News)
              }
              if (item.type == 'spreads') {
                console.log(this.Spreads, '---------------')
                this.Spreads.push(item.data[0])
                this.Spreads.push(item.data[1])
                this.SpreadsMHS.push(item.data[2])
                this.SpreadsMHS.push(item.data[3])
              }
              if (item.type == 'selfSupport') {
                this.selfSuData = item
                this.SelfSupportBaner = item.data.activityImg
                this.SelfSupport = item.data.goods
                //             console.log(this.SelfSupport,'SelfSupport')
              }
              if (item.type == 'topic') {
                this.selfSuData = item
                this.TopicBaner = item.data.activityImg
                this.Topic = item.data.goods
                // console.log(this.Topic)
              }

            })
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },

      //为你推荐
      getrecommendList() {
        let data = {
          'body': {
            pageNum: this.pageSize,
            pageSize: 10,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_Recommend, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if (response.data.code == '000000') {
            if (response.data.body.result.length > 0) {
              for (let i = 0; i < response.data.body.result.length; i++) {
                let temp = response.data.body.result[i];
                this.RecommendData.push(temp)
              }
              this.loading = false;
            } else {
              this.loading = true;
            }
          } else {
            this.loading = true;
          }
        }).catch((error) => {

        });
      },

      //跳转详情页
      chkDetail(val) {
        this.$router.push({
          path: '/ProductDetails/' + val
        })
      },
    },
		mounted() {
	    // this.getindex_bmsGetDictVersion()
			this.getBannerList()
			this.getrecommendList()
		},

	}
</script>

<style scoped>
	header {
		height: 2.2rem;
		padding: 0 0.4rem;
		justify-content: space-between;
		background-color: #fff;
		position: fixed;
		width: 100%;
		top: 0;
		z-index: 9999999;
	}

	header img {
		display: block;
	}

	.logo {
		width: 4.2rem;
		height: 1rem;
	}

	.search {
		padding: 0.3rem 1rem;
		border-radius: 1rem;
		background-color: #f4f4f4;
	}

	.search img {
		width: 0.8rem;
		margin-right: 0.3rem;
	}

	.search input {
		width: 9.4rem;
		border: none;
		background: #f4f4f4;
	}

	.container {
		background: #f4f4f4
	}

	.more {
		width: 1rem;
		height: 0.9rem;
	}

	.banner {
		margin-top: 1.8rem;
		height: 7.7rem;
	}

	.promise {
		font-size: 0.5rem;
		color: #666666;
		height: 1rem;
		background-color: #fff;
		padding: 0 0.3rem;
		justify-content: space-between;
	}

	.promise>div {
		display: flex;
		align-items: center;
	}

	.promise>div>span {
		width: 0.6rem;
		height: 0.6rem;
		margin-right: 0.1rem;
		background-size: 100% 100%;
		background-image: url("../../assets/images/home/987tea_077.png");
	}

	.top-tabs {
		height: 3.6rem;
		margin: 0.4rem 0;
		padding: 0 1rem 0.6rem;
		text-align: center;
		font-size: 0.55rem;
		display: flex;
		align-items: flex-end;
		justify-content: space-between;
		background-color: #fff;
	}

	.top-tabs>div {
		display: flex;
		flex-direction: column;
		align-items: center;
	}

	.top-tabs>div img {
		width: 2.2rem;
		vertical-align: bottom;
	}

	.top-tabs>div span {
		margin-top: -0.3rem;
	}

	.box {
		padding: 0.4rem;
		margin-bottom: 0.4rem;
		font-size: 0.7rem;
		background-color: #fff;
	}

	.box_title {
		font-weight: 500;
		color: #000000;
		font-size: 0.60rem;
	}
	/*自营专区*/

	.ProprietaryMmode_top {
		width: 100%;
		padding: .2rem;
		background: #fff;
		margin-top: .4rem
	}

	.ProprietaryMmode_top b {
		font-weight: 500;
		color: #000000;
		font-size: 0.60rem
	}

	.ProprietaryMmode_top span {
		font-weight: 500;
		color: #999;
		font-size: 0.55rem;
		float: right;
		padding-right: .4rem
	}
  .ProprietaryMmode_top img{width: 0.7rem}
	/*人气热卖*/

	.box .title {
		font-weight: 400;
		font-size: 0.60rem;
		padding: 0.5rem 0 0rem;
		justify-content: center;
	}

	.hot-buy .title>span {
		margin-left: 0.4rem;
		width: 0.9rem;
		height: 0.9rem;
		background-size: 100% 100%;
		background-image: url("../../assets/images/home/987tea_01_03.png");
	}

	.hot-buy .box-block {
		padding: 0.4rem;
		border-radius: 0.3rem;
		background-color: #F4F4F4;
		background-size: 100% 100%;
	}

	.hot-buy .box-block-one {
		padding: 1rem;
		margin-bottom: 0.5rem;
		width: 100%;
		height: 5.5rem;
	}

	.box-block .box-block-title,
	.box-block .box-block-time {
		margin-bottom: 0.3rem;
	}

	.box-block .box-block-time>span {
		color: #fff;
		padding: 0.1rem;
		border-radius: 0.1rem;
		background-color: #B22328;
	}

	.box-block .rmtime {
		font-size: 0.5rem;
	}

	.box-block-two {
		height: 10rem;
	}

	.box-block-three,
	.box-block-five {
		height: 4.85rem;
	}

	.box-block-five {
		margin-top: 0.35rem;
	}

	.box-block-four,
	.box-block-two {
		width: 49%;
	}

	.box-block .xl-title {
		font-size: 0.7rem;
		color: #777777;
	}

	.box-block .buy_one {
		font-size: 0.6rem;
		color: #B22328;
	}

	.box-block .selected h1,
	.box-block .baike h1 {
		font-size: 0.7rem;
		font-weight: bold;
	}

	.box-block .selected,
	.box-block .baike {
		padding: 0.4rem;
		color: #fff;
		width: 7.4rem;
		height: 6.8rem;
		background-size: 100% 100%;
	}

	.box-block .selected {
		background-image: url("../../assets/images/home/homenew_03.gif");
	}

	.box-block .baike {
		background-image: url("../../assets/images/home/homenew_05.png");
	}
	/*人气热卖结束*/
	/*为您精选*/

	.choice .title>span {
		width: 1rem;
		height: 1rem;
		margin-right: 0.4rem;
		background-size: 100% 100%;
		background-image: url("../../assets/images/home/987tea_31.png");
	}

	.choice .small-title {
		color: #9D9D9D;
		margin-bottom: 0.8rem;
		font-size: 0.55rem;
		text-align: center;
	}

	.choice .box-block {
		padding: 0.5rem 0;
		font-size: 0.55rem;
		/*border-top: 1px solid #F5F5F5;*/
	}

	.choice .choice-text-bottom>div>span {
		width: 0.6rem;
		height: 0.6rem;
		color: #717171;
		margin-right: 0.2rem;
		background-size: 100% 100%;
	}

	.choice .choice-text-bottom>div:first-child span {
		background-image: url("../../assets/images/home/987tea_38.png");
	}

	.choice .choice-text-bottom>div:last-child span {
		background-image: url("../../assets/images/home/987tea_35.png");
	}
	/*为您精选结束*/
	/*展示模块*/

	.mode .title>span {
		margin-left: 0.4rem;
		width: 0.9rem;
		height: 0.9rem;
		background-size: 100% 100%;
		background-image: url("../../assets/images/home/987tea_01_03.png");
	}
</style>

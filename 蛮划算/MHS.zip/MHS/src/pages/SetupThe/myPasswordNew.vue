<template>
  <div class="container">
    <Mheader :show='true'>
      <div slot="title">修改密码</div>
      <!--<div slot="info" @click='saveUserInfo'>保存</div>-->
    </Mheader>


      <form class="loginForm">
        <section class="input_container">
          <div class="input_text  ">
            <div class="input_box">
              <img src="../../assets/images/SetupThe/yanzhenma@2x.png" />
              <input type="text" placeholder="请输入原始密码" v-model.lazy="number" >
            </div>
            <div class="input_box">
              <img src="../../assets/images/SetupThe/yanzhenma@2x.png" />
              <input type="text" placeholder="请输入新密码" v-model.lazy="number" >
            </div>
            <div class="input_box">
              <img src="../../assets/images/SetupThe/yanzhenma@2x.png" />
              <input type="text" placeholder="请输入确定新密码" v-model.lazy="number" >
            </div>
          </div>
        </section>
      </form>

    <div class="login-btn" @click="login">下一步</div>

  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  import axios from 'axios';

  export default {
    components: {
      Mheader,
    },
    data() {
      return {
        mhsData:"",
        number:'',
        mtdisabled:false,
        timerCodeMsg: '获取验证码',
      }
    },
    methods: {
      sendCodePowd() { //发送短信验证码
        if(!!!this.mhsData.mobile) {
          Toast('手机号不能为空');
          return;
        }
        let data = {
          'body': {
            mobile: this.mhsData.mobile,
            type:'2'
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_smsSend, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-',
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            this.timeOut();
            this.mtdisabled=true
          } else {
            Toast(response.data.message)
          }
        }).catch((error) => {
          Toast(response.data.message)
        });

      },
      timeOut() { //倒计时
        let self = this;
        let sec = 80;
        for(let i = 0; i <= 80; i++) {
          window.setTimeout(function() {
            if(sec != 0) {
              self.timerCodeMsg = sec + "秒";
              sec--;
            } else {
              sec = 80; //如果倒计时结束就让重新获取验证码显示出来
              self.timerCodeMsg = "获取验证码";
              self.mtdisabled = false
            }
          }, i * 1000)
        }
      },

      login() {
        this.$router.push({
          path: '/myPasswordNew'
        });
        // let data = {
        //   'body': {
        //     userName: this.userName,
        //   },
        //   'global': this.global
        // }
        // axios.post(this.apiJSON.index_info, JSON.stringify(data), {
        //   headers: {
        //     'content-Type': 'text/mhs-'
        //   }
        // }).then((response) => {
        //   if(response.data.code == '000000') {
        //     Toast('登录成功')
        //     this.$router.push({
        //       path: '/MyHome'
        //     });
        //
        //   } else {
        //     Toast(response.data.message)
        //   }
        //
        // }).catch((error) => {
        //   Toast(response.data.message)
        // });
      },
    },
    mounted: function() {
      this.$nextTick(() => {
        this.mhsData=JSON.parse(localStorage.mhsData)
        console.log(this.mhsData,'000')

      })
    }
  }
</script>

<style >
  .setHome{height: 100%;background-color:#f4f4f4 ;overflow: hidden}
  .avatar {
    position: relative;
    display: flex;
    /*flex-direction: column;*/
    align-items: center;
    justify-content: center;
    color: #999;
    padding: 1.2rem 0;
    margin-top:1rem;
    margin-bottom: 1rem;
  }
  .setHomeMobile{width: 100%;text-align: center;height: 4rem;line-height: 4rem;background: #f4f4f4}
  .avatar_left{flex: 0.8}
  .avatar_right>img {
    width: 2rem;
    height: 2rem;
    border-radius: 50%;
  }
  .login-btn {
    margin: 7rem 0.6rem;
    text-align: center;
    color: #fff;
    padding: 0.3rem 0;
    border-radius: 0.8rem;
    font-size: 0.75rem;
    background-color: #e60039;
  }
  .avatar_right .upImg {
    height: 2rem;
    width: 2rem;
    position: absolute;
    top: 1.2rem;
    left: 85%;
    transform: translateX(-50%);
    opacity: 0;
  }
  .cont {
    margin-top: 1.8rem;
    height: 100vh;
    background-color: #f4f4f4;
  }

  .box {
    font-size: 0.7rem;
  }

  .box .login-box {
    /*padding: 0 .5em 1rem;*/
  }

  .box .login {
    height: 7rem;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .box .login>img {
    margin: 0 auto;
    width: 3.5rem;
    height: 3.3rem;
  }

  .class-a {
    background: url("../../assets/images/login&register/pad2.png") no-repeat;
    background-size: 100%
  }

  .class-b {
    background: url("../../assets/images/login&register/pad1.png") no-repeat;
    background-size: 100%
  }

  .loginForm {
    background: #fff;
    margin-bottom: .2rem;
  }
  .input_code{display: flex;line-height: 1.6rem;}
  .input_code1{flex: 2 }
  .input_code2{flex: 1;text-align: center;color: #e60039;font-size: 0.60rem;height: 1.6rem;border-left: 1px solid #eaeaea;margin-top: 0.09rem}
  .input_container input {
    border: none;
    width: 86%;
    height: 1rem;
    line-height: 1rem;
    background: #fff;
    padding-left: .5rem
  }

  .input_container {
    width: 100%
  }

  .input_box {
    border-bottom: 0.5px solid #eaeaea;
    position: relative;
    height: 2rem;
    line-height: 2rem;
    padding: 0 .6rem
  }

  .input_box span {
    position: absolute;
    top: 30%;
    right: 4%;
    display: inline-block;
    width: 30px;
    height: 40px
  }

  .input_box img {
    width: 1rem;
    height: 1rem;
    margin-bottom: .4rem
  }

  .input_text b {
    display: inline-block;
    width: 20px;
    height: 27px;
    margin-bottom: -8px
  }

  .input_password {
    border-bottom: none
  }

  .input_password b {
    display: inline-block;
    width: 20px;
    height: 27px;
    margin-bottom: -8px
  }
  #infoHomeup img{width: 1rem}
  #infoHomeup span{;display:inline-block;padding-left: .4rem}
  .infoHome_text{margin-right: 1rem}
  #infoHomeup .mint-cell-wrapper{ background-size: 100% 0 !important;border-bottom: 1px solid #efefef}
</style>

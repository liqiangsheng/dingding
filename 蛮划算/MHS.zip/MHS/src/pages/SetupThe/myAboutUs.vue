<template>
  <div class="container">
    <Mheader>
      <div slot="title">关于我们</div>
      <!--<div slot="info" @click='saveUserInfo'>保存</div>-->
    </Mheader>
    <div class="login">
      <img src="../../assets/images/login&register/mhs_logo.png" />
    </div>
    <p class="login_p">当前版本V2.8.72</p>

    <div id="infoHome">
      <mt-cell title="蛮划算公众号">
        <span  class="infoHome_text">蛮划算商城</span>

      </mt-cell>
      <mt-cell title="企业官网">
        <span  class="infoHome_text">www.mhsapp.com</span>

      </mt-cell>

      <mt-cell title=" 服务热线">
        <span  class="infoHome_text">400-178-0098</span>

      </mt-cell>

    </div>
  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  export default {
    components: {
      Mheader,
    },
    data() {
      return {
        mhsData:"",
      }
    },
    methods: {


    },
    mounted: function() {
      this.$nextTick(() => {
        this.mhsData=JSON.parse(localStorage.mhsData)
        console.log(this.mhsData,'000')

      })
    }
  }
</script>

<style >
  html{height: 100%;background: #f4f4f4}
 .login {
   background: #f4f4f4;
    height: 5rem;
    display: flex;
    align-items: center;
    justify-content: center;
  }

   .login>img {
    margin: 0 auto;
    width: 3.5rem;
    height: 3.3rem;
  }
   .login_p{text-align: center;background: #f4f4f4;padding-bottom: .4rem}
  .setHome{height: 100%;background-color:#f4f4f4 ;overflow: hidden}

  .avatar_left{flex: 0.8}
  .avatar_right>img {
    width: 2rem;
    height: 2rem;
    border-radius: 50%;
  }
  .avatar_right .upImg {
    height: 2rem;
    width: 2rem;
    position: absolute;
    top: 1.2rem;
    left: 85%;
    transform: translateX(-50%);
    opacity: 0;
  }

  #infoHomeup img{width: 1rem}
  #infoHomeup span{;display:inline-block;padding-left: .4rem}
  .infoHome_text{margin-right: 1rem}
  #infoHomeup .mint-cell-wrapper{ background-size: 100% 0 !important;border-bottom: 1px solid #efefef}
</style>

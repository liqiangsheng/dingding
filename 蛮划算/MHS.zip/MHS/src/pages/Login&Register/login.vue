<template>
	<div class="cont">
		<Mheader :show='true'>
			<h1 slot="title">登录</h1>
		</Mheader>
		<div class="box">
			<div class="login">
				<img src="../../assets/images/login&register/mhs_logo.png" />
			</div>
			<div class="login-box">

				<form class="loginForm">
					<section class="input_container">
						<div class="input_text input_box">
							<b :class="{ 'class-uesrA': uesrInputA, 'class-uesrB': uesrInputB}"></b>
							<input type="text" placeholder="账号" v-model.lazy="userName" @focus='uesrI($event)' @blur="uesrIdone($event)">
						</div>
					</section>
					<section class="input_container input_p">
						<div class="input_password input_box">
							<b :class="{ 'class-passA': passUesrInputA, 'class-passB': passUesrInputB}"></b>
							<input v-if="!showPassword" type="password" placeholder="密码" v-model="userPwd" @focus='passI($event)' @blur="passIdone($event)">
							<input v-else type="text" placeholder="密码" v-model="userPwd">
							<span @click="changePassWordType" class="" :class="{ 'class-a': padImgA, 'class-b': padImgB}"></span>
						</div>
					</section>

				</form>
				<div class="checkbox-box">
					<span @click="checkboxBox" :class="{ 'checkboxBox-a': checkboxBoxA, 'checkboxBox-b': checkboxBoxB}"></span>
					<label for="male">记住密码</label>
				</div>
				<!--<mt-field   placeholder="请输入手机号" type="tel" v-model="userName"></mt-field>-->
				<!--<mt-field   placeholder="请输入密码" type="password" v-model="password"></mt-field>-->

				<div class="login-btn" @click="login">登录</div>
				<div class="methods">

					<div class="m-pswd">
						<router-link :to="{path:'/ResetPassword'}">
							<!--<img src="../../assets/images/login&register/password.png" />-->
							<span>忘记密码？</span>
						</router-link>
					</div>
					<div class="m-phone">
						<router-link :to="{path:'/Register'}">
							<!--<img src="../../assets/images/login&register/phone.png" />-->
							没有账号？ <span>立即注册</span>
						</router-link>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import Mheader from '../../components/Mheader'
	import Mdialog from '../../components/Mdialog'
	import axios from 'axios';
	//import { MessageBox } from 'mint-ui';
	import md5 from 'js-md5';
	import { Toast } from 'mint-ui';
	import { Checklist } from 'mint-ui';

	export default {
		components: {
			Mheader,
			Mdialog
		},
		data() {
			return {
				userName: null,
				userPwd: null, //密码
				showPassword: false, // 是否显示密码
				padImgA: true,
				padImgB: false,
				uesrInputA: true,
				uesrInputB: false,
				passUesrInputA: true,
				passUesrInputB: false,
				checkboxBoxA: true,
				checkboxBoxB: false,

				Img: [{
					padImg: require('../../assets/images/login&register/pad2.png'),
				}],
				padImg: require('../../assets/images/login&register/pad2.png'),
				padImg1: require('../../assets/images/login&register/pad1.png'),
			}
		},
		methods: {
			checkboxBox() {
				this.checkboxBoxA = !this.checkboxBoxA;
				this.checkboxBoxB = !this.checkboxBoxB;
			},
			changePassWordType() {
				this.showPassword = !this.showPassword;
				this.padImgA = !this.padImgA;
				this.padImgB = !this.padImgB;
			},
			uesrI($event) {
				this.uesrInputA = !this.uesrInputA;
				this.uesrInputB = !this.uesrInputB;

			},
			uesrIdone($event) {
				this.uesrInputA = !this.uesrInputA;
				this.uesrInputB = !this.uesrInputB;
			},

			passI($event) {
				this.passUesrInputA = !this.passUesrInputA;
				this.passUesrInputB = !this.passUesrInputB;
			},
			passIdone($event) {
				this.passUesrInputA = !this.passUesrInputA;
				this.passUesrInputB = !this.passUesrInputB;

			},

			login() {
				if(!!!this.userName) {
					Toast('手机号不能为空');
					return;
				}
				if(!this.isPhoneNo(this.userName)) {
					Toast('手机号格式不正确');
					return;
				}
				if(!!!this.userPwd) {
					Toast('密码不能为空');
					return;
				}
				if(this.userPwd.length < 6 || this.userPwd.length > 12) {
					Toast('密码的长度在6-12位之间');
					return;
				}
				if(!this.verifyPassword(this.userPwd)) {
					Toast('密码的格式错误');
					return;
				}
				let data = {
					'body': {
						userName: this.userName,
						userPwd: md5(this.userPwd),
					},
					'global': this.global
				}
				axios.post(this.apiJSON.index_info, JSON.stringify(data), {
					headers: {
						'content-Type': 'text/mhs-'
					}
				}).then((response) => {
					if(response.data.code == '000000') {
						Toast('登录成功')
						this.$router.push({
							path: '/MyHome'
						});
            localStorage.setItem("mhsData", JSON.stringify(response.data.body));
						localStorage.setItem("auth", response.data.body.auth);
						localStorage.setItem("mobile", response.data.body.mobile);
						localStorage.setItem("uid", response.data.body.uid);
						localStorage.setItem("headIco", response.data.body.headIco);
            // window.location.reload();
					} else {
						Toast(response.data.message)
					}

				}).catch((error) => {
					Toast(response.data.message)
				});
			},

			isPhoneNo(userName) { //手机号验证
				var pattern = /^1[34578]\d{9}$/;
				return pattern.test(userName);
			},
			verifyPassword(pwd) { //密码验证
				let pattern = /^[A-Za-z_0-9]{6,16}$/;
				return pattern.test(pwd);
			}

		}
	}
</script>

<style scoped>
	.cont {
		margin-top: 1.8rem;
		height: 100vh;
		background-color: #f4f4f4;
	}

	.box {
		font-size: 0.7rem;
	}

	.box .login-box {
		/*padding: 0 .5em 1rem;*/
	}

	.box .login {
		height: 7rem;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.box .login>img {
		margin: 0 auto;
		width: 3.5rem;
		height: 3.3rem;
	}

	.class-a {
		background: url("../../assets/images/login&register/pad2.png") no-repeat;
		background-size: 100%
	}

	.class-b {
		background: url("../../assets/images/login&register/pad1.png") no-repeat;
		background-size: 100%
	}

	.loginForm {
		background: #fff;
	}

	.input_container input {
		border: none;
		width: 86%;
		height: 1rem;
		line-height: 1rem;
		background: #fff;
		padding-left: .5rem
	}

	.input_container {
		width: 100%
	}

	.input_box {
		border-bottom: 0.5px solid #eaeaea;
		position: relative;
		height: 2rem;
		line-height: 2rem;
		padding: 0 .6rem
	}

	.input_box span {
		position: absolute;
		top: 30%;
		right: 4%;
		display: inline-block;
		width: 30px;
		height: 40px
	}

	.input_box img {
		width: 1rem;
		height: 1rem;
		margin-bottom: .4rem
	}

	.input_text b {
		display: inline-block;
		width: 20px;
		height: 27px;
		margin-bottom: -8px
	}

	.input_password {
		border-bottom: none
	}

	.input_password b {
		display: inline-block;
		width: 20px;
		height: 27px;
		margin-bottom: -8px
	}

	.class-uesrB {
		background: url("../../assets/images/login&register/userName1.png") no-repeat;
		background-size: 100%
	}

	.class-uesrA {
		background: url("../../assets/images/login&register/userName2.png") no-repeat;
		background-size: 100%
	}

	.class-passA {
		background: url("../../assets/images/login&register/password2.png") no-repeat;
		background-size: 100%
	}

	.class-passB {
		background: url("../../assets/images/login&register/password1.png") no-repeat;
		background-size: 100%
	}

	.checkboxBox-a {
		background: url("../../assets/images/login&register/chebox3.png") no-repeat;
		background-size: 100%;
		margin-bottom: -4px
	}

	.checkboxBox-b {
		background: url("../../assets/images/login&register/chebox.png") no-repeat;
		background-size: 100%;
		margin-bottom: -4px
	}

	.wrapper {
		margin-bottom: 10px;
	}

	.checkbox-box {
		padding-left: .6rem;
		margin-top: 1rem
	}

	.checkbox-box span {
		display: inline-block;
		width: 24px;
		height: 22px;
	}

	.box .login-box .login-btn {
		margin: 0.6rem;
		text-align: center;
		color: #fff;
		padding: 0.2rem 0;
		border-radius: 0.8rem;
		font-size: 0.75rem;
		background-color: #e60039;
	}

	.methods {
		margin: 0.6rem;
		font-size: 0.65rem;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.methods a {
		display: flex;
		align-items: center;
	}

	.methods a>img {
		margin-right: 0.2rem;
		width: 0.7rem;
		height: 0.7rem;
	}

	.methods .m-msg a>img {
		width: 0.9rem;
		height: 0.9rem;
	}
</style>

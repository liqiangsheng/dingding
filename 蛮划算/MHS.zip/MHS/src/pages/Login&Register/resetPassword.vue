<template>
  <div class="cont">
    <Mheader :show='true'>
      <h1 slot="title">忘记密码</h1>
    </Mheader>
    <div class="box">
      <div class="login">
        <img src="../../assets/images/login&register/mhs_logo.png" />
      </div>
      <div class="login-box">

        <form class="loginForm">
          <section class="input_container">
            <div class="input_text input_box">
              <b :class="{ 'class-uesrA': uesrInputA, 'class-uesrB': uesrInputB}"></b>
              <input type="text" placeholder="请输入手机号" v-model.lazy="mobile" @focus='uesrI($event)' @blur="uesrIdone($event)">
            </div>
          </section>
          <section class="input_container">
            <div class="input_text input_box input_code">
              <div class="input_code1">
                <b :class="{ 'class-codeA': uesrInputA, 'class-codeB': uesrInputB}"></b>
                <input type="text" placeholder="请输入验证码" v-model.lazy="number" >
              </div>
              <div class="input_code2">
                <div  @click="sendCodePowd" class="pawod">
                  <mt-button  :disabled="mtdisabled" style="background: #fff;box-shadow: none;color: #e60039">{{timerCodeMsg}}</mt-button>
                </div>
              </div>
            </div>

          </section>
          <section class="input_container input_p">
            <div class="input_password input_box">
              <b :class="{ 'class-passA': passUesrInputA, 'class-passB': passUesrInputB}"></b>
              <input v-if="!showPassword" type="password" placeholder="密码" v-model="password" @focus='passI($event)' @blur="passIdone($event)">
              <input v-else type="text" placeholder="密码" v-model="password">
              <span @click="changePassWordType" class="" :class="{ 'class-a': padImgA, 'class-b': padImgB}"></span>
            </div>
          </section>

        </form>
        <div class="login-btn" @click="restPwd">完成</div>
      </div>
    </div>
  </div>
</template>

<script>
  import Mheader from '../../components/Mheader'
  import Mdialog from '../../components/Mdialog'
  import axios from 'axios';
  //import { MessageBox } from 'mint-ui';
  import md5 from 'js-md5';
  import { Toast } from 'mint-ui';
  import { Checklist } from 'mint-ui';

  export default {
    components: {
      Mheader,
      Mdialog
    },
    data() {
      return {
        mobile: null,
        number: null,
        password: null,
        imgNumber: null,
        verifyCode: null,
        vcBool: true,
        timerCodeMsg: '获取验证码',
        fetchCodeMsg: true,
        mtdisabled:false,
        userName: null,
        userPwd: null, //密码
        showPassword: false, // 是否显示密码
        padImgA: true,
        padImgB: false,
        uesrInputA: true,
        uesrInputB: false,
        codeInputA: true,
        codeInputB: false,
        passUesrInputA: true,
        passUesrInputB: false,

        Img: [{
          padImg: require('../../assets/images/login&register/pad2.png'),
        }],
        padImg: require('../../assets/images/login&register/pad2.png'),
        padImg1: require('../../assets/images/login&register/pad1.png'),
      }
    },
    methods: {
      changePassWordType() {
        this.showPassword = !this.showPassword;
        this.padImgA = !this.padImgA;
        this.padImgB = !this.padImgB;
      },
      uesrI($event) {
        this.uesrInputA = !this.uesrInputA;
        this.uesrInputB = !this.uesrInputB;

      },
      uesrIdone($event) {
        this.uesrInputA = !this.uesrInputA;
        this.uesrInputB = !this.uesrInputB;
      },
      codeI($event) {
        this.codeInputA = !this.codeInputA;
        this.codeInputB = !this.codeInputB;

      },
      codeIdone($event) {
        this.codeInputA = !this.codeInputA;
        this.codeInputB = !this.codeInputB;
      },

      passI($event) {
        this.passUesrInputA = !this.passUesrInputA;
        this.passUesrInputB = !this.passUesrInputB;
      },
      passIdone($event) {
        this.passUesrInputA = !this.passUesrInputA;
        this.passUesrInputB = !this.passUesrInputB;

      },

      sendCodePowd() { //发送短信验证码
        if(!!!this.mobile) {
          Toast('手机号不能为空');
          return;
        }
        if(!this.isPhoneNo(this.mobile)) {
          Toast('手机号格式不正确');
          return;
        }

        let data = {
          'body': {
            mobile: this.mobile,
            type:'2'
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_smsSend, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-',
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            this.timeOut();
            this.mtdisabled=true
          } else {
            Toast(response.data.message)
          }
        }).catch((error) => {
          Toast(response.data.message)
        });

      },
      isPhoneNo(phone) { //手机号验证
        var pattern = /^1[34578]\d{9}$/;
        return pattern.test(phone);
      },
      verifyPassword(pwd) { //密码验证
        let pattern = /^[A-Za-z_0-9]{6,16}$/;
        return pattern.test(pwd);
      },
      timeOut() { //倒计时
        let self = this;
        let sec = 80;
        for(let i = 0; i <= 80; i++) {
          window.setTimeout(function() {
            if(sec != 0) {
              self.timerCodeMsg = sec + "秒";
              sec--;
            } else {
              sec = 80; //如果倒计时结束就让重新获取验证码显示出来
              self.timerCodeMsg = "获取验证码";
              self.mtdisabled = false
            }
          }, i * 1000)
        }
      },
      restPwd() { //重置密码
        if(!!!this.mobile) {
          Toast('手机号不能为空');
          return;
        }
        if(!this.isPhoneNo(this.mobile)) {
          Toast('手机号格式不正确');
          return;
        }
        if(!!!this.number) {
          Toast('验证码不能为空');
          return;
        }
        if(this.number.length != 4) {
          Toast('验证码格式不正确');
          return;
        }
        if(!!!this.password) {
          Toast('密码不能为空');
          return;
        }
        if(this.password.length < 6 || this.password.length > 12) {
          Toast('密码的长度在6-12位之间');
          return;
        }
        if(!this.verifyPassword(this.password)) {
          Toast('密码的格式错误');
          return;
        }
        let data = {
          'body': {
            userName:this.mobile,//手机号
            passwordNew:md5(this.password),  //密码
            verificationCode:this.number,//验证码
            type:'2'
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_usModifyPwd, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-',
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            let instance = Toast('修改成功');
            setTimeout(() => {
              instance.close();
              this.$router.push({
                path: '/login'
              })
            }, 1000);
          } else {
            Toast(response.data.message)
          }
        }).catch((error) => {
          Toast(response.data.message)
        });
      },

      chkVCode() {
        if(!!!this.imgNumber) {
          Toast('请输入图片中的字符');
          return;
        }
        if(this.imgNumber.length != 4) {
          Toast('输入的字符长度不对');
          return;
        }
        let strs = this.verifyCode.split('/');
        let imgName = strs[strs.length - 1];
        this.axios.post(this.url + '/api/Login/CheckVCode', {
          vCode: this.imgNumber,
          token: this.vcToken,
          imgName: imgName
        }).then((res) => {
          if(res.data.Code == 200) {
            this.vcBool = false;
            this.fetchCodeMsg = false;
          } else {
            Toast(res.data.Data);
          }
        }).catch((err) => {
          Toast('网络请求超时');
        })
      }



    }
  }
</script>

<style scoped>
  .cont {
    margin-top: 1.8rem;
    height: 100vh;
    background-color: #f4f4f4;
  }

  .box {
    font-size: 0.7rem;
  }

  .box .login-box {
    /*padding: 0 .5em 1rem;*/
  }

  .box .login {
    height: 7rem;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .box .login>img {
    margin: 0 auto;
    width: 3.5rem;
    height: 3.3rem;
  }

  .class-a {
    background: url("../../assets/images/login&register/pad2.png") no-repeat;
    background-size: 100%
  }

  .class-b {
    background: url("../../assets/images/login&register/pad1.png") no-repeat;
    background-size: 100%
  }

  .loginForm {
    background: #fff;
  }
  .input_code{display: flex;line-height: 1.6rem}
  .input_code1{flex: 2 ;}
  .input_code2{flex: 1;text-align: center;color: #e60039;font-size: 0.60rem;height: 1.6rem;border-left: 1px solid #eaeaea;margin-top: 0.09rem}
  .input_container input {
    border: none;
    width: 86%;
    height: 1rem;
    line-height: 1rem;
    background: #fff;
    padding-left: .5rem
  }

  .input_container {
    width: 100%
  }

  .input_box {
    border-bottom: 0.5px solid #eaeaea;
    position: relative;
    height: 2rem;
    line-height: 2rem;
    padding: 0 .6rem
  }

  .input_box span {
    position: absolute;
    top: 30%;
    right: 4%;
    display: inline-block;
    width: 30px;
    height: 40px
  }

  .input_box img {
    width: 1rem;
    height: 1rem;
    margin-bottom: .4rem
  }

  .input_text b {
    display: inline-block;
    width: 20px;
    height: 27px;
    margin-bottom: -8px
  }

  .input_password {
    border-bottom: none
  }

  .input_password b {
    display: inline-block;
    width: 20px;
    height: 27px;
    margin-bottom: -8px
  }

  .class-uesrB {
    background: url("../../assets/images/login&register/userName1.png") no-repeat;
    background-size: 100%
  }

  .class-uesrA {
    background: url("../../assets/images/login&register/userName2.png") no-repeat;
    background-size: 100%
  }
  .class-codeA {
    background: url("../../assets/images/login&register/userName1.png") no-repeat;
    background-size: 100%
  }

  .class-codeB {
    background: url("../../assets/images/login&register/userName2.png") no-repeat;
    background-size: 100%
  }
  .class-passA {
    background: url("../../assets/images/login&register/password2.png") no-repeat;
    background-size: 100%
  }

  .class-passB {
    background: url("../../assets/images/login&register/password1.png") no-repeat;
    background-size: 100%
  }

  .checkboxBox-a {
    background: url("../../assets/images/login&register/chebox3.png") no-repeat;
    background-size: 100%;
    margin-bottom: -4px
  }

  .checkboxBox-b {
    background: url("../../assets/images/login&register/chebox.png") no-repeat;
    background-size: 100%;
    margin-bottom: -4px
  }

  .wrapper {
    margin-bottom: 10px;
  }

  .checkbox-box {
    padding-left: .6rem;
    margin-top: 1rem
  }

  .checkbox-box span {
    display: inline-block;
    width: 24px;
    height: 22px;
  }

  .box .login-box .login-btn {
    margin: 0.6rem;
    text-align: center;
    color: #fff;
    padding: 0.2rem 0;
    border-radius: 0.8rem;
    font-size: 0.75rem;
    background-color: #e60039;
  }

  .methods {
    margin: 0.6rem;
    font-size: 0.65rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .methods a {
    display: flex;
    align-items: center;
  }

  .methods a>img {
    margin-right: 0.2rem;
    width: 0.7rem;
    height: 0.7rem;
  }

  .methods .m-msg a>img {
    width: 0.9rem;
    height: 0.9rem;
  }
</style>

<template>
  <div class="cont">
    <Mheader :show='true'>
      <h1 slot="title">注册</h1>
    </Mheader>
    <div class="box">
      <div class="login">
        <img src="../../assets/images/login&register/mhs_logo.png" />
      </div>
      <div class="login-box">

        <form class="loginForm">
          <section class="input_container">
            <div class="input_text input_box">
              <b :class="{ 'class-uesrA': uesrInputA, 'class-uesrB': uesrInputB}"></b>
              <input type="text" placeholder="请输入手机号" v-model.lazy="mobile" @focus='uesrI($event)' @blur="uesrIdone($event)">
            </div>
          </section>
          <section class="input_container">
            <div class="input_text input_box input_code">
              <div class="input_code1">
                <b :class="{ 'class-codeA': codeInputA, 'class-codeB': codeInputB}"></b>
                <input type="text" placeholder="请输入验证码" v-model.lazy="number">
              </div>
              <div class="input_code2">
                <div  @click="sendCodePowd" class="pawod">
                  <mt-button  :disabled="mtdisabled" style="background: #fff;box-shadow: none;color: #e60039;font-size: 0.55rem">{{timerCodeMsg}}</mt-button>
                </div>
              </div>
            </div>

          </section>
          <section class="input_container input_p">
            <div class="input_password input_box">
              <b :class="{ 'class-passA': passUesrInputA, 'class-passB': passUesrInputB}"></b>
              <input v-if="!showPassword" type="password" placeholder="密码" v-model="password" @focus='passI($event)' @blur="passIdone($event)">
              <input v-else type="text" placeholder="密码" v-model="password">
              <span @click="changePassWordType" class="" :class="{ 'class-a': padImgA, 'class-b': padImgB}"></span>
            </div>
          </section>
          <section class="input_container">
            <div class="input_text input_box">
              <b :class="{ 'class-mobileA': mobileInputA, 'class-mobileB': mobileInputB}"></b>
              <input type="text" placeholder="请输入邀请人手机号" v-model.lazy="mobileCode" @focus='mobileI($event)' @blur="mobileIdone($event)">
            </div>
          </section>
        </form>
        <div class="checkbox-box">
          <span @click="checkboxBox" :class="{ 'checkboxBox-a': checkboxBoxA, 'checkboxBox-b': checkboxBoxB}"></span>
          <label for="male">已阅读并同意<b @click="open" class="text">《用户注册协议》</b><b class="text">《用户隐私政策》</b></label>
        </div>
        <div class="login-btn" @click="restPwd">完成</div>
      </div>
    </div>
    <Mdialog :dialog="dialog">
      <div slot="title">蛮划算用户注册协议</div>
      <div slot="content">
        <div class="a-content-group">
          <p class="p-content">1. 本协议是您与【蛮划算商城】（简称"商城"，网址：www.mhsapp.com）所有者“深圳市前海蛮划算科技有限公司”之间就【蛮划算】网上商城服务等相关事宜所订立的契约，请您仔细阅读本注册服务协议，您点击"同意并继续"按钮后，本协议即构成对双方有约束力的法律文件。</p>
          <p class="p-content">2.本商城及用户均已认真阅读本《用户注册协议》(下称“本协议”)中全部条款（特别是以黑体字标示出的关于本商城及用户重大权益的条款）及本商城发布的其他全部服务条款和操作规则的内容，对本协议及前述服务条款和规则均以知晓、理解并接受，同意将其作为确定双方权利义务的依据，并知悉商城相关活动可能发生的风险和应负的责任，承诺自愿承担相关风险。</p>

          <p class="p-title">一、定义</p>
          <p>1.1【蛮划算商城】是深圳市前海蛮划算科技有限公司运营和管理的平衡式电商综合服务商城，深圳市前海蛮划算科技有限公司通过该商城为用户和商家提供在线购物服务。本协议下文中，【蛮划算商城】既指电商综合服务商城，亦指深圳市前海蛮划算科技有限公司。</p>
          <p>1.2【商城业务】商城一是为商城入驻商家提供产品销售，推广服务，二是为商城会员提供全品类的在线购物服务。</p>
          <p>1.3【用户】是接受并同意本协议全部条款及【蛮划算商城】发布的其他全部服务条款和操作规则、通过【蛮划算商城】进行购物的注册会员。用户注册账户，一个手机号码只能免费注册一个账号。注册用户进行购物，第一次必须用现金购买商城入驻商家提供的商品，当获得商城赠送的积分额度后兑换成积分，可以用该积分在商城上进行再次消费。</p>
          <p>商城所有的用户必须是具有完全的民事权利能力和民事行为能力的自然人消费者，所有的用户根据自己的实际需求选择购买产品种类和数量。</p>
          <p>商城通过互联网依法为用户提供互联网信息等服务，用户使用本商城的相关服务，视为用户完全同意本协议及本商城所有规定。</p>
          <p>1.4 【积分额度】用户在【蛮划算商城】确认完成消费订单后，商城赠送给消费者该笔消费订单商城利润一定比例的积分额度，该积分额度不直接代表物品价值，不能直接作为现金使用，必须经过一个利润周期，即商城利润增加到足以覆盖所赠送的积分额度后（商城以自然日为单位进行结算，每日一结），积分额度方可转换成积分。积分为两种，即通用积分和专用积分，通用积分可在商城全场通用，可直接作为现金进行消费（1积分可抵扣10元现金），；专用积分在商城只能购买商城特定类目、特定商家或特定的商品，只能在商城作为现金消费，不可直接申请兑换成现金。通用积分与专用积分所占积分额度比例由商城根据市场情况具体决定及调整。</p>
          <p>积分仅可用于用户购物时抵扣现金进行支付，在任何情况下，商城均不支持，也不提供针对普通用户的积分（包括通用积分及专用积分）直接兑换现金服务。蛮划算商城的积分只能用于商城的购买交易，用户拥有的蛮划算商城积分可继承（继承人应提前向平台提交书面申请）、可在买家之间进行转让。</p>
          <p>蛮划算商城的积分额度兑换机制采用“每日一结，轮候兑换”的形式实现，即某一日蛮划算商城已完成的消费订单按各商家约定的技术服务费比例计算商城赠送的积分总额度，自该日起当商城利润足以覆盖该日“赠送积分总额度”时，该日积分总额度兑换成积分，而该日之后每天的积分总额度按日期先后进行轮候兑换，下一次商城利润足以覆盖该日次日的“赠送积分总额度”时，该日次日的“赠送积分总额度”兑换成积分，以此类推。</p>
          <p>“积分额度”及“积分”为商城为提升用户满意度及忠诚度而额外赠送给商城用户的非现金形式奖励。购买交易行为所带来的【积分额度】在多长时间内可以转化为实际可用的积分，是蛮划算商城包括其它有关方都无法人为设置，也是任何人都无法事前预知的，“额度”转化为“积分”所需时间的长短只取决于该“额度”生成后蛮划算商城的后续交易情况、交易规模和利润增量，极端情况下，若“额度”生效后，蛮划算商城未发生任何交易，此时商城没有增加任何可供二次分配的利润，“额度”将不会转化为积分，拥有该“额度”的买家会员会因得不到任何积分而最终成为一个自然消费者。</p>
          <p>【特别提醒】如果遇到国家政策、市场形势变更等不可抗力因素造成商城无法运营，所有【蛮划算商城】赠送的积分额度及积分额度兑换成的积分将自动作废。</p>

          <p class="p-title">二、协议范围</p>
          <p>2.1【签约主体】</p>
          <p>【平等主体】本协议由您与蛮划算商城经营者共同缔结，本协议对您与蛮划算商城经营者均具有合同效力。</p>
          <p>【消费者】指在蛮划算商城以购买商品或服务的自然人、商家或法人。</p>
          <p>2.2【补充协议】</p>
          <p> 由于互联网高速发展，您与蛮划算签署的本协议列明的条款并不能完整罗列并覆盖您与蛮划算的所有权利与义务，现有的约定也不能保证完全符合未来发展的需求。因此，蛮划算商城以及官网（www.mhsapp.cn）发布的法律声明及隐私权政策、蛮划算商城规则均为本协议的补充协议，与本协议不可分割且具有同等法律效力。如您使用蛮划算商城服务，视为您同意上述补充协议。</p>

          <p class="p-title">三、账户注册与使用</p>
          <p>3.1 【用户资格】</p>
          <p>您确认，在您开始注册程序使用蛮划算商城服务前，您应当具备中华人民共和国法律规定的与您行为相适应的民事行为能力。若您不具备前述与您行为相适应的民事行为能力，则您及您的监护人应依照法律规定承担因此而导致的一切后果。</p>
          <p>此外，您还需确保您不是任何国家、国际组织或者地域实施的贸易限制、制裁或其他法律、规则限制的对象，否则您可能无法正常注册及使用蛮划算商城服务。用户获得信息的途径为蛮划算官方发布的信息（包括但不限于蛮划算app、微信公众号、官网）,其他均为非官方信息或虚假信息。</p>
          <p>【用户信息】用户应当遵守法律法规，应当妥善使用和保管【蛮划算商城】ID账号及密码，对其【蛮划算商城】ID账号和密码下进行的行为和任何操作的事件负责。应自行诚信向本商城提供注册资料，用户同意其提供的注册资料真实、准确、完整、合法有效，用户注册资料如有变动的，应及时更新其注册资料。</p>
          <p>如果用户提供的注册资料不合法、不真实、不准确、不详尽的，用户需承担因此引起的相应责任及后果，并且蛮划算商城保留终止用户使用蛮划算各项服务的权利，有权在合理时间内对用户终止服务，但对采取行动前用户已经遭受的损失不承担任何责任。用户在未经【蛮划算商城】许可的情况下不得将【蛮划算商城】ID账号以赠与、借用、租用、转让或其他方式处分给他人，因此产生的法律责任由用户自行承担。</p>
          <p>用户在本商城进行浏览、下单购物、兑换商品等活动时，涉及用户真实姓名/名称、通信地址、联系电话、电子邮箱等隐私信息的，本商城将予以严格保密，除非得到用户的授权或法律另有规定，本商城不会向外界披露用户隐私信息。</p>
          <p>用户注册成功后，将产生用户名和登陆密码、支付密码等账户信息，您可以根据本商城规定改变您的密码。用户应谨慎合理的保存、使用其用户名和密码。用户若发现任何非法使用用户ID账号或存在安全漏洞的情况，请立即通知本商城并向公安机关报案。</p>
          <p>用户同意，蛮划算商城拥有通过邮件、短信电话等形式，向在本商城注册、购物用户、收货人发送订单信息、促销活动等告知信息的权利。</p>
          <p>用户不得将在本商城注册获得的ID账户借给他人使用，否则用户应承担由此产生的全部责任，并与实际使用人承担连带责任。</p>
          <p>用户同意，【蛮划算商城】有权使用用户的注册信息、用户名、密码等信息，登录进入用户的注册ID账户，进行证据保全，包括但不限于公证、见证等。</p>
          <p>3.2 【账户说明】</p>
          <p>【账户获得】当您按照注册页面提示填写真实信息、阅读并同意本协议且完成全部注册程序后，您可获得蛮划算商城账户并成为蛮划算商城用户。</p>
          <p>【本商城服务条件确认】本商城的各项电子服务的所有权和运营权归【蛮划算商城】所有。用户同意所有注册协议条款并完成注册程序，才能成为本商城的正式用户。用户确认：本协议条款是处理双方权利义务的契约，始终有效，法律另有强制性规定或双方另有特别约定的，依其规定。</p>
          <p>用户点击同意本协议并完成注册的用户，即视为用户确认自己具有享受本商城服务、下订单购买商品、兑换商品等相应的权利能力和行为能力，能够独立承担法律责任。</p>
          <p>如果您在18周岁以下，您只能在父母或监护人的监护参与下才能使用本商城。</p>
          <p>【蛮划算商城】保留在中华人民共和国大陆地区法律允许的范围内享有独自决定拒绝服务、关闭用户I D账户、清除或编辑内容或取消订单的权利。</p>
          <p>【账户使用】您有权使用您申请并确认的蛮划算会员名、邮箱、手机号码（以下简称“账户名称”）及您设置的密码（账户名称及密码合称“账户”）登录蛮划算商城。</p>
          <p>由于您的蛮划算账户关联您的个人信息和财产安全以及蛮划算商城商业信息，您的蛮划算账户仅限您本人使用。未经蛮划算商城同意，您直接或间接授权第三方使用您蛮划算账户或获取您账户项下信息的行为无效。如蛮划算商城判断您蛮划算账户的使用可能危及您的账户安全及/或蛮划算商城信息安全的，蛮划算商城可拒绝提供相应服务或终止本协议。</p>
          <p>【账户转让】由于您的账户关联您的个人商业信息，原则上不允许进行转户，仅当有法律明文规定、司法裁定或经蛮划算同意，并符合蛮划算商城规则规定的用户账户转让流程的情况下，您可进行账户的转让。您的账户一经转让，该账户项下权利义务一并转移。除此外，您的账户不得以任何方式转让，否则蛮划算商城有权追究您的违约责任，且由此产生的一切责任均由您承担。</p>
          <p>【实名认证】作为蛮划算商城经营者，为使您更好地使用蛮划算商城的各项服务，保障您的账户安全，蛮划算要求您注册及使用蛮划算商城服务时必须提供真实身份信息，必要时按我国法律规定完成实名认证。</p>
          <p>3.3 【注册信息管理】</p>
          <p>3.3.1【真实合法】</p>
          <p>【信息真实】在使用蛮划算商城服务时，您应当按蛮划算商城页面的提示准确完整地提供您的信息（包括您的姓名、身份证号码及电子邮件地址、联系电话、联系地址等），以便蛮划算或其他用户与您联系。您了解并同意，您有义务保持您提供信息的真实性及有效性。</p>
          <p>【用户名的合法性】您设置的蛮划算会员名不得违反国家法律法规及蛮划算商城规则关于会员名的管理规定，否则蛮划算可回收您的蛮划算会员名。</p>
          <p>3.3.2 【更新维护】</p>
          <p>您应当及时更新您提供的信息，在法律有明确规定要求蛮划算作为商城服务提供者必须对部分用户（如商城卖家等）的信息进行核实的情况下，蛮划算将依法不时地对您的信息进行检查核实，您应当配合提供最新、真实、完整、有效的信息。</p>
          <p>如蛮划算按您最后一次提供的信息与您联系未果、您未按蛮划算的要求及时提供信息、您提供的信息存在明显不实或行政司法机关核实您提供的信息无效的，您将承担因此对您自身、他人及蛮划算造成的全部损失与不利后果。蛮划算可向您发出询问或要求整改的通知，并要求您进行重新认证，直至终止对您提供部分或全部蛮划算商城服务，蛮划算对此不承担责任。</p>
          <p>3.4 【账户使用及安全规范】</p>
          <p>【商品信息】本商城上的商品种类、数量、是否有货等商品信息随时都有可能发生变动，本商城不作特别通知。由于上商品信息的数量极其庞大，虽然本商城会尽最大努力保证您所浏览商品信息的准确性，但由于众所周知的互联网技术因素等客观原因存在，本商城网页显示的信息可能会有一定的滞后性或差错，对此情形您知悉并理解；蛮划算商城欢迎纠错，并会视情况给予纠错者一定的奖励。 为表述便利，商品和服务简称为"商品"或"货物"。</p>
          <p>【订单】在您下订单时，请您仔细确认所购商品的名称、价格、数量、型号、规格、尺寸、联系地址、电话、收货人等信息。收货人与用户本人不一致的，收货人的行为和意思表示视为用户的行为和意思表示，用户应对收货人的行为及意思表示的法律后果承担连带责任。</p>
          <p>除法律另有强制性规定外，双方约定如下：本商城上销售方展示的商品和积分数量等信息仅仅是交易信息的发布，您下订单时须填写您希望购买的商品数量及支付方式、收货人、联系方式、收货地址等内容；系统生成的订单信息是计算机信息系统根据您填写的内容自动生成的数据，仅是您向销售方发出的交易诉求；销售方收到您的订单信息后，只有在销售方将您在订单中订购的商品从仓库实际直接向您发出时（ 以商品出库物流公司收货时间为标志），方视为您与销售方之间就实际直接向您发出的商品建立了交易关系；如果您在一份订单里订购了多种商品并且销售方只给您发出了部分商品时，您与销售方之间仅就实际直接向您发出的商品建立了交易关系；只有在销售方实际直接向您发出订单中订购的其他商品时，您和销售方之间就该订单中其他已实际直接向您发出的商品才成立交易关系。您可以随时登录您在本商城注册的ID账户，查询您的订单状态。</p>
          <p>【配送】销售方将会把商品（货物）送到您所指定的收货地址，所有在本商城上列出的送货时间为参考时间，参考时间的计算是根据库存状况、正常的处理过程和送货时间、送货地点的基础上估计得出的。</p>
          <p>因如下情况造成订单延迟或无法配送等，销售方不承担延迟配送的责任：</p>
          <p>(1)用户提供的信息错误、地址不详细等原因导致的；</p>
          <p>(2)货物送达后无人签收，导致无法配送或延迟配送的；</p>
          <p>(3)情势变更因素导致的；</p>
          <p>(4)不可抗力因素导致的，例如：自然灾害、交通戒严、突发战争等。</p>
          <p>【7天无理由退换货】根据《网络购买商品七日无理由退货暂行办法》的相关规定 ，除不适用无理由退换货的商品类别，消费者依法享有自收到商品之日起七日内无理由退货的权利；但若消费者在收到商品之日起七日内在商城选择放弃“七日无理由退货”的权利，则该笔订单状态自消费者确认之日起为“已完成”状态。如商家发货之日起七日内用户未确认收货，则蛮划算商城按超时默认该笔交易为“已完成”，商家发货以后，用户有权申请一次延期确认收货（延期时间自申请延期之日起七日内）。</p>
          <p>蛮划算商城赠送给用户的积分额度自交易完成之日起开始生效并进入等待转化为积分的每日排队序列。</p>
          <p>【责任限制及不承诺担保】除非另有明确的书面说明,本商城及其所包含的或以其它方式通过本商城提供给您的全部信息、内容、材料、产品（包括软件）和服务，均是在"按现状"和"按现有"的基础上提供的。</p>
          <p>除非另有明确的书面说明,蛮划算商城不对本商城的运营及其包含在本上的信息、内容、材料、产品（包括软件）或服务作任何形式的、明示或默示的声明或担保（根据中华人民共和国法律另有规定的以外）。</p>
          <p>如因不可抗力或其它本商城无法控制的原因使本商城销售系统崩溃或无法正常使用导致网上交易无法完成或丢失有关的信息、记录等，蛮划算会合理地尽力协助处理善后事宜。</p>
          <p>【账户安全保管义务】您的账户及密码由您自行设置并保管，蛮划算任何时候均不会主动要求您提供您的账户密码。因此，建议您务必保管好您的账户，并确保您在每个上网时段结束时退出登录，并以正确步骤离开蛮划算商城。</p>
          <p>账户因您主动或无意泄露或因您遭受他人攻击、诈骗等行为而泄露导致的损失及后果，蛮划算不承担责任，您应通过司法、行政等途径向侵权行为人追偿。</p>
          <p>【账户行为责任自负】除蛮划算存在过错外，您应对您账户项下的所有行为结果（包括但不限于在线签署各类协议、发布信息、购买商品及服务及披露信息等）负责。</p>
          <p>【日常维护须知】如发现任何未经授权使用您账户登录蛮划算商城或其他可能导致您账户遭窃、遗失的情况，建议您立即通过手机更新密码，并向蛮划算电话或书面通知形式及时反应情况。您应理解蛮划算对您的任何请求所采取的行动均需要合理时间，且蛮划算应您请求而采取的行动可能无法避免或阻止因您的上述情形而产生的侵害后果的形成或扩大。</p>
          <p>【客户服务】【蛮划算商城】建立专业的客服团队，并建立完善的客户服务制度，从技术、人员和制度上保障用户提问及投诉渠道的畅通，为用户提供及时的疑难解答与投诉反馈。</p>

          <p class="p-title">四、蛮划算商城服务及规范</p>
          <p>4.1【商品或服务的购买与评价 】</p>
          <p>【商品或服务的购买】当您在蛮划算商城购买商品及服务时，请您务必仔细确认所购商品的品名、价格、数量、型号、规格、尺寸或服务的时间、内容、限制性要求等重要事项，并在下单时核实您的联系地址、电话、收货人等信息。如您填写的收货人非您本人，则该收货人的行为和意思表示产生的法律后果均由您承担。</p>
          <p>您的购买行为应当基于真实的消费需求，不得存在对商品或服务实施恶意购买、恶意维权等扰乱蛮划算商城正常交易秩序的行为。基于维护蛮划算商城交易秩序及交易安全的需要，蛮划算发现上述情形时可主动执行关闭相关交易订单等操作。</p>
          <p>【评价】您有权在蛮划算商城提供的评价系统中对与您达成交易的其他用户商品及服务进行评价。您应当理解，您在蛮划算商城的评价信息是公开的，如您不愿意在评价信息中向公众披露您的身份信息，您可以匿名形式发表评价内容。</p>
          <p>您的所有评价行为应遵守蛮划算商城规则的相关规定，评价内容应当客观真实，不应包含任何污言秽语、色情低俗、广告信息及法律法规与本协议列明的其他禁止性信息；您不应以不正当方式帮助他人提升信用或利用评价权利对其他用户实施威胁、敲诈勒索。蛮划算可按照蛮划算商城规则的相关规定对您实施上述行为所产生的评价信息进行删除或屏蔽。</p>
          <p>4.2【交易争议处理】</p>
          <p>【交易争议处理途径】您在蛮划算商城交易过程中与其他用户发生争议的，您或其他用户中任何一方均有权选择以下一种或多种途径解决：</p>
          <p>(一) 与争议相对方自主协商；</p>
          <p>(二) 申请通过蛮划算商城进行调处；</p>
          <p>(三) 请求消费者协会或者其他依法成立的调解组织调解；</p>
          <p>(四) 煽动民族仇恨、民族歧视，破坏民族团结的；</p>
          <p>(五) 根据与争议相对方达成的仲裁协议（如有）提请仲裁机构仲裁；</p>
          <p>(六) 向人民法院提起诉讼。</p>
          <p>当订单状态为“已完成”之前，如您选择通过蛮划算商城进行调处，则表示您认可并愿意履行蛮划算商城工作人员根据其所了解到的争议事实并依据蛮划算商城规则所作出的调处决定（包括调整相关订单的交易状态、判定将争议款项的全部或部分支付给交易一方或双方等）。</p>
          <p>如您对调处决定不满意，您仍有权采取其他争议处理途径解决争议，但通过其他争议处理途径未取得终局决定前，您仍应先履行蛮划算商城的调处决定。</p>
          <p>当订单状态为“已完成”之后（无论是因买家会员超时确认收货还是因买家会员在确认收货同时主动放弃“七日无理由退换货权利”而导致的订单状态为“已完成”）买家会员与卖家会员所产生的退款退货等纠纷，蛮划算商城均有权不再介入调处，买卖双方因本着善意原则首先友好协商，协商不成的双方可选择本条款上述其他途径解决相关争议。</p>

          <p>4.3【费用】</p>
          <p>蛮划算商城向您提供的服务付出了大量的成本，除蛮划算商城的收费业务外，蛮划算根据向您提供的服务收取一定费用或免费。但蛮划算收费项目会采取合理途径并以足够合理的期限提前通过法定程序并提前通知您，确保您有充分选择的权利。</p>
          <p>4.4【市场推广收益】蛮划算商城注册用户通过分享、推广，可获得其直接或间接粉丝消费订单商城利润的一定比例的积分额度奖励。具体奖励办法以商城官方公布的信息为准。</p>
          <p>4.5【业务推荐奖励】蛮划算商城注册用户为商城招募商家入驻、运营中心签约、服务商加盟，将有机会获得一定比例的积分额度奖励。具体奖励办法以商城官方公布的信息为准。</p>
          <p>4.6【责任限制】</p>
          <p>【不可抗力及第三方原因】蛮划算依照法律规定履行基础保障义务，但对于下述情形导致的合同履行障碍、履行瑕疵、履行延后或履行内容变更等情形，蛮划算并不承担相应的违约责任：</p>
          <p>(一) 用户理解并确认：在使用本服务的过程中，可能会遇到不可抗力等风险因素，使本服务发生中断。不可抗力是指不能预见、不能克服并不能避免且对一方或双方造成重大影响的客观事件，包括但不限于自然灾害、罢工、暴乱、战争、政府行为、司法行政命令等等。出现上述情况时，蛮划算将努力在第一时间与相关单位配合，及时进行修复，但是由此给用户或第三方造成的损失，蛮划算及合作单位在法律允许的范围内免责。</p>
          <p>(二) 本服务同大多数互联网服务一样，受包括但不限于用户原因、网络服务质量、社会环境等因素的差异影响，可能受到各种安全问题的侵扰，如他人利用用户的资料，造成现实生活中的骚扰；用户下载安装的其它软件或访问的其他网站中含有"特洛伊木马"等病毒，威胁到用户的计算机信息和数据的安全，继而影响本服务的正常使用等等。用户应加强信息安全及使用者资料的保护意识，要注意加强密码保护，以免遭致损失和骚扰。</p>
          <p>(三) 用户理解并确认：本服务存在因不可抗力、计算机病毒或黑客攻击、系统不稳定、用户所在位置、用户关机以及其他任何技术、互联网络、通信线路原因等造成的服务中断或不能满足用户要求的风险，因此导致的用户或第三方任何损失，蛮划算不承担任何责任。</p>
          <p>(四) 用户理解并确认：在使用本服务过程中存在来自任何他人的包括误导性的、欺骗性的、威胁性的、诽谤性的、令人反感的或非法的信息，或侵犯他人权利的匿名或冒名的信息，以及伴随该等信息的行为，因此导致的用户或第三方的任何损失，蛮划算不承担任何责任。</p>
          <p>(五) 用户理解并确认：蛮划算需要定期或不定期地对"蛮划算"商城或相关的设备进行检修或者维护，如因此类情况而造成服务在合理时间内的中断，蛮划算无需为此承担任何责任，但蛮划算应事先进行通告。</p>
          <p>(六) 蛮划算依据法律法规、本协议约定获得处理违法违规或违约内容的权利，该权利不构成蛮划算的义务或承诺，蛮划算不能保证及时发现违法违规或违约行为或进行相应处理。</p>
          <p>(七)用户理解并确认：对于蛮划算向用户提供的下列产品或者服务的质量缺陷及其引发的任何损失，蛮划算无需承担任何责任：</p>
          <p>(1)蛮划算向用户免费提供的服务；</p>
          <p>(2)蛮划算向用户赠送的任何产品或者服务。</p>
          <p>(八)在任何情况下，蛮划算均不对任何间接性、后果性、惩罚性、偶然性、特殊性或刑罚性的损害（包括因用户使用"蛮划算"或本服务而遭受的利润损失），承担责任（即使蛮划算已被告知该等损失的可能性亦然）。尽管本协议中可能含有相悖的规定，蛮划算对用户承担的全部责任，无论因何原因或何种行为方式，始终不超过用户因使用蛮划算提供的服务而支付给蛮划算的费用(如有)。</p>
          <p>【海量信息】蛮划算仅向您提供蛮划算商城服务，您了解蛮划算商城上的信息系用户自行发布，且可能存在风险和瑕疵。鉴于蛮划算商城具备存在海量信息及信息软件环境下信息与实物相分离的特点，蛮划算无法逐一审查商品及/或服务的信息，无法逐一审查交易所涉及的商品及/或服务的质量、安全以及合法性、真实性、准确性，对此您应谨慎判断。</p>
          <p>【调处决定】您理解并同意，在争议调处服务中，蛮划算商城的客服并非专业人士，仅能以普通人的认知对用户提交的凭证进行判断。因此，除存在故意或重大过失外，调处方对争议调处决定免责。</p>

          <p class="p-title">五、用户信息的保护及授权</p>
          <p>5.1【个人信息的保护】</p>
          <p>蛮划算非常重视用户个人信息（即能够独立或与其他信息结合后识别用户身份的信息）的保护，在您使用蛮划算提供的服务时，您同意蛮划算按照在蛮划算商城上公布的隐私权政策收集、存储、使用、披露和保护您的个人信息。</p>
          <p>5.2【非个人信息的保证与授权】</p>
          <p>【信息的发布】您声明并保证，您对您所发布的信息拥有相应、合法的权利。否则，蛮划算可对您发布的信息依法或依本协议进行删除或屏蔽。</p>
          <p>【禁止性信息】您应当确保您所发布的信息不包含以下内容：</p>
          <p>(一)违反国家法律法规禁止性规定的；</p>
          <p>(二) 政治宣传、封建迷信、淫秽、色情、赌博、暴力、恐怖或者教唆犯罪的；</p>
          <p>(三) 欺诈、虚假、不准确或存在误导性的；</p>
          <p>(四) 侵犯他人知识产权或涉及第三方商业秘密及其他专有权利的；</p>
          <p>(五) 侮辱、诽谤、恐吓、涉及他人隐私等侵害他人合法权益的；</p>
          <p>(六) 存在可能破坏、篡改、删除、影响蛮划算商城任何系统正常运行或未经授权秘密获取蛮划算商城及其他用户的数据、个人资料的病毒、木马、爬虫等恶意软件、程序代码的；</p>
          <p>(七)其他违背社会公共利益或公共道德或依据相关蛮划算商城协议、规则的规定不适合在蛮划算商城上发布的。</p>
          <p>【授权使用】对于您提供、发布及在使用蛮划算商城服务中形成的除个人信息外的文字、图片、视频、音频等非个人信息，在法律规定的保护期限内您免费授予蛮划算获得全球排他的许可使用权利及再授权给其他第三方使用并可以自身名义对第三方侵权行为取证及提起诉讼的权利。您同意蛮划算及其关联公司存储、使用、复制、修订、编辑、发布、展示、翻译、分发您的非个人信息或制作其派生作品，并以已知或日后开发的形式、媒体或技术将上述信息纳入其它作品内。</p>
          <p>【知识产权】【蛮划算商城】所包含的全部智力成果包括但不限于数据库、设计、文字和图表、软件、照片、录像、音乐、声音及其前述组合，软件编译、相关源代码和软件 (包括小应用程序和脚本) 的知识产权权利均归【蛮划算商城】所有。用户不得为商业目的复制、更改、拷贝、发送或使用前述任何材料或内容。</p>
          <p>【蛮划算商城】名称中包含的所有权利 (包括商誉和商标) 均归【蛮划算商城】所有。</p>
          <p>用户接受本协议即视为用户主动将其在【蛮划算商城】发表的任何形式的信息的著作权，包括但不限于：复制权、发行权、出租权、展览权、表演权、放映权、广播权、信息软件传播权、摄制权、改编权、翻译权、汇编权以及应当由著作权人享有的其他可转让权利无偿独家转让给【蛮划算商城】所有，【蛮划算商城】有权利就任何主体侵权单独提起诉讼并获得全部赔偿。本协议属于《中华人民共和国著作权法》第二十五条规定的书面协议，其效力及于用户在【蛮划算商城】发布的任何受著作权法保护的作品内容，无论该内容形成于本协议签订前还是本协议签订后。</p>
          <p>用户在使用【蛮划算商城】服务过程中不得非法使用或处分【蛮划算商城】或他人的知识产权权利。用户不得将已发表于【蛮划算商城】的信息以任何形式发布或授权其它（及媒体）使用。</p>

          <p class="p-title">六、 用户的违约及处理</p>
          <p>6.1【 违约认定】</p>
          <p>(一) 使用蛮划算商城服务时违反有关法律法规规定的；</p>
          <p>(二) 违反本协议或本协议补充协议约定的。</p>
          <p>6.2 【违约处理措施】</p>
          <p>【信息处理】您在蛮划算商城上发布的信息构成违约的，蛮划算可根据相应规则立即对相应信息进行删除、屏蔽处理或对您的账户进行限制、冻结等。</p>
          <p>【行为限制】您在蛮划算商城上实施的行为，或虽未在蛮划算商城上实施但对蛮划算商城及其用户产生影响的行为构成违约的，蛮划算可依据相应规则对您执行账户冻结、终止向您提供部分或全部服务、划扣违约金等处理措施。如您的行为构成根本违约的，蛮划算可查封您的账户，终止向您提供服务。</p>
          <p>【账户处理】当您违约的同时存在欺诈、售假、盗用他人账户等特定情形或您存在危及他人交易安全或账户安全风险时，蛮划算会依照您行为的风险程度对您的账户采取取消收款、现金和兑换止付等强制措施。</p>
          <p>【处理结果公示】蛮划算可将对您上述违约行为处理措施信息以及其他经国家行政或司法机关生效法律文书确认的违法信息在蛮划算商城上予以公示。</p>
          <p>蛮划算商城保留在中华人民共和国大陆地区法律允许的范围内享有独自决定拒绝服务、关闭用户ID账户、清除或编辑内容或取消订单的权利。</p>
          <p>6.3【赔偿责任】</p>
          <p>如您的行为使蛮划算遭受损失（包括自身的直接经济损失、商誉损失及对外支付的赔偿金、和解款、律师费、诉讼费等间接经济损失），您应赔偿蛮划算的上述全部损失。</p>
          <p>如您的行为使蛮划算遭受第三人主张权利，蛮划算可在对第三人承担金钱给付等义务后就全部损失向您追偿。</p>
          <p>如因您的行为使得第三人遭受损失或您怠于履行调处决定、蛮划算出于社会公共利益保护或消费者权益保护目的，可自您的账户中划扣相应款项（或/和积分，下同）进行支付。如您不足以支付相应款项的，您同意委托蛮划算使用自有资金或/和积分代您支付上述款项，您应当返还该部分费用并赔偿因此造成蛮划算的全部损失。</p>
          <p>您同意蛮划算公司自您的账户中划扣相应款项支付上述赔偿款项。如您账户中的款项不足以支付上述赔偿款项的，蛮划算公司可直接抵减您在蛮划算公司其它协议项下的权益，并可继续追偿。</p>
          <p>6.4【特别约定】</p>
          <p>【商业贿赂】如您向蛮划算的雇员或顾问等提供实物、现金、现金等价物、劳务、旅游等价值明显超出正常商务洽谈范畴的利益，则可视为您存在商业贿赂行为。发生上述情形的，蛮划算可立即终止与您的所有合作并向您收取违约金及/或赔偿金，该等金额以蛮划算因您的贿赂行为而遭受的经济损失和商誉损失作为计算依据。</p>
          <p>【关联处理】如您因严重违约导致蛮划算终止本协议时，出于维护商城秩序及保护消费者权益的目的，蛮划算公司可对与您在其他协议项下的合作采取中止甚或终止协议的措施，并以本协议约定的方式通知您。</p>
          <p>如蛮划算与您签署的其他协议中明确约定了对您在本协议项下合作进行关联处理的情形，则蛮划算出于维护商城秩序及保护消费者权益的目的，可在收到指令时中止甚至终止协议，并以本协议约定的方式通知您。</p>

          <p class="p-title">七、协议的变更</p>
          <p>蛮划算可根据国家法律法规变化及维护交易秩序、保护消费者权益需要，不时修改本协议、补充协议。</p>
          <p>如您对已生效的变更事项不同意的，您应当于变更事项确定的生效之日起停止使用蛮划算商城服务，变更事项对您不产生效力；如您在变更事项生效后仍继续使用蛮划算商城服务，则视为您同意已生效的变更事项。</p>

          <p class="p-title">八、通知</p>
          <p>8.1【有效联系方式】</p>
          <p>您在注册成为蛮划算商城会员，并接受蛮划算商城服务时，您应该向蛮划算提供真实有效的联系方式（包括您的电子邮件地址、联系电话、联系地址等），对于联系方式发生变更的，您有义务及时更新有关信息，并保持可被联系的状态。</p>
          <p>蛮划算将向您的上述联系方式的其中之一或其中若干向您送达各类通知，而此类通知的内容可能对您的权利义务产生重大的有利或不利影响，请您务必及时关注。</p>
          <p>您有权通过您注册时填写的手机号码或者电子邮箱获取您感兴趣的商品广告信息、促销优惠等商业性信息；您如果不愿意接收此类信息，您有权向蛮划算商城申请退订。</p>

          <p>8.2 【通知的送达】</p>
          <p>蛮划算通过上述联系方式向您发出通知，其中以电子的方式发出的书面通知，包括但不限于在蛮划算商城公告，向您提供的联系电话发送手机短信，向您提供的电子邮件地址发送电子邮件，向您的账号发送信息，在发送成功后即视为送达；以纸质载体发出的书面通知，按照提供联系地址交邮后的第五个自然日即视为送达。</p>
          <p>对于在蛮划算商城上因交易活动引起的任何纠纷，您同意司法机关（包括但不限于人民法院）可以通过手机短信、电子邮件等现代通讯方式或邮寄方式向您送达法律文书（包括但不限于诉讼文书）。您指定接收法律文书的手机号码、电子邮箱等联系方式为您在蛮划算商城注册、更新时提供的手机号码、电子邮箱等联系方式，司法机关向上述联系方式发出法律文书即视为送达。您指定的邮寄地址为您的法定联系地址或您提供的有效联系地址。</p>
          <p>您同意司法机关可采取以上一种或多种送达方式向您达法律文书，司法机关采取多种方式向您送达法律文书，送达时间以上述送达方式中最先送达的为准。</p>
          <p>您同意上述送达方式适用于各个司法程序阶段。如进入诉讼程序的，包括但不限于一审、二审、再审、执行以及督促程序等。</p>
          <p>你应当保证所提供的联系方式是准确、有效的，并进行实时更新。如果因提供的联系方式不确切，或不及时告知变更后的联系方式，使法律文书无法送达或未及时送达，由您自行承担由此可能产生的法律后果。 </p>

          <p class="p-title">九、协议的终止</p>
          <p>9.1 【终止的情形】</p>
          <p>【用户发起的终止】您有权通过以下任一方式终止本协议：</p>
          <p>(一)变更事项生效前您停止使用并明示不愿接受变更事项的；</p>
          <p>(二)您明示不愿继续使用蛮划算商城服务，且经蛮划算书面认可的。</p>
          <p>【蛮划算发起的强制退出】：出现以下情况时，蛮划算可以本协议第八条的所列的方式通知您终止本协议：</p>
          <p>(一)您违反本协议约定，蛮划算依据违约条款终止本协议的；</p>
          <p>(二) 您盗用他人账户、发布违禁信息、骗取他人财物、售假、扰乱市场秩序、采取不正当手段谋利等行为，蛮划算依据蛮划算商城规则对您的账户予以查封的；</p>
          <p>(三) 除上述情形外，因您多次违反蛮划算商城规则相关规定且情节严重，蛮划算依据蛮划算商城规则对您的账户予以查封的；</p>
          <p>(四) 您的账户被蛮划算依据本协议回收的；</p>
          <p>(五) 其它应当终止服务的情况。</p>

          <p>9.2【 协议终止后的处理】</p>
          <p>注意此条与退出的说法一致性</p>
          <p>【用户信息披露】本协议终止后，除法律有明确规定外，蛮划算无义务向您或您指定的第三方披露您账户中的任何信息。</p>
          <p>【蛮划算权利】本协议终止后，蛮划算仍享有下列权利：</p>
          <p>(一)继续保存您留存于蛮划算商城的本协议第五条所列的各类信息；</p>
          <p>(二)对于您过往的违约行为，蛮划算仍可依据本协议向您追究违约责任。</p>
          <p>【交易处理】本协议终止后，对于您在本协议存续期间产生的交易订单，蛮划算可通知交易相对方并根据交易相对方的意愿决定是否关闭该等交易订单；如交易相对方要求继续履行的，则您应当就该等交易订单继续履行本协议及交易订单的约定，并承担因此产生的任何损失或增加的任何费用。</p>

          <p class="p-title">十、法律适用、管辖与其他</p>
          <p>【法律管辖和适用】本协议的效力、解释及纠纷的解决，适用于中华人民共和国法律。若用户和蛮划算之间发生任何纠纷或争议，首先应友好协商解决，协商不成的，用户同意将纠纷或争议提交蛮划算住所地有管辖权的人民法院管辖。</p>
          <p>【可分性】本协议任一条款被视为废止、无效或不可执行，该条应视为可分的且并不影响本协议其余条款的有效性及可执行性。</p>

          <p class="p-title">十一、其他</p>
          <p>【蛮划算商城】尊重用户和消费者厂家的合法权利，本协议及本上发布的各类规则、声明等其他内容，均是为了更好的、更加便利的为用户和消费者提供服务。</p>
          <p>本商城欢迎用户、社会各界和相关执法部门对本商城提出意见和建议，蛮划算将虚心接受并适时修改本协议及本商城上的各类规则。</p>
          <p>本协议内容中以黑体、加粗字体等方式显著标识的条款，请用户着重阅读。</p>
          <p>【审慎阅读】签约各方已认真阅读并充分理解上述条款的全部内容，特别是免除或者限制责任的条款、法律适用和争议解决条款。</p>

        </div>

      </div>
      <div slot="btn" @click="close">确定</div>
    </Mdialog>
  </div>
</template>

<script>
  import Mheader from '../../components/Mheader'
  import Mdialog from '../../components/Mdialog'
  import axios from 'axios';
  //import { MessageBox } from 'mint-ui';
  import md5 from 'js-md5';
  import { Toast } from 'mint-ui';
  import { Checklist } from 'mint-ui';

  export default {
    components: {
      Mheader,
      Mdialog
    },
    data() {
      return {
        mobile: null,
        number: null,
        mobileCode:'',
        dialog: null,
        password: null,
        imgNumber: null,
        verifyCode: null,
        vcBool: true,
        timerCodeMsg: '获取验证码',
        fetchCodeMsg: true,
        mtdisabled:false,
        userName: null,
        userPwd: null, //密码
        showPassword: false, // 是否显示密码
        padImgA: true,
        padImgB: false,
        checkboxBoxA: true,
        checkboxBoxB: false,
        uesrInputA: true,
        uesrInputB: false,
        codeInputA: true,
        codeInputB: false,
        mobileInputA: true,
        mobileInputB: false,
        passUesrInputA: true,
        passUesrInputB: false,

        Img: [{
          padImg: require('../../assets/images/login&register/pad2.png'),
        }],
        padImg: require('../../assets/images/login&register/pad2.png'),
        padImg1: require('../../assets/images/login&register/pad1.png'),
      }
    },
    methods: {
      open() {
        this.dialog = true
      },
      close() {
        this.dialog = false
      },
      checkboxBox() {
        this.checkboxBoxA = !this.checkboxBoxA;
        this.checkboxBoxB = !this.checkboxBoxB;
      },
      changePassWordType() {
        this.showPassword = !this.showPassword;
        this.padImgA = !this.padImgA;
        this.padImgB = !this.padImgB;
      },
      uesrI($event) {
        this.uesrInputA = !this.uesrInputA;
        this.uesrInputB = !this.uesrInputB;

      },
      uesrIdone($event) {
        this.uesrInputA = !this.uesrInputA;
        this.uesrInputB = !this.uesrInputB;
      },
      codeI($event) {
        this.codeInputA = !this.codeInputA;
        this.codeInputB = !this.codeInputB;

      },
      codeIdone($event) {
        this.codeInputA = !this.codeInputA;
        this.codeInputB = !this.codeInputB;
      },
      mobileI($event) {
        this.mobileInputA = !this.mobileInputA;
        this.mobileInputB = !this.mobileInputB;

      },
      mobileIdone($event) {
        this.mobileInputA = !this.mobileInputA;
        this.mobileInputB = !this.mobileInputB;
      },

      passI($event) {
        this.passUesrInputA = !this.passUesrInputA;
        this.passUesrInputB = !this.passUesrInputB;
      },
      passIdone($event) {
        this.passUesrInputA = !this.passUesrInputA;
        this.passUesrInputB = !this.passUesrInputB;

      },

      sendCodePowd() { //发送短信验证码
        if(!!!this.mobile) {
          Toast('手机号不能为空');
          return;
        }
        if(!this.isPhoneNo(this.mobile)) {
          Toast('手机号格式不正确');
          return;
        }

        let data = {
          'body': {
            mobile: this.mobile,
            type:'1'
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_smsSend, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-',
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            this.timeOut();
            this.mtdisabled=true
          } else {
            Toast(response.data.message)
          }
        }).catch((error) => {
          Toast(response.data.message)
        });

      },
      isPhoneNo(phone) { //手机号验证
        var pattern = /^1[34578]\d{9}$/;
        return pattern.test(phone);
      },
      verifyPassword(pwd) { //密码验证
        let pattern = /^[A-Za-z_0-9]{6,16}$/;
        return pattern.test(pwd);
      },
      timeOut() { //倒计时
        let self = this;
        let sec = 80;
        for(let i = 0; i <= 80; i++) {
          window.setTimeout(function() {
            if(sec != 0) {
              self.timerCodeMsg = sec + "秒";
              sec--;
            } else {
              sec = 80; //如果倒计时结束就让重新获取验证码显示出来
              self.timerCodeMsg = "获取验证码";
              self.mtdisabled = false
            }
          }, i * 1000)
        }
      },
      restPwd() { //重置密码
        if(!!!this.mobile) {
          Toast('手机号不能为空');
          return;
        }
        if(!this.isPhoneNo(this.mobile)) {
          Toast('手机号格式不正确');
          return;
        }
        if(!!!this.number) {
          Toast('验证码不能为空');
          return;
        }
        if(!!!this.password) {
          Toast('密码不能为空');
          return;
        }
        if(this.password.length < 6 || this.password.length > 12) {
          Toast('密码的长度在6-12位之间');
          return;
        }
        if(!this.verifyPassword(this.password)) {
          Toast('密码的格式错误');
          return;
        }
        let data = {
          'body': {
            userName:this.mobile,//手机号
            userPwd:md5(this.password),  //密码
            verificationCode:this.number,//验证码
            userType:'1',
            spreadCode:this.mobileCode,
            type:'2'
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_usRegist, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-',
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            let instance = Toast('注册成功');
            setTimeout(() => {
              instance.close();
              this.$router.push({
                path: '/login'
              })
            }, 1000);
          } else {
            Toast(response.data.message)
          }
        }).catch((error) => {
          Toast(response.data.message)
        });
      },

      chkVCode() {
        if(!!!this.imgNumber) {
          Toast('请输入图片中的字符');
          return;
        }
        if(this.imgNumber.length != 4) {
          Toast('输入的字符长度不对');
          return;
        }
        let strs = this.verifyCode.split('/');
        let imgName = strs[strs.length - 1];
        this.axios.post(this.url + '/api/Login/CheckVCode', {
          vCode: this.imgNumber,
          token: this.vcToken,
          imgName: imgName
        }).then((res) => {
          if(res.data.Code == 200) {
            this.vcBool = false;
            this.fetchCodeMsg = false;
          } else {
            Toast(res.data.Data);
          }
        }).catch((err) => {
          Toast('网络请求超时');
        })
      }



    }
  }
</script>

<style scoped>
  .cont {
    margin-top: 1.8rem;
    height: 100vh;
    background-color: #f4f4f4;
  }

  .box {
    font-size: 0.7rem;
  }

  .box .login-box {
    /*padding: 0 .5em 1rem;*/
  }
  .text{display: inline-block;width: 1rem}
  .box .login {
    height: 7rem;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .box .login>img {
    margin: 0 auto;
    width: 3.5rem;
    height: 3.3rem;
  }

  .class-a {
    background: url("../../assets/images/login&register/pad2.png") no-repeat;
    background-size: 100%
  }

  .class-b {
    background: url("../../assets/images/login&register/pad1.png") no-repeat;
    background-size: 100%
  }

  .loginForm {
    background: #fff;
  }
  .input_code{display: flex;line-height: 1.6rem}
  .input_code1{flex: 2 ;}
  .input_code2{flex: 1;text-align: center;color: #e60039;font-size: 0.60rem;height: 1.6rem;border-left: 1px solid #eaeaea;margin-top: 0.09rem}
  .input_container input {
    border: none;
    width: 86%;
    height: 1rem;
    line-height: 1rem;
    background: #fff;
    padding-left: .5rem
  }

  .input_container {
    width: 100%
  }

  .input_box {
    border-bottom: 0.5px solid #eaeaea;
    position: relative;
    height: 2rem;
    line-height: 2rem;
    padding: 0 .6rem
  }

  .input_box span {
    position: absolute;
    top: 30%;
    right: 4%;
    display: inline-block;
    width: 30px;
    height: 40px
  }

  .input_box img {
    width: 1rem;
    height: 1rem;
    margin-bottom: .4rem
  }

  .input_text b {
    display: inline-block;
    width: 20px;
    height: 27px;
    margin-bottom: -8px
  }

  .input_password {
    /*border-bottom: none*/
  }

  .input_password b {
    display: inline-block;
    width: 20px;
    height: 27px;
    margin-bottom: -8px
  }

  .class-uesrB {
    background: url("../../assets/images/login&register/userName1.png") no-repeat;
    background-size: 100%
  }

  .class-uesrA {
    background: url("../../assets/images/login&register/userName2.png") no-repeat;
    background-size: 100%
  }
  .class-codeB {
    background: url("../../assets/images/login&register/userName1.png") no-repeat;
    background-size: 100%
  }

  .class-codeA {
    background: url("../../assets/images/login&register/userName2.png") no-repeat;
    background-size: 100%
  }
  .class-mobileB {
    background: url("../../assets/images/login&register/userName1.png") no-repeat;
    background-size: 100%
  }

  .class-mobileA {
    background: url("../../assets/images/login&register/userName2.png") no-repeat;
    background-size: 100%
  }

  .class-passA {
    background: url("../../assets/images/login&register/password2.png") no-repeat;
    background-size: 100%
  }

  .class-passB {
    background: url("../../assets/images/login&register/password1.png") no-repeat;
    background-size: 100%
  }

  .checkboxBox-a {
    background: url("../../assets/images/login&register/chebox3.png") no-repeat;
    background-size: 100%;
    margin-bottom: -4px
  }

  .checkboxBox-b {
    background: url("../../assets/images/login&register/chebox.png") no-repeat;
    background-size: 100%;
    margin-bottom: -4px
  }

  .wrapper {
    margin-bottom: 10px;
  }

  .checkbox-box {
    padding-left: .6rem;
    margin-top: 1rem;
    font-size: 0.55rem;
  }

  .checkbox-box span {
    display: inline-block;
    width: 24px;
    height: 22px;
  }
  .checkbox-box b{display: inline-block;width: 115px;}
  .checkbox-box .text{color: #e60039}
  .box .login-box .login-btn {
    margin: 0.6rem;
    text-align: center;
    color: #fff;
    padding: 0.2rem 0;
    border-radius: 0.8rem;
    font-size: 0.75rem;
    background-color: #e60039;
  }

  .methods {
    margin: 0.6rem;
    font-size: 0.65rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .methods a {
    display: flex;
    align-items: center;
  }

  .methods a>img {
    margin-right: 0.2rem;
    width: 0.7rem;
    height: 0.7rem;
  }

  .methods .m-msg a>img {
    width: 0.9rem;
    height: 0.9rem;
  }
</style>

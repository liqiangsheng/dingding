<template>
  <div class="container">
    <Mheader>
      <div slot="title">密码管理</div>
      <!--<div slot="info" @click='saveUserInfo'>保存</div>-->
    </Mheader>
    <div class="setHome">
      <div id="infoHomeup">
        <router-link to="/MyAddress">
          <mt-cell title="修改登录密码">
            <span><img src="../../assets/images/arrow.png" /></span>
          </mt-cell>
        </router-link>
        <router-link to="/MyAddress">
          <mt-cell title="设置交易密码">
            <span><img src="../../assets/images/arrow.png" /></span>
          </mt-cell>
        </router-link>


      </div>
    </div>
  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  export default {
    components: {
      Mheader,
    },
    data() {
      return {
        mhsData:"",
      }
    },
    methods: {


    },
    mounted: function() {
      this.$nextTick(() => {
        this.mhsData=JSON.parse(localStorage.mhsData)
        console.log(this.mhsData,'000')

      })
    }
  }
</script>

<style >

</style>

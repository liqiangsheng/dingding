<template>
  <div class="container1" style="overflow: hidden">
    <!--<Mheader></Mheader>-->
    <div class="top">
      <div class="top_header">
        <router-link to="/MyTheSetup">
          <div class="Setupthe">
            <img src="../../assets/images/myHome/set@2x.png"/>
          </div>
        </router-link>
        <!--<router-link to="/MySet">-->
          <div class="head"  @click="linkIf">
            <div class="avatar lm-margin-r-lg">
              <img  v-lazy="this.headIco!= null ? imgBaseUrl+this.headIco : src" alt="" />

            </div>
            <div class="info ">
              <div class="name lm-margin-l-sm" v-if="auth">{{mobile}}<span class="rightSpan"><img
                src="../../assets/images/myHome/jiantou2@2x.png"/></span></div>
              <div v-else>请点击登录</div>
              <div class="cb lm-margin-t-xs">
              </div>
            </div>
          </div>
        <!--</router-link>-->
      </div>

      <div class="Thewallet">
        <div class="Thewallet_top">
          <!--<img src="../../assets/images/myHome/qianbao@2x.png" alt="">-->
          <!--<span>我的钱包</span>-->
        </div>
        <div class="Thewallet_botton">
          <div>
            <p>可用积分</p>
            <b>{{moneyData.currencyIntegral!==undefined?returnFloat(moneyData.currencyIntegral):'0.00'}}</b>
          </div>
          <div class="Thewallet_botton_center">
            <p>易物券</p>
            <b> {{moneyData.accelerateValue!==undefined?returnFloat(moneyData.accelerateValue):'0.00'}}</b>
          </div>
          <!--<div>-->
          <!--<p>积分额度</p>-->
          <!--<b>{{moneyData.totalNonArrivalScore}}</b>-->
          <!--</div>-->
        </div>
      </div>

      <div class="TheOrder">
        <ul>
          <router-link to="/MyWalletHome">
            <li>
              <span class="TheOrder_left"><img src="../../assets/images/myHome/tuiguang@2x.png"/></span>
              <span class="TheOrder_center">我的钱包</span>
              <span class="TheOrder_right"><img src="../../assets/images/myHome/jiantou@2x.png"/></span>
            </li>
          </router-link>
          <router-link to="/MyOrder/待付款/0">
            <li>
              <span class="TheOrder_left"><img src="../../assets/images/myHome/fankui@2x.png"/></span>
              <span class="TheOrder_center">我的订单</span>
              <span class="TheOrder_right"><img src="../../assets/images/myHome/jiantou@2x.png"/></span>
            </li>
          </router-link>
          <!--<li>-->
          <!--<span class="TheOrder_left"><img src="../../assets/images/myHome/jifen@2x.png"/></span>-->
          <!--<span class="TheOrder_center">积分转增</span>-->
          <!--<span class="TheOrder_right"><img src="../../assets/images/myHome/jiantou@2x.png"/></span>-->
          <!--</li>-->
          <router-link to="/MyTopromote">
            <li>
              <span class="TheOrder_left"><img src="../../assets/images/myHome/tuiguang@2x.png"/></span>
              <span class="TheOrder_center">我的推广</span>
              <span class="TheOrder_right"><img src="../../assets/images/myHome/jiantou@2x.png"/></span>
            </li>
          </router-link>
          <router-link to="/MyCollection">
            <li>
              <span class="TheOrder_left"><img src="../../assets/images/myHome/shoucang@2x.png"/></span>
              <span class="TheOrder_center">我的收藏</span>
              <span class="TheOrder_right"><img src="../../assets/images/myHome/jiantou@2x.png"/></span>
            </li>
          </router-link>
        </ul>
      </div>

      <div class="TheOrder Customer ">
        <ul>
          <router-link to="/CustomerHome">
            <li>
              <span class="TheOrder_left"><img src="../../assets/images/myHome/help@2x.png"/></span>
              <span class="TheOrder_center">客服中心</span>
              <span class="TheOrder_right"><img src="../../assets/images/myHome/jiantou@2x.png"/></span>
            </li>
          </router-link>

          <router-link to="/AgreementHome">
            <li>
              <span class="TheOrder_left"><img src="../../assets/images/myHome/agreement.png"/></span>
              <span class="TheOrder_center">相关协议</span>
              <span class="TheOrder_right"><img src="../../assets/images/myHome/jiantou@2x.png"/></span>
            </li>
          </router-link>

        </ul>

      </div>
    </div>
    <Mfooter :myCenterCurrent='true'></Mfooter>
  </div>
</template>

<script>
  import Mheader from '../../components/Mheader'
  import Mfooter from '../../components/Mfooter'
  import {Toast} from 'mint-ui'
  import axios from 'axios';

  export default {
    components: {
      Mheader,
      Mfooter
    },
    data() {
      return {
        src: require("../../assets/images/myTopromote/login_03.png"),
        moneyData: '',
        auth:localStorage.auth,
        imgURl: 'http://preimg.mhsapp.com/',
        mobile: localStorage.getItem('mobile'),
        headIco: localStorage.getItem('headIco'),
        user: '',
        userHeadImg: require("../../assets/images/home_03.png") //默认头像
      }
    },

    methods: {
      linkIf(){
        if(!!localStorage.auth){
          this.$router.push({
            path: '/MySet'
          });
        }else{
          this.$router.push({
            path: '/Login'
          });
        }

      },
      returnFloat(value) {
        let value1 = Math.round(parseFloat(value) * 100) / 100;
        //console.log(typeof value1 + '22')
        let xsd = value1.toString().split(".");
        if(xsd.length == 1) {
          value = value1.toString() + ".00";
          return value;
        }
        if(xsd.length > 1) {
          if(xsd[1].length < 2) {
            value = value.toString() + "0";
            //console.log(typeof value + 'type2222222')
          }
          return value;
          //console.log(value)
        }
      },
      signOut() {
        localStorage.clear(); //清楚全部的localStorage
        this.$router.push({
          path: '/Login'
        });
      },
      getUserInfo() {
        let data = {
          'global': this.global
        }
        axios.post(this.apiJSON.index_atsTotalAccount, JSON.stringify(data), {
          headers: {'content-Type': 'text/mhs-', auth: localStorage.auth}
        }).then((response) => {
          if (response.data.code == '000000') {
            console.log(response.data.body, 'response.data')
            this.moneyData = response.data.body
          } else {
            // Toast(response.data.message)
          }

        }).catch((error) => {
        });
      }

    },
    mounted: function () {
      this.$nextTick(() => {
        this.getUserInfo();
      })
    }
  }
</script>

<style scoped>
  .top {
    position: relative;
    margin-bottom: 3.5rem
  }

  .top_header {
    margin-bottom: 2rem !important;
  }

  .Setupthe {
    width: 100%;
    height: 2rem;
    background: #f14a52;
    position: relative;
  }

  .Setupthe img {
    position: absolute;
    top: .6rem;
    right: .6rem;
    z-index: 999999;
    width: 1rem;
    height: 1rem
  }

  .rightSpan {
    display: inline-block;
    width: 16%;
    float: right
  }

  .rightSpan img {
    width: .8rem;
    height: .8rem
  }

  .Thewallet {
    font-size: 0.55rem;
    position: absolute;
    top: 7rem;
    left: 0;
    right: 0;
    width: 90%;
    margin: 0 auto;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    -webkit-box-shadow: #666 0px 0px 10px;
    -moz-box-shadow: #666 0px 0px 10px;
    box-shadow: #666 0px 1px 1px;
    background: #fff;
    margin-bottom: .2rem;
  }

  .Thewallet_top {
    width: 100%;
    line-height: 1.6rem;
    display: flex;
    margin: .5rem 0;
    background: url("../../assets/images/myHome/b_bg@1x.png") no-repeat;
  }

  .Thewallet_top img {
    width: 1rem;
    height: 1.1rem;
    margin-bottom: 1.1rem;
    margin-left: .6rem;
  }

  .Thewallet_top span {
    flex: 1;
    color: #fff;
    display: inline-block;
    margin-top: -.3rem;
    font-size: 0.55rem;
    padding-left: .1rem
  }

  .Thewallet_botton {
    width: 100%;
    display: flex;
    text-align: center;
    margin-top: -0.8rem;
  }

  .Thewallet_botton div {
    flex: 1;
    color: #262626;
    font-weight: 500;
  }

  .Thewallet_botton b {
    color: #ff4e60;
    font-weight: 600;
    display: inline-block;
    margin-top: .3rem;
    padding: 0 .2rem .4rem;
  }

  .Thewallet_botton p {
    margin: .2rem;
  }

  .Thewallet_botton_center {
    border-right: 1px solid #f0f0f0;
    border-left: 1px solid #f0f0f0
  }

  .TheOrder {
    margin-top: 4rem;
    font-size: 0.55rem;
    border: 1px solid #f0f0f0;
    width: 90%;
    margin: 0 auto;
    height: 100%;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    -webkit-box-shadow: #666 0px 0px 10px;
    -moz-box-shadow: #666 0px 0px 10px;
    box-shadow: #666 0px 1px 1px;
    background: #fff;
    margin-bottom: 1rem;
  }

  .TheOrder ul {
  }

  .TheOrder img {
    width: 100%;
    height: 100%
  }

  .TheOrder ul li {
    border-top: 1px solid #f0f0f0;
    padding: .8rem .5rem;
    display: flex;
  }

  /*.TheOrder ul  li img{width: 1rem;height: 1rem;}*/

  .TheOrder_left,
  .TheOrder_right {
    display: inline-block;
    width: 20px;
    height: 20px;
  }

  .TheOrder_center {
    flex: 1;
    padding-left: .5rem;
  }

  /*.TheOrder_right img{width: .6rem !important;height: .6rem!important}*/

  .head {
    display: flex;
    align-items: center;
    padding: .6rem 0 3rem 1rem;
    color: #ffffff;
    background-color: #e91f47;
    background: url("../../assets/images/myHome/bg@2x.png") no-repeat;
  }

  .head .avatar {
    width: 4rem;
    height: 3rem;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
  }

  .head .avatar img {
    border-radius: 50%;
  }

  .info {
    width: 100%;
    font-size: 0.75rem;
  }

  .info .cb a {
    display: flex;
    align-items: center;
    font-size: 0.6rem;
    border-radius: 0.6rem;
    padding: 0.2rem 1rem 0.2rem 0.3rem;
    background-color: #8E1C20;
  }

  .info .cb i {
    display: inline-block;
    width: 0.8rem;
    height: 0.8rem;
    background-size: 100% 100%;
    background-image: url("../../assets/images/myInfo/myInfo_03.png");
  }

  .my-order {
    margin-bottom: 0.5rem;
    background-color: #ffffff;
    font-size: 0.65rem;
  }

  .my-order .title {
    padding: 0.5rem;
    border-bottom: 1px solid #eee;
  }

  .my-order .order-control {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 1rem 0.6rem 1rem;
  }

  .order-control .control-icon,
  .server-control .control-icon {
    display: flex;
    flex-direction: column;
    align-items: center;
    font-size: 0.55rem;
  }

  .order-control .control-icon > img,
  .server-control .control-icon > img {
    width: 2.2rem;
    height: 2.2rem;
  }

  .order-control .control-icon > div,
  .server-control .control-icon > div {
    margin-top: -0.3rem;
  }

  .my-order .server-control {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0.4rem 1rem 1.2rem 1rem;
  }

  .my-order .server-control:last-child {
    border-top: 1px solid #eee;
  }
</style>

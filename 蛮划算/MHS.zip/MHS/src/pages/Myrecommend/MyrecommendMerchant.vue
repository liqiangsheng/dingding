<template>
  <div class="container">
    <Mheader>
      <div slot="title">推广商户</div>
    </Mheader>
    <div class="merchant">
      <p><img src="../../assets/images/myTopromote/logo.jpg" alt=""></p>
      <p>注册蛮划算商户版App,轻松开店赚钱</p>
      <p class="merchant_btn" @click="merchant"> 立即注册</p>
    </div>
    <div class="Myrecommend">

      <p>1、让朋友扫码下面的二维码，即可安装蛮划算App</p>
      <vue-qr  :logoSrc="src2" :text='text' height="100" width="100"></vue-qr>
        <p>我的邀请码：<span>{{mhsData.spreadCode}}</span></p>
    </div>
  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  import VueQr from 'vue-qr'
  export default {
    components: {
      Mheader,
      VueQr
    },
    data() {
      return {
        mobile:1111111111111,
        mhsData:'',
        text:'',
        src2: require('../../assets/images/myTopromote/logo.jpg'),
      }
    },
    methods: {
      merchant(){
        window.location.href=''+this.apiCentet+'/business/business.html?uid='+this.mhsData.spreadCode+'&mobile='+this.mhsData.mobile+''; //跳转的地址
      }
    },
    mounted: function() {
      this.$nextTick(() => {
        if(!!localStorage.mhsData){
          this.mhsData=JSON.parse(localStorage.mhsData)
          // console.log(this.mhsData.spreadCode,this.mhsData.mobile,'000')
          this.text=''+this.apiCentet+'/business/business.html?uid='+this.mhsData.spreadCode+'&mobile='+this.mhsData.mobile+''
        }

      })

    }
  }
</script>

<style >
  html{background: #f4f4f4}
  .merchant{text-align: center;background: #fff;margin-top: 2.2rem;padding-top: 1rem;font-size: 0.55rem;color: #999;padding-bottom: 1rem}
  .merchant p{padding: .3rem}
  .merchant_btn{width: 40%;background: red;margin: 0 auto;color: #fff;border-radius: .3rem;}
  .merchant img{width: 2rem}
  .Myrecommend{margin: 0 auto;text-align: center;margin-top:.6rem;background: #fff;font-size: 0.55rem}
  .Myrecommend p{margin-bottom: 1rem ;padding: .4rem}
  .Myrecommend img{width: 7rem;}
  .Myrecommend span{color:red;font-weight: 900 }
</style>

<template>
  <div class="container">
    <Mheader id="header_myfans">
      <div slot="title">我的粉丝</div>
      <div slot="info" @click="open" >我的推荐人</div>
    </Mheader>
      <div class="myfans_box">
            <div class="myfans_box_top">
              <p>总人数（人）</p>
              <p class="myfans_box_num">{{fansCountdata.directFans+fansCountdata.indirectFans}}</p>
            </div>
            <div class="myfans_box_bottom">
              <span class="myfans_box_right">
                <p>直接粉丝</p>
                <p>{{fansCountdata.directFans}}人</p>
              </span>
              <span class="myfans_box_botm">
                <p>间接粉丝</p>
                <p>{{fansCountdata.indirectFans}}人</p>
              </span>
            </div>
      </div>

    <div class="forum-box" v-infinite-scroll="loadMore1" infinite-scroll-disabled="loading"
         infinite-scroll-distance="10">
      <div class="fans_data">
        <div class="fans_data_box" v-for="(item,index) in fansList">
        <span class="fans_data_box_img">
           <!--<img v-lazy="imgBaseUrl+item.headIco" />-->
           <img  v-lazy="item.headIco!= null ? imgBaseUrl+item.headIco : src" alt="" />

        </span>
          <span class="fans_data_box-center">
          <p>{{item.userName}}</p>
          <p v-if="item.realName">认证姓名：{{item.realName}}</p>
          <p v-else="item.userName">认证姓名：{{item.userName}}</p>
        </span>
          <span class="fans_data_box-bottom">
          <p>间接粉丝：{{item.indirectFans}}人</p>
        </span>
        </div>
      </div>
      <div class="loading" v-show="isLoading">
        <mt-spinner :type="3" color="#999"></mt-spinner>
        <span class="lm-margin-l-sm lm-text-grey">加载中...</span>
      </div>
    </div>


    <Mdialog :dialog="dialog">
      {{GETmyusRefedata}}
      <div slot="content">
        <div class="dialog_span">
            <span class="dialog_span_left">
               <img v-lazy="imgBaseUrl+GETmyusRefedata.head_ico" />
              <!--<img  v-lazy="GETmyusRefedata.head_ico!= null ? imgBaseUrl+GETmyusRefedata.head_ico : src" alt="" />-->
            </span>
          <span>
              <p>{{GETmyusRefedata.realName}}</p>
              <p>ID：{{GETmyusRefedata.spreadCode}}</p>
              <p>tell：{{GETmyusRefedata.mobile}}</p>

            </span>
        </div>
      </div>

      <div slot="btn" @click="close">确定</div>
    </Mdialog>





  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  import Mdialog from '../../components/Mdialog'

  export default {
    components: {
      Mheader,
      Mdialog
    },
    data() {
      return {
        fansCountdata:'',
        src: require("../../assets/images/myTopromote/login_03.png"),
        fansList:[],
        GETmyusRefedata:'',
        dialog: null,
        isNewest: true, //是否最新
        pageSize: 0, //当前页码
        isLoading: false, //是否显示加载中...
      }
    },
    methods: {
      open() {
        this.dialog = true
      },
      close() {
        this.dialog = false
      },
      loadMore1() {
        this.loading = true;
        this.isLoading = true;
        this.pageSize++;
        if (this.isNewest) {
          this.getFans(this.pageSize);
        }

      },
    getFans(){
      let data = {
        'body': {
          pageNum: this.pageSize,
          pageSize: 10,
          userId: localStorage.uid
        },
        'global': this.global
      }
      this.axios.post(this.apiJSON.my_usFansList, JSON.stringify(data), {
        headers: {
          'content-Type': 'text/mhs-'
        }
      }).then((response) => {
        if (response.data.code == '000000') {
          this.fansCountdata=response.data.body.fansCount
          if (response.data.body.directFansList.length > 0) {
            for (let i = 0; i < response.data.body.directFansList.length; i++) {
              let temp = response.data.body.directFansList[i];
              this.fansList.push(temp)
              // console.log(this.fansList)
            }
            this.loading = false;
          } else {
            this.isLoading = false;
            Toast("暂无数据更多")
          }
          // this.DataList = response.data.body
          // console.log(this.DataList)
        } else {
          Toast(response.data.message)
        }

      }).catch((error) => {

      });
    },
      GETmyusRefe(){
        let data = {
          'body': {
            userId: localStorage.uid
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.my_usReferrerInfomation, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if (response.data.code == '000000') {
            this.GETmyusRefedata=response.data.body
            // console.log(this.GETmyusRefedata,'GETmyusRefe')
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });

      }
    },
    mounted: function() {
      this.$nextTick(() => {
        this.GETmyusRefe()
      })
    }
  }
</script>

<style >
#header_myfans{background: #f04b52;font-size: 0.55rem;color: #fff}
  .myfans_box{height: 11rem;background: url("../../assets/images/myTopromote/bg@3x.png") no-repeat;color: #fff;font-size: 0.55rem;background-size: 100% 100%}
  .myfans_box_top{width: 50%;margin: 0 auto;text-align: center;padding-top: 3rem}
  .myfans_box_top p {padding: .4rem;padding-bottom: 1rem}
  .myfans_box_num{font-size: 1.6rem}
  .myfans_box_bottom{display: flex;text-align: center}
  .myfans_box_bottom span{flex: 1}
  .myfans_box_right{border-right: 2px solid #ffc5cd}
  .myfans_box_right p{padding: .2rem}
  .myfans_box_botm p{padding: .2rem}
  .fans_data_box{padding: .6rem;display: flex;font-size: 0.55rem;color: #999}
  .fans_data_box_img{display: inline-block;width: 2rem;height:2rem;border:1px solid #fff;border-radius: 50%}
  .fans_data_box_img img{border-radius: 50%}
  .fans_data_box-center{flex: 1}
  .fans_data_box-center p{padding: .2rem}
  .fans_data_box-bottom p{padding: .6rem}
  .dialog_span{font-size: 0.55rem}
  .dialog_span_left{width: 2rem;height: 2rem}
</style>

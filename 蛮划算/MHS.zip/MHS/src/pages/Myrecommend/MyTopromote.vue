<template>
  <div class="container">
    <Mheader>
      <div slot="title">我的推广</div>
      <!--<div slot="info" @click='saveUserInfo'>保存</div>-->
    </Mheader>
    <div class="setHome">
      <div id="infoHomeup">
        <router-link to="/Myrecommend">
          <mt-cell title="推广用户">
            <img slot="icon" src="../../assets/images/myTopromote/ziying@2x.png" >
            <span><img src="../../assets/images/arrow.png" /></span>
          </mt-cell>
        </router-link>

        <router-link to="/MyrecommendMerchant">
          <mt-cell title="推广商户">
            <img slot="icon" src="../../assets/images/myTopromote/ziying@2x.png" >
            <span><img src="../../assets/images/arrow.png" /></span>
          </mt-cell>
        </router-link>

        <router-link to="/Myfans">
        <mt-cell title="我的粉丝">
          <img slot="icon" src="../../assets/images/myTopromote/ziying@2x.png" >
          <span><img src="../../assets/images/arrow.png" /></span>
        </mt-cell>
        </router-link>
      </div>
    </div>


    <mt-datetime-picker ref="picker" type="date" v-model="user.Birthday" :startDate="startYear" :endDate="endYear" year-format="{value} 年" month-format="{value} 月" date-format="{value} 日">
    </mt-datetime-picker>
  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  export default {
    components: {
      Mheader,
    },
    data() {
      return {
        imgURl:'http://img.mhsapp.com/',
        mhsData:"",
        value: '',
        startYear: new Date(new Date().getFullYear() - 70, 0, 1),
        endYear: new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDay()),
        user: '',
        userHeadImg: require("../../assets/images/home_03.png") //默认头像
      }
    },
    filters: {
      intercept(value) {
        let birthday = new Date(value);
        birthday = birthday.getFullYear() + '年' + (birthday.getMonth() + 1) + '月' + birthday.getDate() + '日'
        return birthday
      }
    },
    methods: {
      openPicker() {
        this.$refs.picker.open();
      },
      signOut() {
        localStorage.clear(); //清楚全部的localStorage
        this.$router.push({
          path: '/Login'
        });
      },
      //获取用户信息
      getUserInfo() {
        this.axios({
          url: this.url + '/api/User/GetUserInfoByUserId',
          method: 'get',
          headers: {
            'Authorization': 'BasicAuth ' + localStorage.lut
          }

        }).then((res) => {
          if(!!res) {
            if(res.data.Code == 200) {
              this.user = res.data.ExData;
            } else {
              Toast(res.data.Data);
            }
          }
        })
      },
      //更新头像
      updateHeadImg(e) {
        let file = e.target.files[0];
        let param = new FormData(); //创建form对象
        param.append('file', file, file.name); //通过append向form对象添加数据
        param.append('chunk', '0'); //添加form表单中其他数据

        let config = {
          headers: {
            'Content-Type': 'multipart/form-data',
            'Authorization': 'BasicAuth ' + localStorage.lut
          }
        }; //添加请求头
        this.axios.post(this.url + '/api/User/SaveHeadImg', param, config)
          .then(res => {
            if(res.data.Code = 200) {
              this.user.HeadImg = res.data.ExData;
              Toast(res.data.Data);
            } else {
              Toast(res.data.Data);
            }
          })
      },

      //保存用户信息
      saveUserInfo() {
        if(!!!this.user.UserName) {
          Toast('请填写昵称！');
          return false;
        }
        if(this.user.UserName.length > 8) {
          Toast('昵称过长，请控制在8个字以内！');
          return false;
        }
        if(!!!this.user.Sex) {
          Toast('请选择性别！');
          return false;
        }
        if(!!!this.user.Birthday) {
          Toast('请填写生日！');
          return false;
        }
        this.axios({
          url: this.url + '/api/User/SaveUserInfo',
          method: 'post',
          data: {
            UserName: this.user.UserName,
            Sex: this.user.Sex,
            Birthday: this.user.Birthday
          },
          headers: {
            'Authorization': 'BasicAuth ' + localStorage.lut
          }

        }).then((res) => {
          if(!!res) {
            if(res.data.Code == 200) {
              Toast(res.data.Data);
            } else {
              Toast(res.data.Data);
            }
          }
        })
      }

    },
    mounted: function() {
      this.$nextTick(() => {
        // this.getUserInfo();
        this.mhsData=JSON.parse(localStorage.mhsData)
        console.log(this.mhsData,'000')

      })
    }
  }
</script>

<style >
  .setHome{height: 100%;background-color:#f4f4f4 ;overflow: hidden}

  .avatar_left{flex: 0.8}
  .avatar_right>img {
    width: 2rem;
    height: 2rem;
    border-radius: 50%;
  }
  .avatar_right .upImg {
    height: 2rem;
    width: 2rem;
    position: absolute;
    top: 1.2rem;
    left: 85%;
    transform: translateX(-50%);
    opacity: 0;
  }

  #infoHomeup img{width: 0.8rem}
  #infoHomeup span{;display:inline-block;padding-left: .4rem;font-size: 0.55rem}
  .infoHome_text{margin-right: 1rem}
  #infoHomeup .mint-cell-wrapper{ background-size: 100% 0 !important;border-bottom: 1px solid #efefef}
</style>

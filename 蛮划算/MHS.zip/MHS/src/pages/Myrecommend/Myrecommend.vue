<template>
  <div class="container">
    <Mheader>
      <div slot="title">推广用户</div>
    </Mheader>
    <div class="Myrecommend">
    <p>1、让朋友扫码下面的二维码，即可安装蛮划算APP</p>
      <vue-qr  :logoSrc="src2" :text='text' height="100" width="100"></vue-qr>
        <p>我的邀请码：<span>{{mhsData.spreadCode}}</span></p>
    </div>
  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  import VueQr from 'vue-qr'
  export default {
    components: {
      Mheader,
      VueQr
    },
    data() {
      return {
        mobile:1111111111111,
        mhsData:'',
        text:'',
        src2: require('../../assets/images/index_home/logo.png'),
      }
    },
    methods: {
    },
    mounted: function() {
      this.$nextTick(() => {
        if(!!localStorage.mhsData){
          this.mhsData=JSON.parse(localStorage.mhsData)
          console.log(this.mhsData.spreadCode,this.mhsData.mobile,'000')
          this.text=''+this.apiCentet+'/user/user.html?uid='+this.mhsData.spreadCode+'&mobile='+this.mhsData.mobile+''
        }

      })

    }
  }
</script>

<style >
  html{background: #f4f4f4}
  .Myrecommend{margin: 0 auto;text-align: center;margin-top: 2.2rem;background: #fff}
  .Myrecommend p{margin-bottom: 1rem ;padding: .4rem}
  .Myrecommend img{width: 7rem;}
  .Myrecommend span{color:red;font-weight: 900 }
</style>

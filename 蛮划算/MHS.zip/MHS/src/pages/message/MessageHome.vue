<template>
  <div class="container">
    <Mheader>
      <div slot="title">消息</div>
    </Mheader>


    <div class="box_mssage">
      <router-link :to="{path:'/OrderMessage/'+orderMessage.messageType}">
        <div class="message_box one-top">
          <div class="message_img">
            <img src="../../assets/images/message/message_dingdan@2x.png" alt="">
          </div>
          <div class="message_text">
            <p class="message_text_top">
              <span class="message_text_top_LeftSpan">订单消息</span>
              <span class="message_text_top_rightSpan">{{orderMessage.updateTime}}</span>
            </p>
            <p class="message_text_bottom">{{orderMessage.messageTitle}}</p>
          </div>
        </div>
      </router-link>
      <router-link :to="{path:'/OrderMessage/'+integralMessage.messageType}">
        <div class="message_box">
          <div class="message_img">
            <img src="../../assets/images/message/message_jifen@2x.png" alt="">
          </div>
          <div class="message_text">
            <p class="message_text_top">
              <span class="message_text_top_LeftSpan">积分消息</span>
              <span class="message_text_top_rightSpan">{{integralMessage.updateTime}}</span>
            </p>
            <p class="message_text_bottom">{{integralMessage.messageTitle}}</p>
          </div>
        </div>
      </router-link>

      <router-link :to="{path:'/OrderMessage/'+systemMessage.messageType}">
        <div class="message_box">
          <div class="message_img">
            <img src="../../assets/images/message/message_xitong@2x.png" alt="">
          </div>
          <div class="message_text">
            <p class="message_text_top">
              <span class="message_text_top_LeftSpan">系统消息</span>
              <span class="message_text_top_rightSpan">{{systemMessage.updateTime}}</span>
            </p>
            <p class="message_text_bottom">{{systemMessage.messageTitle}}</p>
          </div>
        </div>
      </router-link>

    </div>

  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import {Toast} from 'mint-ui'

  export default {
    components: {
      Mheader,
    },
    data() {
      return {
        messageData: "",
        orderMessage: '',//订单消息
        systemMessage: '',//系统消息
        integralMessage: '',//积分消息
      }
    },
    methods: {

      getMessage() {
        let data = {
          'body': {
            pageNum: this.pageSize,
            pageSize: 10,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.index_ssQueryMessageTypeList, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if (response.data.code == '000000') {
            this.messageData = response.data.body
            this.messageData.forEach(item => {
              console.log(item.messageType)
              if (item.messageType == 1) {
                this.orderMessage = item
              }
              if (item.messageType == 5) {
                this.systemMessage = item
              }
              if (item.messageType == 6) {
                this.integralMessage = item
              }
            })
            console.log(this.messageData, 'body')
          } else {
            Toast(response.data.message)
          }
        }).catch((error) => {

        });
      },

    },
    mounted: function () {
      this.$nextTick(() => {
        this.getMessage()

      })
    }
  }
</script>

<style>
  html {
    background: #f4f4f4
  }

  .message_header {
    background: red
  }

  .one-top {
    margin-top: 2.2rem;
  }

  .message_box {
    background: #fff;
    padding: .4rem;
    margin-bottom: .2rem
  }

  .message_box {
    display: flex;
    font-size: 0.56rem
  }

  .message_img {
    margin: 0 .4rem
  }

  .message_img {
    width: 2rem
  }

  .message_text {
    width: 100%;
  }

  .message_text p {
    margin: 0 .2rem .2rem
  }

  .message_text_top {
    display: flex
  }

  .message_text_top span {
    flex: 1
  }

  .message_text_top_rightSpan {
    color: #cacaca
  }

  .message_text_bottom {
    color: #999
  }
</style>

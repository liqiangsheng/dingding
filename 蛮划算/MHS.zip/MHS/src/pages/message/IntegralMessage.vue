<template>
  <div class="container">
    <Mheader>
      <div slot="title">密码管理</div>
      <!--<div slot="info" @click='saveUserInfo'>保存</div>-->
    </Mheader>
    <div class="setHome">
      <div id="infoHomeup">
        <router-link to="/MyAddress">
          <mt-cell title="修改登录密码">
            <span><img src="../../assets/images/arrow.png" /></span>
          </mt-cell>
        </router-link>
        <router-link to="/MyAddress">
          <mt-cell title="设置交易密码">
            <span><img src="../../assets/images/arrow.png" /></span>
          </mt-cell>
        </router-link>


      </div>
    </div>
  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  export default {
    components: {
      Mheader,
    },
    data() {
      return {
        mhsData:"",
      }
    },
    methods: {


    },
    mounted: function() {
      this.$nextTick(() => {
        this.mhsData=JSON.parse(localStorage.mhsData)
        console.log(this.mhsData,'000')

      })
    }
  }
</script>

<style >
  .setHome{height: 100%;background-color:#f4f4f4 ;overflow: hidden}
  .avatar {
    position: relative;
    display: flex;
    /*flex-direction: column;*/
    align-items: center;
    justify-content: center;
    color: #999;
    padding: 1.2rem 0;
    background-color: #fff;
    margin-top:1rem;
    margin-bottom: 1rem;
  }
  .avatar_left{flex: 0.8}
  .avatar_right>img {
    width: 2rem;
    height: 2rem;
    border-radius: 50%;
  }
  .avatar_right .upImg {
    height: 2rem;
    width: 2rem;
    position: absolute;
    top: 1.2rem;
    left: 85%;
    transform: translateX(-50%);
    opacity: 0;
  }

  #infoHomeup img{width: 1rem}
  #infoHomeup span{;display:inline-block;padding-left: .4rem}
  .infoHome_text{margin-right: 1rem}
  #infoHomeup .mint-cell-wrapper{ background-size: 100% 0 !important;border-bottom: 1px solid #efefef}
</style>

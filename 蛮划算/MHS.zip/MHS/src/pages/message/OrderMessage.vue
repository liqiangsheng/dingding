<template>
  <div class="container">
    <Mheader>
      <div slot="title">全部消息</div>
      <!--<div slot="info" @click='saveUserInfo'>保存</div>-->
    </Mheader>
    <div style="margin-top: 2.2rem">

      <div class="forum-box" v-infinite-scroll="loadMore" infinite-scroll-disabled="loading" infinite-scroll-distance="10">
        <div class="orderMessage-box" v-for="(item,index) in orderData">
          <div>
            <p class="orderMessage_top"><img src="../../assets/images/message/message2@2x.png" alt="">  {{item.messageTitle}}</p>
            <p class="orderMessage_content">{{item.content}}</p>
            <p class="orderMessage_bottom">{{item.publishTime}}</p>
          </div>
        </div>
        <div class="loading" v-show="isLoading">
          <mt-spinner :type="3" color="#999"></mt-spinner>
          <span class="lm-margin-l-sm lm-text-grey">加载中...</span>
        </div>
      </div>
      </div>
  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  export default {
    components: {
      Mheader,
    },
    data() {
      return {
        orderData:[],
        pageNum:0,
        isNewest: true, //是否最新,
        isLoading: false, //是否显示加载中...

      }
    },
    methods: {
      loadMore() {
        this.loading = true;
        this.isLoading = true;
        this.pageNum++;
        if(this.isNewest) {
          this.GETorder(1);
        } else if(this.isHot) {
          // this.getLatestTopic(3);
        } else {
          // this.getThemeByThemeType();
        }

      },
    GETorder(){
      let data = {
        'body': {
          messageType: this.$route.params.MessageID,
          pageNum: this.pageNum,
          pageSize: 20
        },
        'global': this.global
      }
      this.axios.post(this.apiJSON.index_ssQueryMessageList, JSON.stringify(data), {
        headers: {
          'content-Type': 'text/mhs-'
        }
      }).then((response) => {
        if(response.data.code == '000000') {
          if(response.data.body.length > 0) {
            for(let i = 0; i < response.data.body.length; i++) {
              let temp = response.data.body[i];
              this.orderData.push(temp)
            }
            this.loading = false;
          } else {
            Toast('没有更多数据了')
            this.isLoading = false;
          }
        } else {
          this.isLoading = true;
        }
      }).catch((error) => {

      });
    }

    },
    mounted: function() {
      this.$nextTick(() => {
        // this.GETorder()

      })
    }
  }
</script>

<style >
  .orderMessage-box{background: #fff;margin-bottom: .2rem;font-size: 0.55rem}
.orderMessage-box img{width: 0.8rem}
  .orderMessage_top{padding: .6rem;border-bottom: 1px solid #eee}
  .orderMessage_content{padding: .6rem}
  .orderMessage_bottom{padding: .6rem;color: #999}
</style>

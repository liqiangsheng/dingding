<template>
	<div class="container address">
		<Mheader>
			<div slot="title">{{title}}</div>
		</Mheader>
		<div id="address">
			<ul>
				<li v-for="(item,index) in cityNamedata" @click="addressBOx(item)">
					<mt-cell style="background-size: 100% 0px">
						{{item.cityName}}
					</mt-cell>
				</li>
			</ul>

		</div>
		<Mfooter :myCenterCurrent='true'></Mfooter>
	</div>
</template>

<script>
	import Mheader from '../../components/Mheader'
	import Mfooter from '../../components/Mfooter'
	import { CellSwipe } from 'mint-ui'
	import { address, slots } from '../../components/linkage/address'

	export default {
		components: {
			Mheader,
			Mfooter,
			// Datajson
		},
		data() {
			return {
				title: '市选择',
				btnName: '修改',
				addressData: [],
				address: '',
				dataCity: '',
				cityNamedata: [],
				dataObj: '',
			}
		},
		watch: {

		},
		methods: {

			addressBOx(item) {
				this.dataObj = item
				sessionStorage.setItem("Citydata", JSON.stringify(this.dataObj));
				this.$router.push({
					name: 'AddressCounty',
					params: {
						dataObj: this.dataObj
					}

				})
				// console.log(item,'xiang')
			},

		},
		mounted() {
			this.dataCity = JSON.parse(sessionStorage.getItem('dataObj'));
			this.dataCity.cityList.forEach(item => {
				this.cityNamedata.push(item)
				// console.log(this.cityNamedata,'777')
			})
		}
	}
</script>

<style lang="scss">
	#address .mint-cell-title {
		flex: 0 !important;
	}
	
	.save {
		margin: 1.5rem auto;
		padding: 0.3rem 0;
		border-radius: 0.2rem;
		text-align: center;
		width: 50%;
		color: #ffffff;
		background-color: #B4282D;
	}
	
	.linkage-wrap {
		left: 4rem;
		width: 11rem;
		z-index: 999;
		top: 31%;
		position: absolute;
		.address-wrap {
			display: flex;
			justify-content: space-between;
			align-items: center;
			height: 30px;
			font-size: 14px;
			color: #333;
			.input {
				display: flex;
				align-items: center;
				flex: 1;
				height: 100%;
				padding: 0;
				box-sizing: border-box;
			}
			.btn {
				flex: 0 0 80px;
				width: 100%;
				height: 1.2rem;
				line-height: 30px;
				text-align: center;
				border: 1px solid #ccc;
				border-left: 0 none;
				box-sizing: border-box;
				position: absolute;
				opacity: 0;
			}
		}
		.pick-mark {
			position: fixed;
			left: 0;
			top: 0;
			bottom: 0;
			right: 0;
			z-index: 999;
			.btn-wrap {
				position: absolute;
				left: 0;
				right: 0;
				bottom: 180px;
				display: flex;
				justify-content: space-between;
				align-items: center;
				height: 40px;
				padding: 0 20px;
				font-size: 14px;
				background: #fff;
				.btn-cancel {
					color: #999;
				}
				.btn-sure {
					color: #B4282D;
				}
			}
			.select {
				position: absolute;
				left: 0;
				bottom: 0;
				width: 100%;
				background-color: #eeeeee;
			}
			.picker-items {
				font-size: 14px;
				background: #eee;
				.picker-slot {
					font-size: 14px;
				}
				.picker-item {
					&.picker-selected {
						color: #535353;
					}
				}
				.picker-center-highlight {
					&:after,
					&:before {
						background: #fff;
					}
				}
			}
		}
	}
</style>
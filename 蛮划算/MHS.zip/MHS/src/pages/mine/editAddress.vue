<template>
	<div class="container address">
		<Mheader>
			<div slot="title">{{title}}</div>
		</Mheader>
		<mt-field label="联系人" placeholder="请输入用户名" v-model="username" @blur.native.capture="changeCount()"></mt-field>
		<mt-field label="手机号" placeholder="请输入手机号" type="tel" v-model="phone" :attr="{maxlength:11}" @blur.native.capture="changeCountphone()"></mt-field>
		<router-link :to="{path:'/Address/'}">
			<mt-field label="所在地区" placeholder="请选择收货地址" v-model="address" style="background-size: 100% 0px"></mt-field>
		</router-link>
		<!--<div class="linkage-wrap">-->
		<!--<div class="address-wrap">-->
		<!--<span class="btn" @click="address_flag = true">点击选择</span>-->
		<!--</div>-->
		<!--<div class="pick-mark" v-show="address_flag" @click="address_flag = false">-->
		<!--<div class="btn-wrap">-->
		<!--<a class="btn-cancel" @click="address_flag = false">取消</a>-->
		<!--<a class="btn-sure" @click="fillAddress">确定</a>-->
		<!--</div>-->
		<!--<mt-picker class="select" :slots="slots" value-key="aname" @change="onValuesChange"></mt-picker>-->
		<!--</div>-->
		<!--</div>-->
		<mt-field label="详细地址" placeholder="请输入地址" v-model="detailAddress"></mt-field>
		<mt-cell title="">
			<!--<mt-switch v-model="isDefault"></mt-switch>-->
		</mt-cell>
		<div class="save" @click="save">{{btnName}}</div>
		<Mfooter :myCenterCurrent='true'></Mfooter>
	</div>
</template>

<script>
	import Mheader from '../../components/Mheader'
	import Mfooter from '../../components/Mfooter'
	import { Toast } from 'mint-ui'
	import { Popup } from 'mint-ui';
	import { address, slots } from '../../components/linkage/address'
	// import  Datajson from '../../components/linkage/Data'

	export default {
		components: {
			Mheader,
			Mfooter,
			// Datajson
		},
		data() {
			return {
				title: '添加地址',
				btnName: '保存',
				username:'',
				phone: '',
				address_flag: false,
				slots: slots,
				temp_addr: '',
				address: '',
				detailAddress: '',
				isDefault: false,
				data: '',
				cityList1: '',
				CityObj: '',
        provinceName:'',//省
        cityName:'',//市
        adressId:'',
			}
		},
		methods: {

			//
      changeCount(value){
        console.log(this.username,'22')
        sessionStorage.setItem('username', JSON.stringify(this.username));
      },
      changeCountphone(){
        console.log(this.phone,'33333')
        sessionStorage.setItem('phone', JSON.stringify(this.phone));
      },
			datatiyi() {
				let data = {
					'body': {
						userId: localStorage.uid,
						typeId: 1,
					},
					'global': this.global
				}
				this.axios.get('/static/js/Data.json', JSON.stringify(data)).then((response) => {
					this.data = response.data
					this.data.forEach(item => {
						this.cityList1 = item

					})
					if(response.data.code == '000000') {} else {
						Toast(response.data.message)
					}

				}).catch((error) => {

				});
			},
			//TODO:编辑的时候已选择的省份没有省市区插件没有选中
			fillAddress() {
				// 填入省市区
				this.address = this.temp_addr;
				this.address_flag = false;
				this.$emit('getAddress', this.address);
			},
			initAddress() {
				// console.log(address.provinceName,'2')
				address.forEach(item => {
					// console.log(item.provinceName)
					this.slots[0] = item.provinceName
				})
				// this.slots[0].values = address.filter((item, index) => {
				//   if (item.provinceId.length ==3) {
				//      return item;
				//   }
				// });
			},
			onValuesChange(picker, values) {
				// // 防止没有省份时报错
				// if (values[0]) {
				//   this.slots[1].values = address.filter((item, index) => {
				//     if (item.apid == values[0].aid) {
				//       return item;
				//     }
				//   });
				// }
				// 防止没有市时报错
				if(values[1]) {
					// this.slots[2].values = address.filter((item, index) => {
					//   if (item.apid ==values[1].aid) {
					//     return item;
					//   }
					// });
				}
				// 防止没有区时报错
				if(values[2]) {
					// 这里可以指定地址符，此处以空格进行连接
					// this.temp_addr = values[0].aname + ' ' + values[1].aname + ' ' + values[2].aname;
				}
			},
			isPhoneNo(phone) { //手机号验证
				var pattern = /^1[34578]\d{9}$/;
				return pattern.test(phone);
			},
			//添加新地址
			save() {
				if(!!!this.username.replace(/(^\s+)|(\s+$)/g, "")) {
					Toast('请填写联系人姓名');
					return;
				}
				if(!!!this.phone.replace(/(^\s+)|(\s+$)/g, "")) {
					Toast('请填写联系人手机号');
					return;
				}
				if(!this.isPhoneNo(this.phone.replace(/(^\s+)|(\s+$)/g, ""))) {
					Toast('手机号格式错误');
					return;
				}
				if(!!!this.address.replace(/(^\s+)|(\s+$)/g, "")) {
					Toast('请选择省市区');
					return;
				}
				if(!!!this.detailAddress.replace(/(^\s+)|(\s+$)/g, "")) {
					Toast('请填写详细的收货地址');
					return;
				}
				let str = this.address.split(' ');
				let data = {
					'body': {
						type: '2',
						userId: localStorage.uid,
						// provinceId:str[0],
						// cityId:str[1],
						// countyId:str[2],
            adressId:this.CityObj.adressId,
						provinceId: this.CityObj.provinceId,
						cityId: this.CityObj.cityId,
						countyId: this.CityObj.countyId,
						address: this.detailAddress.replace(/(^\s+)|(\s+$)/g, ""), //详细地址
						acceptName: this.username.replace(/(^\s+)|(\s+$)/g, ""), //联系人姓名
						mobile: this.phone.replace(/(^\s+)|(\s+$)/g, ""), //联系人电话
            isDefault: "0"
					},
					'global': this.global
				}
				this.axios.post(this.apiJSON.usGetAddDeleteModifyAdress, JSON.stringify(data), {
					headers: {
						'content-Type': 'text/mhs-',
						'auth': localStorage.auth
					}
				}).then((response) => {
					if(response.data.code == '000000') {
						let instance = Toast('添加（修改）成功');
						// sessionStorage.removeItem('CityObj'); //登录成功后移除浏览过的商品信息
            sessionStorage.removeItem('username'); //
            sessionStorage.removeItem('phone'); //
            setTimeout(() => {
							instance.close();
							this.$router.replace({
								path: '/MyAddress'
							});
						}, 1000);
					} else {
						Toast(response.data.message)
					}

				}).catch((error) => {

				});
			},
      Address(id){
        //我这里去数组是取this.add   这样是不对的 那你调用
        //传省份id
        //我先把id写死吧 好
          for (var i=0;i<address.length;i++) {

          }

      },
		},
		mounted() {

      console.log(address,'0-------')   //城市数组
      // this.datatiyi()
			// console.log(this.slots,'0')




			if(!!sessionStorage.CityObj) {
				this.CityObj = JSON.parse(sessionStorage.getItem('CityObj'));
				this.address = this.CityObj.provinceName + ' ' + this.CityObj.cityName + ' ' + this.CityObj.countyName;

				console.log(this.CityObj, 'popopoo')
			}
      this.$nextTick(() => {
       this.Address()
      })

			this.$nextTick(function() {
          if(this.$route.params.aId == 1) { //aid为0时是新增收货地址页面
					this.title = '编辑地址';
					this.btnName = '保存';
          if(!!sessionStorage.AddressEidt) {
            let AddressEidt=JSON.parse(sessionStorage.AddressEidt)
            console.log(AddressEidt,'AddressEidt')
            this.username = AddressEidt.acceptName;
            this.phone = AddressEidt.mobile;
            this.adressId=AddressEidt.adressId
            var provinceName=''
            var cityName=''
            var countyName=''
            //省
            address.forEach(item => {
              if(item.provinceId == AddressEidt.provinceId){
                provinceName=item.provinceName
                console.log(provinceName,'000999----')
              }
            })

          //市
            for (var i=0;i<address.length;i++){
              for (var j=0;j<address[i].cityList.length;j++){
                if(AddressEidt.cityId == address[i].cityList[j].cityId){
                  cityName=address[i].cityList[j].cityName
                    console.log(cityName,'9898989')
                }
              }
            }
            //县
            for (var i=0;i<address.length;i++){
              for (var j=0;j<address[i].cityList.length;j++){
                for (var k=0;k<address[i].cityList[j].countyList.length;k++){
                    if(address[i].cityList[j].countyList[k].countyId ==AddressEidt.countyId  ){
                      countyName=address[i].cityList[j].countyList[k].countyName
                      console.log(countyName)
                    }
                }
              }
            }

            this.address =provinceName  + ' ' + cityName + ' ' + countyName;   //三个id

            this.detailAddress=AddressEidt.address
          }
				} else {
					// //请求要编辑的地址信息
					// this.axios({
					// 	url: this.url + '/api/ReceiveAddress/GetAddressByAddressId',
					// 	method: 'post',
					// 	data: {
					// 		addressId: this.$route.params.aId
					// 	},
					// 	headers: {
					// 		'Authorization': 'BasicAuth ' + localStorage.lut
					// 	}
                    //
					// }).then((res) => {
					// 	if(!!res) {
					// 		if(res.data.Code == 200) {
					// 			let a = res.data.ExData;
					// 			this.username = a.ConsigneeName;
					// 			this.phone = a.Mobile;
					// 			this.address = a.Province + ' ' + a.City + ' ' + a.Area;
					// 			this.detailAddress = a.Detail;
					// 			this.isDefault = a.IsDefault == 0 ? true : false;
					// 		} else {
					// 			Toast(res.data.Data);
					// 		}
					// 	}
					// })
				}
				this.initAddress();
          if(!!sessionStorage.username){
            this.username=JSON.parse(sessionStorage.username)
          }
          if(!!sessionStorage.phone){
            this.phone=JSON.parse(sessionStorage.phone)
          }
			},
      )

		}
	}
</script>

<style lang="scss" scoped>
	.save {
		margin: 1.5rem auto;
		padding: 0.3rem 0;
		border-radius: 0.8rem;
		text-align: center;
		width:90%;
		color: #ffffff;
		background-color: #e6013a;
	}

	.linkage-wrap {
		left: 4rem;
		width: 11rem;
		z-index: 999;
		top: 31%;
		position: absolute;
		.address-wrap {
			display: flex;
			justify-content: space-between;
			align-items: center;
			height: 30px;
			font-size: 14px;
			color: #333;
			.input {
				display: flex;
				align-items: center;
				flex: 1;
				height: 100%;
				padding: 0;
				box-sizing: border-box;
			}
			.btn {
				flex: 0 0 80px;
				width: 100%;
				height: 1.2rem;
				line-height: 30px;
				text-align: center;
				border: 1px solid #ccc;
				border-left: 0 none;
				box-sizing: border-box;
				position: absolute;
				opacity: 0;
			}
		}
		.pick-mark {
			position: fixed;
			left: 0;
			top: 0;
			bottom: 0;
			right: 0;
			z-index: 999;
			.btn-wrap {
				position: absolute;
				left: 0;
				right: 0;
				bottom: 180px;
				display: flex;
				justify-content: space-between;
				align-items: center;
				height: 40px;
				padding: 0 20px;
				font-size: 14px;
				background: #fff;
				.btn-cancel {
					color: #999;
				}
				.btn-sure {
					color: #B4282D;
				}
			}
			.select {
				position: absolute;
				left: 0;
				bottom: 0;
				width: 100%;
				background-color: #eeeeee;
			}
			.picker-items {
				font-size: 14px;
				background: #eee;
				.picker-slot {
					font-size: 14px;
				}
				.picker-item {
					&.picker-selected {
						color: #535353;
					}
				}
				.picker-center-highlight {
					&:after,
					&:before {
						background: #fff;
					}
				}
			}
		}
	}
</style>

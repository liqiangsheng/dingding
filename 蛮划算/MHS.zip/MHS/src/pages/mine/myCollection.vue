<template>
	<div class="container">
		<Mheader :show=true>
			<div slot="title">我的收藏</div>
		</Mheader>


    <div class="page-navbar">
      <!-- navbar -->
      <mt-navbar class="page-part" v-model="selected" @click='test'>
        <mt-tab-item id="1">商品</mt-tab-item>
        <mt-tab-item id="2">商家</mt-tab-item>
      </mt-navbar>

      <!-- tabcontainer -->
      <mt-tab-container v-model="selected" >
        <mt-tab-container-item id="1">
          <div class="product_colle" v-for="(item,index) in productlist" :key='index'>
            <div class="product-img">
              <img :src="imgBaseUrl+item.imgUrl" alt="" style="width: 3rem;height: 3rem">
            </div>
            <div>
              <div>
                <div class="product-name">
                  <router-link :to="{path:'/ProductDetails/'+item.goodsId}">
                    <p> {{ item.goodsName }}</p>
                    <b class="product-score">增送 <span class="product-score_span">{{ item.score }}</span>积分额度</b>
                    <p><span class="lm-text-red">￥{{ item.appPrice }}</span></p>
                    <!--<span class="lm-text-grey lm-font-xs">{{ item.Name }}</span>-->
                  </router-link>
                </div>
                <!--<div class="product-delete" @click="deleteFavourite(item.goodsId)"></div>-->
              </div>
              <div class="product-price">

                <!--<div>￥ <span class="lm-text-red">{{ item.appPrice }}</span> 元</div>-->
                <!--<div class="go-buy">-->
                  <!--<router-link :to="{path:'/ProductDetails/'+item.goodsId}">-->
                    <!--去下单-->
                  <!--</router-link>-->

                <!--</div>-->
              </div>
            </div>
          </div>



          <!--<mt-cell v-for="n in 10" :title="'内容 ' + n" />-->
        </mt-tab-container-item>
        <mt-tab-container-item id="2">
          <div v-for="(item,index) in getMerchatData" class="merchan_box">
            <router-link :to="{path:'/Seller/'+item.sellerId}">
              <span class="merchan_box_img">
                <img :src="imgBaseUrl+item.headIco" alt="" >
              </span>
            <span>
              <p>{{item.trueName}}</p>
              <p class="merchan_box_p">{{item.updateTime}}</p>
            </span>
              </router-link>
          </div>
        </mt-tab-container-item>
      </mt-tab-container>
    </div>



		<Mfooter :myCenterCurrent="true"></Mfooter>

	</div>

</template>

<script>
	import Mheader from '../../components/Mheader'
	import Mfooter from '../../components/Mfooter'
	import { Toast } from 'mint-ui'
  import { Navbar, TabItem } from 'mint-ui';
	export default {
		components: {
			Mheader,
			Mfooter,
      Navbar,
      TabItem
		},
		data() {
			return {
        selected:'1',
				productlist: [],
        getMerchatData:[],
        dialog: null,
        isNewest: true, //是否最新
        pageSize: 1, //当前页码
        isLoading: false, //是否显示加载中...
			}
		},
		//获取收藏商品列表
		methods: {
      test(){
        console.log(1111)
        console.log(this.selected); // 这个currentTab就是实时更新的当前tab
      },
			getFavouriteInfo() {
        let data = {
          'body': {
            goodsId: this.$route.params.productID,
            pageNum: this.pageSize,
            pageSize: 10,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.Goods_gsQueryFavoriteGoods, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            this.productlist = response.data.body;
            console.log(this.productlist,'this.productlist')
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });




			},

      getMerchat(){
        let data = {
          'body': {
            pageNum: this.pageSize,
            pageSize: 20,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.Goods_msGetFavorites, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-'
          }
        }).then((response) => {
          if (response.data.code == '000000') {
            if (response.data.body.length > 0) {
              for (let i = 0; i < response.data.body.length; i++) {
                let temp = response.data.body[i];
                this.getMerchatData.push(temp)
                 console.log(this.getMerchatData,'getMerchatData')
              }
              this.loading = false;
            } else {
              this.isLoading = false;
              Toast("暂无数据更多")
            }
            // this.DataList = response.data.body
            // console.log(this.DataList)
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });

      },
			//删除收藏的商品
			deleteFavourite(FavouriteId) {
				this.axios({
					url: this.url + '/api/Product/RemoveFavourite',
					method: 'post',
					data: {
						FavouriteId: FavouriteId
					},
					headers: {
						'Authorization': 'BasicAuth ' + localStorage.lut
					}

				}).then((res) => {
					if(!!res) {
						if(res.data.Code == 200) {
							//移除删除的商品
							this.productlist = this.productlist.filter(p => p.FavouriteId != FavouriteId);
							Toast(res.data.Data);
						} else {
							Toast(res.data.Data);
						}
					}
				})
			},
		},

		mounted: function() {
			this.$nextTick(function() {
				this.getFavouriteInfo();
      this.getMerchat()
			})
		}
	}
</script>

<style scoped>
  .merchan_box{padding: .4rem;display: flex;font-size: 0.55rem}
  .merchan_box p{padding: .29rem;padding-left: .5rem}
  .merchan_box img{width:3rem;height: 3rem;border-radius: 50%;}
  .merchan_box_p{color: #999}
  .merchan_box_img{display: inline-block;width: 3rem;height:3rem;border: 1px solid #fff;background: #fff}
  .page-part .is-selected{color: #e50039 !important;border-bottom: 2px solid #e50039 !important;margin-bottom:0px !important;}
	.product_colle {
    font-size: 0.55rem;
		display: flex;
		align-items: center;
    margin-top: .5rem;
		padding: 0.4rem;
		background-color: #ffffff;
		border-bottom: 1px solid #eeeeee;
	}

	.product_colle .product-img {
		width: 3.5rem;
		height: 3.5rem;
		margin-right: 0.4rem;
	}

	.product_colle>div:last-child {
		position: relative;
		height: 3.5rem;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		align-content: space-between;
	}

	.product_colle>div:last-child>div {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.product_colle .product-name {
		font-size: 0.65rem;
		color: #000;
	}

	.product_colle .product-name p {
    padding: .2rem;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
    font-size: 0.55rem;
	}

	.product_colle .product-delete {
		width: 0.8rem;
		height: 0.8rem;
		background-size: 100% 100%;
		background-image: url("../../assets/images/myInfo/delete.png");
	}
  .product-score {;
    text-align: center;
    background: #fbb546;
    color: #fff;
    padding: .2rem;
    font-size: 0.55rem;
    border-radius: .2rem;
  }
	.product_colle .product-price .go-buy {
		border-radius: 0.2rem;
		padding: 0.2rem 0.8rem;
		color: #B4282D;
		border: 0.1rem solid #B4282D;
	}
</style>

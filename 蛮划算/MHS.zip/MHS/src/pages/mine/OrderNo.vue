<template>
	<div class="container">
		<Mheader>
			<div slot="title">确认订单</div>
		</Mheader>

		<div class="help-box" id="checkbox">
			<div class="help-block">
				<div class="flex-between title" @click="toggleLook(0)">
					<span>积分支付</span>
					<img class="arrow" :class="{rotate:cont0}" src="../../assets/images/arrow1.png" />
				</div>
				<transition name="slide-fade">
					<div v-show="cont0" class="cont">
						<!--<mt-radio-->
						<!--v-model="value1"-->
						<!--align="right"-->
						<!--:options="options1">-->
						<!--</mt-radio>-->
						<group>
							<radio :options="radio001" v-model="valueMoye" @on-change="change"></radio>
						</group>
					</div>
				</transition>
			</div>
			<div class="help-block">
				<div class="flex-between title" @click="toggleLook(3)">
					<span>现金支付</span>
					<img class="arrow" :class="{rotate:cont1}" src="../../assets/images/arrow1.png" />
				</div>
				<transition name="slide-fade">
					<div v-show="cont1" class="cont">
						<!--<mt-radio-->
						<!--v-model="value2"-->
						<!--align="right"-->
						<!--:options="options2">-->
						<!--</mt-radio>-->
						<group>
							<radio :options="radio02" v-model="valueMoye" @on-change="change"></radio>
						</group>
					</div>
				</transition>
			</div>

		</div>

		<div>

		</div>

		<div class="btn" @click="saveInfo">提交</div>
	</div>
</template>

<script>
	import Mheader from '../../components/Mheader'
	import { Toast } from 'mint-ui'
	import { Group, Radio } from 'vux'
	const options = ['China', 'Japan']
	export default {
		components: {
			Mheader,
			Radio,
			Group
		},
		data() {
			return {
				valueMoye: 2,
				OrderNo: 2,
				weixinId: {},
				radio001: [{
					icon: 'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=142719395,615698616&fm=27&gp=0.jpg',
					key: 1,
					value: '通用积分'
				}, {
					icon: 'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=29529422,1968876201&fm=27&gp=0.jpg',
					key: 4,
					value: '专用积分'
				}],
				radio02: [{
						icon: 'https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=2881502819,1702418975&fm=58&bpow=400&bpoh=400',
						key: 3,
						value: '支付宝'
					}, {
						icon: 'https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=2136740882,3271518133&fm=58&bpow=630&bpoh=630',
						key: 2,
						value: '微信'
					},
					{
						icon: 'https://ss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=2027953294,1144892857&fm=58&bpow=1108&bpoh=707',
						key: 5,
						value: '快钱'
					},
				],
				cont0: true,
				cont1: true,
				value1: '',
				value2: '',
				options1: [{
						label: '专用积分',
						value: '1'
					},
					{
						label: '通用积分',
						value: '2'
					},
				],
				options2: [{
						label: '支付宝支付',
						value: '1'
					},
					{
						label: '微信支付',
						value: '2'
					},
					{
						label: '快钱支付',
						value: '3'
					},
				]

			}
		},
		methods: {
			//获取用户信息
			toggleLook(e) {
				switch(e) {
					case 0:
						this.cont0 = !this.cont0
						break;
					case 3:
						this.cont1 = !this.cont1
						break;
					default:
						this.cont1 = !this.cont1
				}
			},
			change(value, label) {
				this.OrderNo = value
				console.log(this.OrderNo, 'this.OrderNo')
			},
			//保存信息
			saveInfo() {
				console.log(this.OrderNo, 'saveInfo')
				let data = {
					'body': {
						payType: this.OrderNo,
						userId: localStorage.uid,
						dealType: '1',
						orderNo: JSON.parse(sessionStorage.orderNo)
					},
					'global': this.global
				}
				this.axios.post(this.apiJSON.Goods_bsOrderPay, JSON.stringify(data), {
					headers: {
						'content-Type': 'text/mhs-',
						'auth': localStorage.auth
					}
				}).then((response) => {
					if(response.data.code == '000000') {
						this.weixinId = response.data.body.signData
						console.log(response.data.body.signData)
						this.onBridgeReady()

					} else {
						Toast(response.data.message)
					}

				}).catch((error) => {

				});
			},

			onBridgeReady: function() {
				WeixinJSBridge.invoke(
					'getBrandWCPayRequest', {
						"appId": this.weixinId.appid, //公众号名称，由商户传入
						"timeStamp": JSON.stringify(this.weixinId.timestamp), //时间戳，自1970年以来的秒数
						"nonceStr": this.weixinId.noncestr, //随机串
						"package": this.weixinId.package,
						"signType": 'MD5', //微信签名方式：
						"paySign": this.weixinId.sign //微信签名
					},
					function(res) {
						console.log(res)
						if(res.err_msg === 'get_brand_wcpay_request:ok') {
							Toast('微信支付成功')
							// this.$router.push('/MineOrder')
						} else if(res.err_msg === 'get_brand_wcpay_request:cancel') {
							Toast('用户取消支付')
							// window.location.href = 'gift_failview.do?out_trade_no=' + this.orderId
						} else if(res.err_msg === 'get_brand_wcpay_request:fail') {
							// Toast('网络异常，请重试')
						}
					}
				)
			}
		},
		callpay: function() {
			alert(3333333)
			if(typeof WeixinJSBridge === 'undefined') {
				if(document.addEventListener) {
					document.addEventListener('WeixinJSBridgeReady', this.onBridgeReady(), false)
				} else if(document.attachEvent) {
					document.attachEvent('WeixinJSBridgeReady', this.onBridgeReady())
					document.attachEvent('onWeixinJSBridgeReady', this.onBridgeReady())
				}
			} else {
				this.onBridgeReady()
			}
		}
	}
</script>

<style>
	#checkbox .weui-cell__ft {
		width: 28px !important;
		height: 28px !important;
		border: 1px solid #ccc;
		border-radius: 50%
	}
	
	.weui-cells_radio .weui-check:checked+.weui-icon-checked:before {
		color: red !important;
	}
	
	.rotate {
		transform: rotate(0) !important;
	}
	
	.help-box {
		padding: 0.5rem 0;
	}
	
	.help-box .help-block+.help-block {
		border-top: 1px solid #eee;
	}
	
	.help-block .title,
	.service {
		background-color: #fff;
		padding: 1.2rem;
	}
	
	.help-block .title .arrow {
		width: 0.9rem;
		height: 0.8rem;
		transition: all .3s;
		transform: rotate(-90deg);
	}
	
	.help-block .cont {
		line-height: 1.1rem;
		padding: 0.4rem;
	}
	
	.service .tel-img {
		margin-right: 0.5rem;
		border-radius: 50%;
		width: 1.8rem;
		height: 1.8rem;
		background-position: center center;
		background-repeat: no-repeat;
		background-size: 1.4rem 1.4rem;
		background-color: #1DCB98;
		background-image: url("../../assets/images/tel.png");
	}
	
	.service .contact {
		padding: 0.1rem 0.2rem;
		border-radius: 3px;
		color: #b4282d;
		border: 1px solid #b4282d;
	}
	
	.slide-fade-enter-active {
		transition: all .3s ease;
	}
	
	.slide-fade-leave-active {
		transition: all .3s cubic-bezier(1.0, 0.5, 0.8, 1.0);
	}
	
	.slide-fade-enter,
	.slide-fade-leave-to
	/* .slide-fade-leave-active for below version 2.1.8 */
	
	{
		transform: translateX(10px);
		opacity: 0;
	}
	
	.btn {
		width: 100%;
		position: fixed;
		bottom: 0;
		display: flex;
		align-items: center;
		justify-content: center;
		height: 1.8rem;
		color: #fff;
		background-color: #B4282D;
	}
</style>
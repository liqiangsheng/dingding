<template>
	<div class="container address">
		<Mheader>
			<div slot="title">{{title}}</div>
		</Mheader>
		<div id="address">
			<ul>
				<!--<router-link :to="{path:'/AddressCity/'}">-->
				<li v-for="(item,index) in addressData" @click="addressBOx(item)">
					<mt-cell style="background-size: 100% 0px">
						{{item.provinceName}}
					</mt-cell>
				</li>
				<!--</router-link>-->
			</ul>

		</div>
		<Mfooter :myCenterCurrent='true'></Mfooter>
	</div>
</template>

<script>
	import Mheader from '../../components/Mheader'
	import Mfooter from '../../components/Mfooter'
	import { CellSwipe } from 'mint-ui'
	import { address, slots } from '../../components/linkage/address'

	export default {
		components: {
			Mheader,
			Mfooter,
			// Datajson
		},
		data() {
			return {
				title: '省选择',
				btnName: '修改',
				addressData: [],
				address: '',
				dataObj: '',
			}
		},
		methods: {
			addressBOx(item) {
				this.dataObj = item
				sessionStorage.setItem("dataObj", JSON.stringify(this.dataObj));
				this.$router.push({
					name: 'AddressCity',
					params: {
						dataObj: this.dataObj
					}

				})
				console.log(item, '09item')
			},
			// //
			// datatiyi(){
			//   let data = {
			//     'body': {
			//       userId: localStorage.uid,
			//       typeId: 1,
			//     },
			//     'global': this.global
			//   }
			//   this.axios.get('/static/js/Data.json', JSON.stringify(data)).then((response) => {
			//     this.data=response.data
			//     this.data.forEach(item=>{
			//       this.cityList1=item
			//
			//     })
			//     if (response.data.code == '000000') {
			//     } else {
			//       Toast(response.data.message)
			//     }
			//
			//   }).catch((error) => {
			//
			//   });
			// },
			fillAddress() {
				// 填入省市区
				this.address = this.temp_addr;
				this.address_flag = false;
				this.$emit('getAddress', this.address);
			},
			initAddress() {
				this.addressData = [],
					address.forEach(item => {
						this.addressData.push(item)
					})
				// console.log(this.addressData,'000')

				// this.slots[0].values = address.filter((item, index) => {
				//   if (item.provinceId.length ==3) {
				//      return item;
				//   }
				// });
			},
			onValuesChange(picker, values) {
				// // 防止没有省份时报错
				// if (values[0]) {
				//   this.slots[1].values = address.filter((item, index) => {
				//     if (item.apid == values[0].aid) {
				//       return item;
				//     }
				//   });
				// }
				// 防止没有市时报错
				if(values[1]) {
					// this.slots[2].values = address.filter((item, index) => {
					//   if (item.apid ==values[1].aid) {
					//     return item;
					//   }
					// });
				}
				// 防止没有区时报错
				if(values[2]) {
					// 这里可以指定地址符，此处以空格进行连接
					// this.temp_addr = values[0].aname + ' ' + values[1].aname + ' ' + values[2].aname;
				}
			},

		},
		mounted() {
			this.initAddress();
			console.log(this.addressData,'addressData')
		}
	}
</script>

<style lang="scss">
	#address .mint-cell-title {
		flex: 0 !important;
	}

	.save {
		margin: 1.5rem auto;
		padding: 0.3rem 0;
		border-radius: 0.2rem;
		text-align: center;
		width: 50%;
		color: #ffffff;
		background-color: #B4282D;
	}

	.linkage-wrap {
		left: 4rem;
		width: 11rem;
		z-index: 999;
		top: 31%;
		position: absolute;
		.address-wrap {
			display: flex;
			justify-content: space-between;
			align-items: center;
			height: 30px;
			font-size: 14px;
			color: #333;
			.input {
				display: flex;
				align-items: center;
				flex: 1;
				height: 100%;
				padding: 0;
				box-sizing: border-box;
			}
			.btn {
				flex: 0 0 80px;
				width: 100%;
				height: 1.2rem;
				line-height: 30px;
				text-align: center;
				border: 1px solid #ccc;
				border-left: 0 none;
				box-sizing: border-box;
				position: absolute;
				opacity: 0;
			}
		}
		.pick-mark {
			position: fixed;
			left: 0;
			top: 0;
			bottom: 0;
			right: 0;
			z-index: 999;
			.btn-wrap {
				position: absolute;
				left: 0;
				right: 0;
				bottom: 180px;
				display: flex;
				justify-content: space-between;
				align-items: center;
				height: 40px;
				padding: 0 20px;
				font-size: 14px;
				background: #fff;
				.btn-cancel {
					color: #999;
				}
				.btn-sure {
					color: #B4282D;
				}
			}
			.select {
				position: absolute;
				left: 0;
				bottom: 0;
				width: 100%;
				background-color: #eeeeee;
			}
			.picker-items {
				font-size: 14px;
				background: #eee;
				.picker-slot {
					font-size: 14px;
				}
				.picker-item {
					&.picker-selected {
						color: #535353;
					}
				}
				.picker-center-highlight {
					&:after,
					&:before {
						background: #fff;
					}
				}
			}
		}
	}
</style>

<template>
	<div class="container">
		<Mheader>
			<div slot="title">我的订单</div>
		</Mheader>
		<div class="tabs">
			<div class="tab" v-for="(item,index) in tabList" :class="{active:activeIdx == index}" :key='index' @click="tabActive(index)">{{ item.tabName }}
			</div>
		</div>

		<div class="order-box" v-infinite-scroll="loadMore" infinite-scroll-disabled="loading" infinite-scroll-distance="10">

			<MorderBox v-for="(item,index) in orderList" :orderProductList="item" :key="item.orderNo" :path="item.orderNo">

				<span slot="number">{{ item.appPrice }}</span>
				<span slot="state">{{ item.OrderStateStr }}</span>

				<!--<span slot="img"><img :src="item.HeadImg" alt=""></span>-->
				<!--<span class="product-name" slot="name">{{ item.ProductName }}</span>-->
				<!--<span class="lm-text-grey lm-margin-t-sm" slot="count">数量：{{ item.ProductCount}}</span>-->

				<span class="lm-text-red" slot="price">{{ item.TotalPrice }}</span>
				<span slot="cancel" v-show="item.OrderState==0 && item.PayState!=1" @click="cancelOrder(item.ProductOrderId)">取消订单</span>
				<span slot="btn" v-if="item.orderStatus==20" @click="goToPay(item,index)" class="btn_zf">立即支付</span>
				<span slot="btn" v-if="item.orderStatus==3||item.orderStatus==4" @click="DeleteOrder(item,index)">删除订单</span>
        <span slot="btn" v-if="item.orderStatus==18" >已完成</span>


				<span slot="btn" v-else-if="(item.PayType==0&&(item.OrderState==0||item.OrderState==6))||(item.PayType!=0 && item.PayState==1)" @click="addOrderUrged(item.ProductOrderId)">催单</span>
				<span slot="btn" v-else-if="item.OrderState==2" @click="logistics(item.LogisticsNo)">查看物流</span>
				<span slot="btn" v-else-if="item.OrderState==3" @click="goToEvaluate(item.ProductOrderId)" :class="{already:item.OrderState==3}"><span v-if="item.OrderState==3" >已评价</span><span v-else>去评价</span></span>
				<span slot="time">{{ item.CreateTime | format }}</span>
			</MorderBox>
		</div>

		<div class="noorder-box" v-show="orderList.length == 0">
			<div class="noorder">
				<img src="../../assets/images/myInfo/order_03.png" />
				<p>没有相关的订单</p>
			</div>
		</div>

		<Mfooter :myCenterCurrent='true'></Mfooter>
	</div>
</template>

<script>
	import Mheader from '../../components/Mheader'
	import Mfooter from '../../components/Mfooter'
	import MorderBox from '../../components/MorderBox'
	import { Toast } from 'mint-ui'
	import { MessageBox } from 'mint-ui'
	export default {
		components: {
			Mheader,
			Mfooter,
			MorderBox
		},
		data() {
			return {
        isactive:'',
				tabNum: this.$route.params.tabNum,
				typeId: 0, //选择的订单类型
				pageIndex: 0,
				pageSize: 10,
				loading: false,
				activeIdx: this.$route.params.tabNum,
				goodsList: [],
				tabList: [{
						tabName: '全部'
					},
					{
						tabName: '待付款'
					},
					{
						tabName: '待收货'
					},
					{
						tabName: '已收货'
					},
					{
						tabName: '已完成'
					}
				],
				orderList: [] //订单集合
			}
		},
		filters: {
			format(val) {
				let date = new Date(val);
				let y = date.getFullYear();
				let m = date.getMonth() + 1;
				m = m < 10 ? ('0' + m) : m;
				let d = date.getDate();
				d = d < 10 ? ('0' + d) : d;
				let h = date.getHours();
				let minute = date.getMinutes();
				minute = minute < 10 ? ('0' + minute) : minute;
				return y + '-' + m + '-' + d + ' ' + h + ':' + minute;
			}
		},
    mounted(){
    },
		methods: {
		  //删除订单
      DeleteOrder(item,index){
        console.log(item,'999',index,'000')
        MessageBox.confirm('是否要删除订单?').then(action => {
          let data = {
            'body': {
              dealType:'2',
              index:'2',
              orderNo:item.orderNo,
            },
            'global': this.global
          }
          this.axios.post(this.apiJSON.order_bsOrderCancel, JSON.stringify(data), {
            headers: {'content-Type': 'text/mhs-','auth': localStorage.auth}
          }).then((response) => {
            if(response.data.code == '000000') {
              Toast('删除订单成功')
              this.orderList.splice(index, 1);
              // this.orderList = this.orderList.filter(item => item.orderNo != item.orderNo);
              this.getOrderByType()

            } else {
              Toast(response.data.message)
            }

          }).catch((error) => {

          });
        });
      },
			//加载更多
			loadMore() {
				this.loading = true;
				this.pageIndex++;
				this.getOrderByType();
			},
			tabActive(i) {
				console.log(i, 'ss')
				this.activeIdx = i;
				this.tabList.forEach(function(value, index, array) {
					array[index].isactive = false;
				});
				this.tabList[i].isactive = true;
				console.log(i, 'i')
				this.tabNum = i;
				console.log(this.tabNum, 'this.tabNum')
				this.typeId = i;
				this.pageIndex = 1;
				this.orderList = [];
				this.getOrderByType();
			},
			//获取订单信息
			// Goods_orderSearch
			getOrderByType() {
				let data = {
					'body': {
						orderType: '2',
						pageNum: this.pageIndex,
						queryCondition: JSON.stringify(this.typeId),
						pageSize: '20',
					},
					'global': this.global
				}
				this.axios.post(this.apiJSON.Goods_orderSearch, JSON.stringify(data), {
					headers: {
						'content-Type': 'text/mhs-',
						'auth': localStorage.auth
					}
				}).then((response) => {
					if(response.data.code == '000000') {
						if(this.pageIndex == 1) {
							// console.log(1)
							this.orderList = response.data.body.orders;
							// console.log(this.orderList, 'this')
							this.orderList.forEach(item => {
								this.goodsList.push(item.shopInfoList)

							})
							// console.log(this.goodsList, 'goodsList')
							this.loading = false;
						} else {
							// console.log(2)
							if(response.data.body.orders.length > 0) {
								// console.log(3)
								for(let i = 0; i < response.data.body.orders.length; i++) {
									this.orderList.push(response.data.body.orders[i])
									// console.log(this.orderList, 'this.orderList')
								}
								this.loading = false;
							} else {
								// console.log(4)
								this.loading = true;
							}
						}
					} else {
						Toast(response.data.message)
					}
				}).catch((error) => {
					// Toast(error.data.message)
				});
			},
			//取消订单
			cancelOrder(oId) {
				MessageBox.confirm('确认取消订单么?').then(action => {
					this.axios({
						url: this.url + '/api/Order/CancelOrder',
						method: 'post',
						data: {
							orderId: oId
						},
						headers: {
							'Authorization': 'BasicAuth ' + localStorage.lut
						}
					}).then((res) => {
						if(!!res) {
							if(res.data.Code == 200) {
								//移除删除的订单
								this.orderList = this.orderList.filter(o => o.ProductOrderId != oId);
								Toast(res.data.Data);
							} else {
								Toast(res.data.Data);
							}
						}
					})
				});
			},
			//去下单
			goToPay(item,index) {
        console.log(item,'item')
        let data = {
          'body': {
            orderNos: [item.orderNo]

          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.order_toPay, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-',
            'auth': localStorage.auth
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            Toast('下单成功')
            console.log(response.data.body,'response.data.body')
            this.orderNoorderNo = response.data.body.orderNo
            sessionStorage.setItem("orderNo", JSON.stringify(this.orderNoorderNo));
            this.$router.push({
              path: '/OrderNo'
            })

          } else {
            Toast(response.data.message)
          }
        }).catch((error) => {
          Toast(response.data.message)
        });

			},
			//去评价
			goToEvaluate(val) {
				this.$router.push({
					path: '/evaluate/' + val
				})
			},
			// 查看物流
			logistics(info) {
				this.$router.push({
					path: '/Logistics',
					query: {
						express: info
					}
				})
			},
			//催单
			addOrderUrged(oId) {
				this.axios({
					url: this.url + '/api/OrderUrged/AddOrderUrged',
					method: 'post',
					data: {
						OrderId: oId
					},
					headers: {
						'Authorization': 'BasicAuth ' + localStorage.lut
					}
				}).then((res) => {
					if(!!res) {
						if(res.data.Code == 200) {
							Toast(res.data.Data);
						} else {
							Toast(res.data.Data);
						}
					}
				})
			}
		},
		created() {
			let index = this.$route.params.tabNum
			this.tabList[index].isactive = true
			this.typeId = parseInt(index);
			console.log(this.tabList[index].isactive, 'this.tabList[index].isactive')
			// this.tabActive()
			// this.getOrderByType();
		}
	}
</script>

<style scoped>
  .top{font-size: 0.55rem}
	.tabs {
		width: 100%;
		position: fixed !important;
    font-size: 0.55rem;
	}
.btn_zf{background: #e50039;color: #fff !important;border: none !important;}
	.tabs {
		top: 1.8rem;
		display: flex;
		align-items: center;
		height: 1.6rem;
		margin-bottom: 0.5rem;
		line-height: 1.6rem;
		background-color: #ffffff;
		border-bottom: 1px solid #eeeeee;
	}

	.order-box {
		margin-top: 4rem;
	}

	.tabs .tab {
		text-align: center;
		width: 20%;
		height: 100%;
		border-bottom: 3px solid #fff;
	}

	.tabs .active {
		color: #e50039;
		border-bottom: 2px solid #e50039;
	}

	.noorder-box {
		width: 100%;
		height: 80vh;
		position: relative;
	}

	.noorder {
		position: absolute;
		text-align: center;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		color: #C8C8C8;
	}

	.noorder>img {
		width: 4rem;
		height: 4.5rem;
	}
	/*按钮操作后*/

	.already {
		pointer-events: none;
		color: #9d9d9d!important;
		border-color: #9d9d9d!important;
	}
</style>

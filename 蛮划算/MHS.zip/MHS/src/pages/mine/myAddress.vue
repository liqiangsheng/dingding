<template>
	<div class="container">
		<Mheader>
			<div slot="title" class="title_box">
        <div  class="title_left">
          地址管理
        </div>
        <div class="title_right">
          <router-link :to="{path:'/EditAddress/0'}" replace>
            <div>
              添加
            </div>
          </router-link>
        </div>
      </div>
		</Mheader>

    <div class="address_top" v-for="(item,index) in userAllAddress" :key='index'>
      <div class="address" :class="{checked:item.IsDefault==0}" @click="checkAddress(index)">
        <div>
          <div class="name">{{item.acceptName}}</div>
          <div class="name address1">{{item.address}}</div>
          <!--<div class="mr">{{item.isDefault ==true ? '默认' : ''}}</div>-->
        </div>
        <!--<div >-->
        <!--<div class="tel">{{item.mobile}}</div>-->
        <!--<div class="add">{{item.address}}</div>-->
        <!--<div class="add">{{item.address + item.City + item.Area + item.Detail}}</div>-->
        <!--</div>-->
        <div>
          <div class="tel">{{item.mobile}}</div>


        </div>
      </div>
      <div class="address_botton">
        <div class="address_botton_first" @click="checkisDefault(item)">
        <p>
          <b class="address_p_bg":class="timeBarType(item.isDefault)"></b>
          <span>默认地址</span>
        </p>

        </div>
        <div class="address_botton_str">
          <div @click="checkisedit(item)">
            <router-link :to="{path:'/EditAddress/1'}" replace>
              <img src="../../assets/images/myAddress/write@2x.png" />
            编辑
            </router-link >
          </div>
          <div @click="checkisDel(item)">
              <img src="../../assets/images/myAddress/delete@2x.png" />
            删除
          </div>
        </div>

      </div>
    </div>




		<Mfooter :myCenterCurrent='true'></Mfooter>
	</div>
</template>

<script>
	import Mheader from '../../components/Mheader'
	import Mfooter from '../../components/Mfooter'
	import { Toast } from 'mint-ui'

	export default {
		components: {
			Mheader,
			Mfooter
		},
		data() {
			return {
        value:'',
        type:1,
				userAllAddress: [],
        options : [{
          label: '选项A',
          value: 'A'
        },]


      }
		},
		methods: {
      checkisedit(item){
        sessionStorage.setItem("AddressEidt", JSON.stringify(item));
      },
      checkisDel(item){
        console.log(item,'checkisDel')
        if(item.isDefault==true){
          Toast('不能删除默认地址')
          return
        }
        let data = {
          'body': {
            type: '3',
            isDel:true,
            adressId: item.adressId,
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.usGetAddDeleteModifyAdress, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-',
            'auth': localStorage.auth
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            this.getUserAddress()
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },
		  //默认图标
      timeBarType(type) {
        if(type == true) return 'gray-bg';
        if(type == false) return 'blue-bg';
      },
      check: function(){
        console.log(this.value)
      },
      //设置默认
      checkisDefault(item){
        console.log(item,'checkisDefault')
        let data = {
          'body': {
            type: '3',
            userId: localStorage.uid,
            adressId: item.adressId,
            isDefault: '1',
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.usGetAddDeleteModifyAdress, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-',
            'auth': localStorage.auth
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            this.getUserAddress()
          } else {
            Toast(response.data.message)
          }

        }).catch((error) => {

        });
      },
      //获取用户地址列表
			getUserAddress() {
				let data = {
					'body': {
						type: '1',
						userId: localStorage.uid,
						pageNum: 1,
						pageSize: 20,
					},
					'global': this.global
				}
				this.axios.post(this.apiJSON.usGetAddDeleteModifyAdress, JSON.stringify(data), {
					headers: {
						'content-Type': 'text/mhs-',
						'auth': localStorage.auth
					}
				}).then((response) => {
					if(response.data.code == '000000') {
						this.userAllAddress = response.data.body
						console.log(response.data.body, '9')
					} else {
						Toast(response.data.message)
					}

				}).catch((error) => {

				});
			},
			//选中收货地址
			checkAddress(index) {
				console.log(index, '0')
				if(!!this.$route.query.isban) {
					return false;
				} else {
					this.$store.state.receiveAddress = this.userAllAddress[index];
					console.log(this.$store.state.receiveAddress, 'this.$store.state.receiveAddress')
					this.$router.go(-1);
				}
			}
		},
		mounted: function() {
			this.getUserAddress();
		}

	}
</script>

<style>

  html{background: #f4f4f4}
  .address_top{
    margin-bottom: .4rem;

  }
  .title_box{display: flex;}
  .title_left{flex: 2}
  .title_right{padding-right: .4rem;font-size: 0.55rem;color: #e50039}
  .address_top .address {
		display: flex;
		align-items: center;
		padding: 0.5rem 0;
		border-left: 4px solid #fff;
		background-color: #ffffff;
    border-bottom: 1px solid #eaeaea;
	}

	.address.checked {
		border-left: 4px solid #B4282D;
	}

	.address+.address {
		border-top: 1px solid #eeeeee;
	}

	.address>div:first-child {
		padding-left: 0.5rem;
		width: 10rem;
	}
  .address_p_bg{display:inline-block;width: 18px;margin-bottom: -0.1rem;height:18px;background: url("../../assets/images/myAddress/icon@2x.png") no-repeat;background-size: 100% 100%}
  .gray-bg{display:inline-block;width: 18px;margin-bottom: -0.1rem;height:18px;background: url("../../assets/images/myAddress/icon_@2x.png") no-repeat;background-size: 100% 100%}


  .address>div:first-child .name {
		font-size: 0.65rem;
    padding: .3rem;
	}
  .address>div:first-child .address1 {
    font-size: 0.65rem;
    color: #999;
  }
  .address_botton{display: flex;font-size: 0.55rem}
  .address_botton img{width: 0.7rem}
  .address_botton_str  {
    display: flex;
    padding: 0.5rem 0;
    padding-left: 1rem;
  }

  .address_botton_str div{flex: 1}
.address_botton div{
  flex: 1;
  /*text-align: center;*/
  background: #fff;

}
.address_botton_first{
  width: 7rem;
  padding:0.5rem 0;
  text-align: left;
  padding-left: .6rem;
}
	.address>div:first-child .mr {
		margin-top: 0.3rem;
		width: 1.5rem;
		text-align: center;
		border-radius: 0.1rem;
		font-size: 0.5rem;
		color: #B4282D;
		border: 1px solid #B4282D;
	}

	.address>div:nth-child(2) {
		margin-left: 0.8rem;
		/*width: 9rem;*/
	}

	.address>div:nth-child(2) .add {
		margin-top: 0.2rem;
		font-size: 0.6rem;
		color: #999;
	}

	.address>div:last-child {
		width: 0.8rem;
		height: 0.8rem;
		margin-left: 0.7rem;
	}

	.new-address {
		margin: 1.2rem auto;
		width: 90%;
		padding: 0.4rem 0;
		text-align: center;
		border-radius: 0.2rem;
		border: 2px solid #B4282D;
		color: #B4282D;
		background-color: #ffffff;
	}
</style>

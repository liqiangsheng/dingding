<template>
  <div class="container">
    <Mheader>
      <div slot="title">我的订单</div>
    </Mheader>
    <div class="myWallettabs">
      <div class="tab_box" v-for="(item,index) in tabList" :class="{active:activeIdx == index}" :key='index' @click="tabActive(index)">{{ item.tabName }}
      </div>
    </div>

    <div class="order-box" v-infinite-scroll="loadMore" infinite-scroll-disabled="loading" infinite-scroll-distance="10">
      <div v-for="(item,index) in orderList" class="MyWalletDetails_box">
        <span class="MyWalletDetails_box_span1">
          <p>{{item.reason}}</p>
          <p class="MyWalletDetails_box_p">{{item.createTime}}</p>
        </span>
        <span class="MyWalletDetails_box_span">{{item.transAmount}}</span>
      </div>
    </div>


    <Mfooter :myCenterCurrent='true'></Mfooter>
  </div>
</template>

<script>
  import Mheader from '../../components/Mheader'
  import Mfooter from '../../components/Mfooter'
  import MorderBox from '../../components/MorderBox'
  import { Toast } from 'mint-ui'
  import { MessageBox } from 'mint-ui'
  export default {
    components: {
      Mheader,
      Mfooter,
      MorderBox
    },
    data() {
      return {
        isactive:true,
        tabNum:0,
        typeId: 1, //选择的订单类型
        pageIndex: 0,
        pageSize: 10,
        loading: false,
        activeIdx: 0,
        goodsList: [],
        tabList: [{
          tabName: '进账'
        },
          {
            tabName: '支出'
          },

        ],
        orderList: [] //订单集合
      }
    },
    filters: {
      format(val) {
        let date = new Date(val);
        let y = date.getFullYear();
        let m = date.getMonth() + 1;
        m = m < 10 ? ('0' + m) : m;
        let d = date.getDate();
        d = d < 10 ? ('0' + d) : d;
        let h = date.getHours();
        let minute = date.getMinutes();
        minute = minute < 10 ? ('0' + minute) : minute;
        return y + '-' + m + '-' + d + ' ' + h + ':' + minute;
      }
    },
    mounted(){
    },
    methods: {
      //加载更多
      loadMore() {
        this.loading = true;
        this.pageIndex++;
        this.getOrderByType();
      },
      tabActive(i) {
        this.activeIdx = i;
        this.tabList.forEach(function(value, index, array) {
          array[index].isactive = false;
        });
        this.tabList[i].isactive = true;
        this.tabNum = i;
        this.typeId = i+1;
        this.pageIndex = 1;
        this.orderList = [];
        this.getOrderByType();
      },
      //获取订单信息
      // Goods_orderSearch
      getOrderByType() {
        let data = {
          'body': {
            type: this.$route.params.WalleID,
            pageNum: 1,
            pageSize:20,
            pageNum: this.pageIndex,
            chargeStatus: JSON.stringify(this.typeId),
          },
          'global': this.global
        }
        this.axios.post(this.apiJSON.my_accountScoreDetail, JSON.stringify(data), {
          headers: {
            'content-Type': 'text/mhs-',
            'auth': localStorage.auth
          }
        }).then((response) => {
          if(response.data.code == '000000') {
            if(this.pageIndex == 1) {
              // console.log(1)
              this.orderList = response.data.body.result;
              // console.log(this.orderList, 'this')
              this.orderList.forEach(item => {
                this.goodsList.push(item.shopInfoList)

              })
              // console.log(this.goodsList, 'goodsList')
              this.loading = false;
            } else {
              // console.log(2)
              if(response.data.body.result.length > 0) {
                // console.log(3)
                for(let i = 0; i < response.data.body.result.length; i++) {
                  this.orderList.push(response.data.body.result[i])
                  console.log(this.orderList, 'this.orderList')
                }
                this.loading = false;
              } else {
                // console.log(4)
                this.loading = true;
              }
            }
          } else {
            Toast(response.data.message)
          }
        }).catch((error) => {
          // Toast(error.data.message)
        });
      },

    },
    created() {
      let index =1
      this.tabList[index].isactive = true
      this.typeId = parseInt(index);
      // console.log(this.tabList[index].isactive, 'this.tabList[index].isactive')

    }
  }
</script>

<style scoped>
  .top{font-size: 0.55rem}
  .myWallettabs {
    width: 100%;
    position: fixed !important;
    font-size: 0.55rem;
  }
  .btn_zf{background: #e50039;color: #fff !important;border: none !important;}
  .myWallettabs {
    top: 1.8rem;
    display: flex;
    align-items: center;
    height: 1.6rem;
    margin-bottom: 0.5rem;
    line-height: 1.6rem;
    background-color: #ffffff;
    border-bottom: 1px solid #eeeeee;
  }

  .order-box {
    margin-top: 4rem;
  }

  .myWallettabs .tab_box {
    text-align: center;
    width: 50%;
    height: 100%;
    border-bottom: 3px solid #fff;
  }

  .myWallettabs .active {
    color: #e50039;
    border-bottom: 2px solid #e50039;
  }
  .MyWalletDetails_box_p{font-size: 0.5rem;color: #999;padding: .1rem}
.MyWalletDetails_box{display: flex;font-size: 0.55rem;background: #fff}
  .MyWalletDetails_box_span1{flex: 1;border-bottom: 1px solid #eee;padding: .3rem}

.MyWalletDetails_box_span{width: 3rem;float: right;color: red;line-height: 2rem;padding-right: .5rem}
</style>

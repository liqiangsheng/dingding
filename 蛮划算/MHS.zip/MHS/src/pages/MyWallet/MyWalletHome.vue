<template>
  <div class="container">
    <Mheader>
      <div slot="title">我的钱包</div>
      <!--<div slot="info" @click='saveUserInfo'>保存</div>-->
    </Mheader>
      <div class="Walle_box">
        <p>平台积分</p>
        <ul>
          <router-link :to="{path:'/MyWalletDetails/'+AvailableData.type}">
          <li>
            <b class="Walle_box_img"><img src="../../assets/images/MyWallet/keyongjifen.png" alt=""></b>
            <span>{{AvailableData.title}}</span>
            <span class="Walle_box_span">{{AvailableData.value}}</span>
            <b class="Walle_box_img rightImg"><img src="../../assets/images/arrow.png" alt=""></b>
          </li>
          </router-link>
          <router-link :to="{path:'/MyWalletDetails/'+frozenAmountData.type}">

            <li>
              <b class="Walle_box_img"><img src="../../assets/images/MyWallet/dongjiejifen.png" alt=""></b>
              <span>{{frozenAmountData.title}}</span>
              <span class="Walle_box_span">{{frozenAmountData.value}}</span>
              <b class="Walle_box_img rightImg"><img src="../../assets/images/arrow.png" alt=""></b>
            </li>
          </router-link>
          <router-link :to="{path:'/MyWalletDetails/'+integralAmountData.type}">

          <li>
            <b class="Walle_box_img"><img src="../../assets/images/MyWallet/jifenedu.png" alt=""></b>
            <span>{{integralAmountData.title}}</span>
            <span class="Walle_box_span">{{integralAmountData.value}}</span>
            <b class="Walle_box_img rightImg"><img src="../../assets/images/arrow.png" alt=""></b>
          </li>
            </router-link>
          <router-link :to="{path:'/MyWalletDetails/'+barterVoucherData.type}">
            <li>
            <b class="Walle_box_img"><img src="../../assets/images/MyWallet/yiwuquan.png" alt=""></b>
            <span>{{barterVoucherData.title}}</span>
            <span class="Walle_box_span">{{barterVoucherData.value}}</span>
            <b class="Walle_box_img rightImg"><img src="../../assets/images/arrow.png" alt=""></b>
          </li>
            </router-link >

        </ul>
        <div class="Walle_box_bottom">渠道合作</div>
        <ul>
          <router-link :to="{path:'/MyWalletDetails/'+hongfaData.type}">

          <li>
            <b class="Walle_box_img"><img src="../../assets/images/MyWallet/hongfajifen.png" alt=""></b>
            <span>{{hongfaData.title}}</span>
            <span class="Walle_box_span">{{hongfaData.value}}</span>
            <b class="Walle_box_img rightImg"><img src="../../assets/images/arrow.png" alt=""></b>
          </li>
            </router-link>

        </ul>
      </div>
  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  import axios from 'axios';

  export default {
    components: {
      Mheader,
    },
    data() {
      return {
        WalletData:'',
        AvailableData:'',//可用积分
        frozenAmountData:'',  //冻结积分
        integralAmountData:'',//积分额度
        barterVoucherData:'',//易物券
        hongfaData:'',//宏法
      }
    },
    methods: {
        getWallet(){
          let data = {
            'global': this.global
          }
          axios.post(this.apiJSON.my_accountWalletDetail, JSON.stringify(data), {
            headers: {'content-Type': 'text/mhs-',auth: localStorage.auth }
          }).then((response) => {
            if(response.data.code == '000000') {
              // console.log(response.data.body,'response.data')
              this.WalletData=response.data.body
             this.WalletData.forEach(item=>{
               if(item.type =='availableAmount') {
                 this.AvailableData =item
               }
               if(item.type =='frozenAmount') {
                 this.frozenAmountData =item
               }
               if(item.type =='integralAmount') {
                 this.integralAmountData =item
               }
               if(item.type =='barterVoucher') {
                 this.barterVoucherData =item
               }
               if(item.type =='hongfa') {
                 this.hongfaData =item
               }

             })
              console.log(this.WalletData,'WalletData')
            } else {
              Toast(response.data.message)
              this.$router.push({
                path: '/login'
              })
            }

          }).catch((error) => {
          });
        }
    },
    mounted: function() {
      this.$nextTick(() => {
          this.getWallet()

      })
    }
  }
</script>

<style >
  html{background: #f4f4f4}
  .rightImg img{width: 0.7rem !important;margin-bottom: .4rem}
.Walle_box img{width:0.91rem;}
.Walle_box_img{width: 1.2rem}
.Walle_box_span{text-align: right;color: red;padding-right: .4rem}
.Walle_box p{height: 2rem;line-height: 2rem;background: #fff;margin-top: 2.2rem;padding-left: .6rem;}
.Walle_box ul li{display: flex;padding: .4rem;border-bottom: 1px solid #eee;color: #999;font-size: 0.58rem}
.Walle_box ul li span{flex: 1;}
  .Walle_box_bottom{height: 2rem;background: #fff;line-height: 2rem;padding-left: .6rem}
</style>

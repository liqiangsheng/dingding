<template>
	<div class="container">
		<Mheader>
			<div slot="title">活动</div>
			<div class="msg" slot="info">
			</div>
		</Mheader>

		<div>
			<img src="http://img.mhsapp.com/goods/hongfa_zhuanqu.png" alt="">
		</div>
		<Mfooter :worldCurrent='true'></Mfooter>
	</div>
</template>

<script>
	import Mheader from '../../components/Mheader'
	import Mfooter from '../../components/Mfooter'
	import { Toast } from 'mint-ui'
	import { formatDate } from '../../assets/js/Date.js' //时间显示格式转换js

	export default {
		components: {
			Mheader,
			Mfooter
		},
		data() {
			return {

			}
		},

		methods: {

		},
		mounted() {

		}
	}
</script>

<style scoped>

</style>
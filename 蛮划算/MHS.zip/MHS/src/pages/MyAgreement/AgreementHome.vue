<template>
  <div class="container">
    <Mheader style="border-bottom: 1px solid #eee">
      <div slot="title">协议与通知</div>
      <!--<div slot="info" @click='saveUserInfo'>保存</div>-->
    </Mheader>

      <div class="AgreementHome_box">
          <ul>
            <a :href="apiCentet+'/view/agreement/rule.html'">
              <li><span>商城章程</span><strong><img src="../../assets/images/myHome/jiantou@2x.png"/></strong></li>
            </a>
            <a :href="apiCentet+'/view/agreement/userAgreement0613.html'">
              <li><span>蛮划算用户注册协议</span><strong><img src="../../assets/images/myHome/jiantou@2x.png"/></strong></li>
            </a>
              <a :href="apiCentet+'/view/agreement/privacy.html'">
              <li><span>隐私政策</span><strong><img src="../../assets/images/myHome/jiantou@2x.png"/></strong></li>

            </a>
          </ul>
      </div>

    </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  export default {
    components: {
      Mheader,
    },
    data() {
      return {
        mhsData:"",
      }
    },
    methods: {


    },
    mounted: function() {
      this.$nextTick(() => {

      })
    }
  }
</script>

<style >

  .AgreementHome_box ul li{display: flex;padding: .5rem;border-bottom: 1px solid #eee;font-size: 0.6rem}
  .AgreementHome_box ul li span{flex:1;}
  .AgreementHome_box img{width:0.6rem}
</style>

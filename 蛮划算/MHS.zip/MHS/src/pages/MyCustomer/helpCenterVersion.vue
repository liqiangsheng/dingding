<template>
  <div class="container">
    <Mheader :show='true'>
      <div slot="title">客户中心</div>
      <div class="msg" slot="info">
      </div>
    </Mheader>

    <div class="help-box">
      <div class="help-block">
        <div class="flex-between title" @click="toggleLook(0)">
          <span>1、怎么查看蛮划算用户版APP的版本？</span>
          <img class="arrow" :class="{rotate:cont0}" src="../../assets/images/arrow1.png" />
        </div>
        <transition name="slide-fade">
          <div v-show="cont0" class="cont">
            <div class="font600"></div>
            <div class="lm-font-sm lm-margin-t-xs">
              <p class="text-indent">
                打开蛮划算用户版APP后点击右下方‘我的’——点击右上角‘设置’——点击‘关于我们’，即可看到您目前使用的版本信息。
              </p>


            </div>
          </div>
        </transition>
      </div>


    </div>

    <Mfooter :myCenterCurrent='true'></Mfooter>
  </div>
</template>

<script>
  import Mheader from '../../components/Mheader'
  import Mfooter from '../../components/Mfooter'

  export default {
    components: {
      Mheader,
      Mfooter
    },
    data() {
      return {
        cont0: true,
        cont1: false,
        cont2: false,
        cont3: false,
        cont4: false,
        cont5: false,
        cont6: false,
      }
    },
    methods: {
      toggleLook(e) {
        switch(e) {
          case 0:
            this.cont0 = !this.cont0
            break;
          case 1:
            this.cont1 = !this.cont1
            break;
          case 2:
            this.cont2 = !this.cont2
            break;
          case 3:
            this.cont3 = !this.cont3
            break;
          case 4:
            this.cont4 = !this.cont4
            break;
          case 5:
            this.cont5 = !this.cont5
            break;
          default:
            this.cont6 = !this.cont6
        }
      }
    }
  }
</script>

<style scoped>
  .rotate {
    transform: rotate(0)!important;
  }

  .help-box {
    padding: 0.5rem 0;
    font-size: 0.6rem
  }

  .help-box .help-block+.help-block {
    border-top: 1px solid #eee;
  }
  .cont{font-size: 0.55rem;background: #f4f4f4}
  .lm-font-sm{color: #999;font-size: 0.55rem;}
  .text-indent{text-indent: 1rem}
  .help-block .title,
  .service {
    background-color: #fff;
    padding: 0.5rem 0.5rem 0.5rem;
  }

  .help-block .title .arrow {
    width: 0.8rem;
    height: 0.8rem;
    transition: all .3s;
    transform: rotate(-90deg);
  }

  .help-block .cont {
    line-height: 1.1rem;
    padding:  0 0.4rem 0.4rem;
  }

  .service .tel-img {
    margin-right: 0.5rem;
    border-radius: 50%;
    width: 1.8rem;
    height: 1.8rem;
    background-position: center center;
    background-repeat: no-repeat;
    background-size: 1.4rem 1.4rem;
    background-color: #1DCB98;
    background-image: url("../../assets/images/tel.png");
  }

  .service .contact {
    padding: 0.1rem 0.2rem;
    border-radius: 3px;
    color: #b4282d;
    border: 1px solid #b4282d;
  }

  .slide-fade-enter-active {
    transition: all .3s ease;
  }

  .slide-fade-leave-active {
    transition: all .3s cubic-bezier(1.0, 0.5, 0.8, 1.0);
  }

  .slide-fade-enter,
  .slide-fade-leave-to
    /* .slide-fade-leave-active for below version 2.1.8 */

  {
    transform: translateX(10px);
    opacity: 0;
  }
</style>

<template>
	<div class="container">
		<Mheader :show='true'>
			<div slot="title">客户中心</div>
			<div class="msg" slot="info">
			</div>
		</Mheader>

		<div class="help-box">
			<div class="help-block">
				<div class="flex-between title" @click="toggleLook(0)">
					<span>1、蛮划算是怎样的模式？</span>
					<img class="arrow" :class="{rotate:cont0}" src="../../assets/images/arrow1.png" />
				</div>
				<transition name="slide-fade">
					<div v-show="cont0" class="cont">
						<div class="font600"></div>
						<div class="lm-font-sm lm-margin-t-xs">
               <p class="text-indent">
                 深圳市前海蛮划算科技有限公司创立于2017年3月，总部坐落于有着“中国硅谷”之称南山区高新技术软件园，是一家理念创新，
                 管理先进的高科技互联网公司。 公司依托旗下开发的蛮划算移动电商综合服务平台，为众多中小企业提供了一站式营销、运营、推广服务，
                 降低企业成本，增加收益。同时，公司以企业战略顶层设计创新为手段，以“财散人聚、人聚财来”为经营宗旨，首创“消费循环”的全新商业模式，
                 为广大消费者提供更好、更多、更实惠的家庭消费增值解决方案，拉近了老百姓、商城、商家的距离，从而实现了三者共赢。 我们期待与各界人士携手
                 ，借助互联网共享经济国家战略趋势，打造出一个平衡式共享共赢的社会和谐局面。
               </p>

            </div>
					</div>
				</transition>
			</div>
			<div class="help-block">
				<div class="flex-between title" @click="toggleLook(1)">
					<span>2、如何注册账号？</span>
					<img class="arrow" :class="{rotate:cont1}" src="../../assets/images/arrow1.png" />
				</div>
				<transition name="slide-fade">
					<div v-show="cont1" class="cont">
						<div class="font600"></div>
						<div class="lm-font-sm lm-margin-t-xs">
              <p>第一步：下载蛮划算商户版APP；</p>
              <p>第二步：进入登录页面，点击“立即注册”；</p>
              <p>第三步：填写手机号码，获取验证码；</p>
              <p>第四步：填写验证码和密码，点击“注册”（如有推荐人，请务必填写准确的邀请码哦）。</p>
						</div>

					</div>
				</transition>
			</div>
			<div class="help-block">
				<div class="flex-between title" @click="toggleLook(2)">
					<span>3、注册时手机收不到验证码怎么办？</span>
					<img class="arrow" :class="{rotate:cont2}" src="../../assets/images/arrow1.png" />
				</div>
				<transition name="slide-fade">
          <div v-show="cont2" class="cont">
            <div class="font600"></div>
            <div class="lm-font-sm lm-margin-t-xs">
              <p class="text-indent">如未收到验证码，请排查以下可能导致的原因：</p>
              <p>A. 核对输入的手机号码是否正确；</p>
              <p>B. 手机是否处于网络连接状态；</p>
              <p>C. 手机号码是否停机；</p>
              <p>由于通信网络等原因出现延迟的情况，尝试换一个时间段再试，或将手机卡放在其他手机里。</p>
            </div>

          </div>
				</transition>
			</div>
			<div class="help-block">
				<div class="flex-between title" @click="toggleLook(3)">
					<span>4、忘记密码怎么办？</span>
					<img class="arrow" :class="{rotate:cont3}" src="../../assets/images/arrow1.png" />
				</div>
				<transition name="slide-fade">
					<div v-show="cont3" class="cont">
            <p class="text-indent">进入登录页面点击“忘记密码”，输入手机号找回密码，按照页面提示操作即可。</p>
					</div>
				</transition>
			</div>
			<div class="help-block">
				<div class="flex-between title" @click="toggleLook(4)">
					<span>5、如何修改昵称？</span>
					<img class="arrow" :class="{rotate:cont4}" src="../../assets/images/arrow1.png" />
				</div>
				<transition name="slide-fade">
					<div v-show="cont4" class="cont">
            <p class="text-indent">进入“我的”页面，点击头像进去“个人主页-昵称” 进行修改。</p>
					</div>
				</transition>
			</div>
      <div class="help-block">
        <div class="flex-between title" @click="toggleLook(5)">
          <span>6、如何进行实名认证？</span>
          <img class="arrow" :class="{rotate:cont5}" src="../../assets/images/arrow1.png" />
        </div>
        <transition name="slide-fade">
          <div v-show="cont5" class="cont">
            <p>第一步：点击“我的”；</p>
            <p>第二步：点击头像栏进入，“个人主页-实名认证”；</p>
            <p>第三步：填写与个人持有的身份证一致的姓名与身份证号；</p>
            <p>第四步：勾选协议，点击“提交”。</p>
          </div>
        </transition>
      </div>
      <div class="help-block">
        <div class="flex-between title" @click="toggleLook(6)">
          <span>7、为什么需要实名认证？</span>
          <img class="arrow" :class="{rotate:cont6}" src="../../assets/images/arrow1.png" />
        </div>
        <transition name="slide-fade">
          <div v-show="cont6" class="cont">
            <p class="text-indent">在您消费的过程中将与商城涉及充值、支付、消费和提现等资金交易过程，为使您更好地使用蛮划算商城的各项服务，保障您的账户安全，蛮划算要求您注册及使用蛮划算商城服务时必须提供真实身份信息。</p>
          </div>
        </transition>
      </div>
		</div>

		<Mfooter :myCenterCurrent='true'></Mfooter>
	</div>
</template>

<script>
	import Mheader from '../../components/Mheader'
	import Mfooter from '../../components/Mfooter'

	export default {
		components: {
			Mheader,
			Mfooter
		},
		data() {
			return {
				cont0: false,
				cont1: false,
				cont2: false,
				cont3: false,
				cont4: false,
        cont5: false,
        cont6: false,
			}
		},
		methods: {
			toggleLook(e) {
				switch(e) {
					case 0:
						this.cont0 = !this.cont0
						break;
					case 1:
						this.cont1 = !this.cont1
						break;
					case 2:
						this.cont2 = !this.cont2
						break;
					case 3:
						this.cont3 = !this.cont3
						break;
          case 4:
            this.cont4 = !this.cont4
            break;
          case 5:
            this.cont5 = !this.cont5
            break;
					default:
						this.cont6 = !this.cont6
				}
			}
		}
	}
</script>

<style scoped>
	.rotate {
		transform: rotate(0)!important;
	}

	.help-box {
		padding: 0.5rem 0;
    font-size: 0.6rem
	}

	.help-box .help-block+.help-block {
		border-top: 1px solid #eee;
	}
  .cont{font-size: 0.55rem;background: #f4f4f4}
  .lm-font-sm{color: #999;font-size: 0.55rem;}
  .text-indent{text-indent: 1rem}
	.help-block .title,
	.service {
		background-color: #fff;
		padding: 0.5rem 0.5rem 0.5rem;
	}

	.help-block .title .arrow {
		width: 0.8rem;
		height: 0.8rem;
		transition: all .3s;
		transform: rotate(-90deg);
	}

	.help-block .cont {
		line-height: 1.1rem;
		padding:  0 0.4rem 0.4rem;
	}

	.service .tel-img {
		margin-right: 0.5rem;
		border-radius: 50%;
		width: 1.8rem;
		height: 1.8rem;
		background-position: center center;
		background-repeat: no-repeat;
		background-size: 1.4rem 1.4rem;
		background-color: #1DCB98;
		background-image: url("../../assets/images/tel.png");
	}

	.service .contact {
		padding: 0.1rem 0.2rem;
		border-radius: 3px;
		color: #b4282d;
		border: 1px solid #b4282d;
	}

	.slide-fade-enter-active {
		transition: all .3s ease;
	}

	.slide-fade-leave-active {
		transition: all .3s cubic-bezier(1.0, 0.5, 0.8, 1.0);
	}

	.slide-fade-enter,
	.slide-fade-leave-to
	/* .slide-fade-leave-active for below version 2.1.8 */

	{
		transform: translateX(10px);
		opacity: 0;
	}
</style>

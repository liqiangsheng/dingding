<template>
  <div class="container">
    <Mheader style="border-bottom: 1px solid #eee;">
      <div slot="title">客服中心</div>
      <!--<div slot="info" @click='saveUserInfo'>保存</div>-->
    </Mheader>
      <div class="CustomerHone_box">
       <div class="CustomerHone_box_top">
         <img src="../../assets/images/home/search.png" alt="">
         <input type="text" placeholder="有问题？点我">
       </div>
        <div class="CustomerHone_box_centet">
          <div >
            <router-link to="/helpCenterAccount">
            <p class="CustomerHone_box_centet_p"><span> <img src="../../assets/images/CustomerHome/mine_sel@2x.png" alt=""></span><b>账号相关问题解答</b><span><img src="../../assets/images/CustomerHome/more@2x.png" alt=""></span></p>
            <ul class="CustomerHone_box_centet_ul">
              <li>1、蛮划算是怎样的模式？</li>
              <li>2、如何注册账号？</li>
              <li>3、注册时手机收不到验证码怎么办？</li>
            </ul>
              </router-link >
          </div>
          <div >
            <router-link to="/helpCenterPromote">
            <div class="CustomerHone_box_centet_div"></div>
            <p class="CustomerHone_box_centet_p"><span> <img src="../../assets/images/CustomerHome/mine_sel@2x.png" alt=""></span><b>推广相关问题解答</b><span><img src="../../assets/images/CustomerHome/more@2x.png" alt=""></span></p>
            <ul class="CustomerHone_box_centet_ul">
              <li>1、什么是粉丝？</li>
              <li>2、直接粉丝和间接粉丝的区别？</li>
              <li>3、推荐用户/商家有什么好处？</li>
            </ul>
            </router-link >
          </div>
          <div >
            <router-link to="/helpCenterPay">
            <div class="CustomerHone_box_centet_div"></div>
            <p class="CustomerHone_box_centet_p"><span> <img src="../../assets/images/CustomerHome/mine_sel@2x.png" alt=""></span><b>支付相关问题解答</b><span><img src="../../assets/images/CustomerHome/more@2x.png" alt=""></span></p>
            <ul class="CustomerHone_box_centet_ul">
              <li>1、有哪些支付方式？</li>
            </ul>
            </router-link>
          </div>
          <div >
            <router-link to="/helpCenterVersion">
            <div class="CustomerHone_box_centet_div"></div>
            <p class="CustomerHone_box_centet_p"><span> <img src="../../assets/images/CustomerHome/mine_sel@2x.png" alt=""></span><b>版本相关问题解答</b><span><img src="../../assets/images/CustomerHome/more@2x.png" alt=""></span></p>
            <ul class="CustomerHone_box_centet_ul">
              <li>1、怎么查看蛮划算用户版APP的版本？</li>
            </ul>
            </router-link>
          </div>
          <div >
            <router-link to="/helpCenterContact">
            <div class="CustomerHone_box_centet_div"></div>
            <p class="CustomerHone_box_centet_p"><span> <img src="../../assets/images/CustomerHome/mine_sel@2x.png" alt=""></span><b>联系客服</b><span><img src="../../assets/images/CustomerHome/more@2x.png" alt=""></span></p>
            <ul class="CustomerHone_box_centet_ul">
              <li>1、如何直接与蛮划算联系？</li>
            </ul>
            </router-link>
          </div>
        </div>
      </div>
  </div>

</template>

<script>
  import Mheader from '../../components/Mheader'
  import { Toast } from 'mint-ui'
  export default {
    components: {
      Mheader,
    },
    data() {
      return {
      }
    },
    methods: {


    },
    mounted: function() {
      this.$nextTick(() => {


      })
    }
  }
</script>

<style >
  html{background: #f4f4f4}
  .CustomerHone_box{background: #fff ;padding-top: .3rem}
  .CustomerHone_box_top{width: 90%;height: 1.6rem;line-height: 1.6rem;border: 1px solid #f4f4f4;padding-left: .6rem;background: #f4f4f4;margin: 0 auto;border-radius: 1rem;}
  .CustomerHone_box_top img{width: 0.7rem;margin-bottom: .5rem}
  .CustomerHone_box_top input{height: 1.3rem;line-height: 1.3rem;width: 80%;border: none;background: #f4f4f4;padding-left: .4rem}
  .CustomerHone_box_centet img{width: 0.8rem}
  .CustomerHone_box_centet_div{background: #f4f4f4;height: .4rem}
  .CustomerHone_box_centet_p{display: flex;padding: .6rem;border-bottom: 1px solid #eee;background:#fff}
  .CustomerHone_box_centet_p b{flex: 1;padding-left: .6rem;font-weight: 500;}
  .CustomerHone_box_centet_ul{padding: .6rem;color: #999;background: #fff}
  .CustomerHone_box_centet_ul li{padding: .2rem;font-size: 0.55rem}
</style>

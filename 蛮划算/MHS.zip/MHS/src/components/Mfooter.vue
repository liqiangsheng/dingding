<template>
    <nav class="nav-bottom">
      <router-link to="/">
        <span class="nav-icon nav-icon-index" :class="{ indexCurrent: indexCurrent }"></span>
        <span class=" nav-icon-index1" :class="{ indexCurrent1: indexCurrent }">商城</span>
      </router-link>
      <router-link to="/Category">
        <span class="nav-icon nav-icon-shop" :class="{ shopCurrent: shopCurrent }"></span>
        <span class=" nav-icon-shop1" :class="{ shopCurrent1: shopCurrent }">分类</span>

      </router-link>
       <!--<router-link to="/TcHome">-->
      <!--<span class="nav-icon nav-icon-world" :class="{ worldCurrent: worldCurrent }"></span>-->
         <!--活动-->
      <!--</router-link>-->
      <router-link to="/Cart">
        <span class="nav-icon nav-icon-cart" :class="{ cartCurrent: cartCurrent }"></span>
        <span class="nav-icon-cart1" :class="{ cartCurrent1: cartCurrent }">购物车</span>
      </router-link>
      <router-link to="/MyHome">
        <span class="nav-icon nav-icon-myCenter" :class="{ myCenterCurrent: myCenterCurrent }"></span>
        <span class="nav-icon-myCenter1" :class="{ myCenterCurrent1: myCenterCurrent }">我的</span>
      </router-link>
    </nav>
</template>

<script>
  export default {
    name: 'Footer',
    props: {
      indexCurrent: false,
      indexCurrent1:false,
      shopCurrent1: false,
      shopCurrent: false,
      worldCurrent: false,
      cartCurrent: false,
      cartCurrent1:false,
      myCenterCurrent: false,
      myCenterCurrent1:false,
    }
  }
</script>

<style scoped>
  /*底部导航*/
  .nav-bottom {
    width: 100%;
    height: 2.4rem;
    position: fixed;
    z-index: 911;
    bottom: 0;
    background-color: #fff;
    display: flex;
    border-top: 1px solid #dedede;
  }

  .nav-bottom > a {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    width: 25%;
    height: 100%;
  }

  .nav-bottom .nav-icon {
    width: 1.2rem;
    height: 1rem;
    background-size: 100% 100%;
  }

  .nav-icon-index {
    background-image: url("../assets/images/tabBar/home_nor@2x.png");
  }
  .nav-icon-index1 {
    color: #999999;
    font-size: 0.55rem;

  }
  .nav-icon-shop {
    background-image: url("../assets/images/tabBar/near_nor@2x.png");
  }
 .nav-icon-shop1{
    color: #999999;
    font-size: 0.55rem;
  }
  .nav-icon-world {
    background-image: url("../assets/images/tabBar/world.png");
  }

  .nav-icon-cart {
    background-image: url("../assets/images/tabBar/shop_nor@2x.png");
  }
  .nav-icon-cart1 {
    color: #999999;
    font-size: 0.55rem;
  }
  .nav-icon-myCenter {
    background-image: url("../assets/images/tabBar/mine_nor@2x.png");
  }
  .nav-icon-myCenter1 {
    color: #999999;
    font-size: 0.55rem;
  }
  /*当前底部导航*/
  .indexCurrent {
    background-image: url("../assets/images/tabBar/home_sel@2x.png");
  }
  .indexCurrent1 {
    color: #e60039;
    font-size: 0.55rem;
  }
  .shopCurrent {
    background-image: url("../assets/images/tabBar/near_sel@2x.png");
  }
  .shopCurrent1 {
    color: #e60039;
    font-size: 0.55rem;
  }
  .worldCurrent {
    background-image: url("../assets/images/tabBar/world_current.png");
  }

  .cartCurrent {
    background-image: url("../assets/images/tabBar/shop_sel@2x.png");
  }
 .cartCurrent1{
    color: #e60039;
    font-size: 0.55rem;
  }
  .myCenterCurrent {
    background-image: url("../assets/images/tabBar/mine_sel@2x.png");
  }
  .myCenterCurrent1 {
    color: #e60039;
    font-size: 0.55rem;
  }
</style>

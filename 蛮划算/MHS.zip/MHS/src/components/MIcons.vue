<template>
<div class='icons' style="padding-top: .4rem ;background: #ffffff">
   <div class="mode-box">

        <MmodeIcon v-for="(item,index) in Icons" :key="item.ProductId" :index="index" :portalId="item.portalId"
                   :portalImage="imgBaseUrl+item.portalImage" :portalName="item.portalName" :productPrice="item.SalePrice" :target="item.target"></MmodeIcon>
  </div>
</div>
</template>
<script>

	import MmodeIcon from './Mode/MmodeIcon'
	import { Toast } from 'mint-ui'
  export default {
    name: 'MIcon',
    props: {
      Icons: Array,
    },
    data() {
      return {

        swiperOption: {
          pagination:'.swiper-pagination',
          loop:true,
          // some swiper options/callbacks
          // 所有的参数同 swiper 官方 api 参数
          // ...
        },
        iconList:[
        {
            "SalePrice":'陕货南行',
            "ClassName":null,
            "PVName":null,
            "ProductId":"69ea1e7c36d94d7396c2f96f2f580359",
            "ProductNum":null,
            "Name":"绿茶 炒青高山云雾绿茶袋装250g 买一送一",
            "HeadImg":"https://gw.alicdn.com/tps/TB1FDOHLVXXXXcZXFXXXXXXXXXX-183-129.png?imgtag=avatar",
            "Describe":null,
            "AllStock":0,
            "Price":158,
            "ProductUrl":null,
            "State":0,
            "IsDelete":0,
            "Template":null,
            "ProductClassifyId":null,
            "CreateTime":"0001-01-01 00:00:00",
            "Remark":null,
            "SaleComment":null,
            "ProductTagIds":null,
            "MerchantId":null,
            "Sort":0,
            "IsPromotion":0,
            "SubTitle":null,
            "IsMall":0,
            "PerPrice":0,
            "PropertyValueIds":null,
            "Score":0,
            "Sketch":null,
            "Grade":0,
            "GradeIsDetail":0,
            "SaleSum":0,
            "RealSales":0,
            "IsExtra":0,
            "ClickNum":0,
            "DiscussNum":0,
            "IsMain":0,
            "IsHot":0,
            "ProductSubClassifyId":null,
            "TeaToolClassifyIds":null,
            "CPSDiscount":0
        },
        {
            "SalePrice":'自营专区',
            "ClassName":null,
            "PVName":null,
            "ProductId":"ae87b6230b5a40ab811bb576ed51722c",
            "ProductNum":null,
            "Name":"2017新茶正宗黄山特级太平猴魁200g",
            "HeadImg":"https://gw.alicdn.com/tps/i2/TB19BluIVXXXXX6XpXXN4ls0XXX-183-129.png?imgtag=avatar",
            "Describe":null,
            "AllStock":0,
            "Price":288,
            "ProductUrl":null,
            "State":0,
            "IsDelete":0,
            "Template":null,
            "ProductClassifyId":null,
            "CreateTime":"0001-01-01 00:00:00",
            "Remark":null,
            "SaleComment":null,
            "ProductTagIds":null,
            "MerchantId":null,
            "Sort":0,
            "IsPromotion":0,
            "SubTitle":null,
            "IsMall":0,
            "PerPrice":0,
            "PropertyValueIds":null,
            "Score":0,
            "Sketch":null,
            "Grade":0,
            "GradeIsDetail":0,
            "SaleSum":0,
            "RealSales":0,
            "IsExtra":0,
            "ClickNum":0,
            "DiscussNum":0,
            "IsMain":0,
            "IsHot":0,
            "ProductSubClassifyId":null,
            "TeaToolClassifyIds":null,
            "CPSDiscount":0
        },
        {
            "SalePrice":'新人专区',
            "ClassName":"[mall]信阳毛尖",
            "PVName":"登堂入室",
            "ProductId":"737a975ae61245e4b2586a2fb4360d82",
            "ProductNum":"xymj99",
            "Name":"拍一发二 共250g 信阳毛尖早春新茶",
            "HeadImg":"https://gw.alicdn.com/tps/TB1PlmNLVXXXXXEXFXXXXXXXXXX-183-129.png?imgtag=avata",
            "Describe":"",
            "AllStock":298,
            "Price":298,
            "ProductUrl":null,
            "State":1,
            "IsDelete":0,
            "Template":"",
            "ProductClassifyId":"7c3f558606074157b9ee4f131c073e3a",
            "CreateTime":"2017-07-08 13:34:17",
            "Remark":"【99元特价尝鲜活动】 买125g送125g，铁罐装共250g 每日限量500份！",
            "SaleComment":null,
            "ProductTagIds":"77d8f21ccb774fd3843767d57ebb527d,291fdbb0c13b437c85a1214391a22fca,c996e6f4a4614793a42f89428eab7039,e72bbaa5b578449a8a42def3ef086599",
            "MerchantId":"",
            "Sort":82,
            "IsPromotion":0,
            "SubTitle":"信阳原产 纯手工好茶 ",
            "IsMall":1,
            "PerPrice":198,
            "PropertyValueIds":"[26],[29],[32],[21],[52]",
            "Score":0,
            "Sketch":"",
            "Grade":38,
            "GradeIsDetail":0,
            "SaleSum":325,
            "RealSales":91,
            "IsExtra":1,
            "ClickNum":0,
            "DiscussNum":0,
            "IsMain":0,
            "IsHot":0,
            "ProductSubClassifyId":"545e36d86cd1460ca3b6c25015130d45",
            "TeaToolClassifyIds":null,
            "CPSDiscount":75
        },
        {
            "SalePrice":"惠啦专区",
            "ClassName":null,
            "PVName":null,
            "ProductId":"5ed452a785a04eed8703fee6fbcf7684",
            "ProductNum":null,
            "Name":"云南普洱茶饼老班章普洱熟茶 2009年特级熟茶357g",
            "HeadImg":"//gw.alicdn.com/tps/TB1RN0HMFXXXXXNXpXXXXXXXXXX-183-129.png?imgtag=avatar",
            "Describe":null,
            "AllStock":0,
            "Price":168,
            "ProductUrl":null,
            "State":0,
            "IsDelete":0,
            "Template":null,
            "ProductClassifyId":null,
            "CreateTime":"0001-01-01 00:00:00",
            "Remark":null,
            "SaleComment":null,
            "ProductTagIds":null,
            "MerchantId":null,
            "Sort":0,
            "IsPromotion":0,
            "SubTitle":null,
            "IsMall":0,
            "PerPrice":0,
            "PropertyValueIds":null,
            "Score":0,
            "Sketch":null,
            "Grade":0,
            "GradeIsDetail":0,
            "SaleSum":0,
            "RealSales":0,
            "IsExtra":0,
            "ClickNum":0,
            "DiscussNum":0,
            "IsMain":0,
            "IsHot":0,
            "ProductSubClassifyId":null,
            "TeaToolClassifyIds":null,
            "CPSDiscount":0
        },
        {
            "SalePrice":"非常划算",
            "ClassName":"[mall]白豪银针",
            "PVName":"渐入佳境",
            "ProductId":"5a27f0db15bd45439c19ab74b96ff99d",
            "ProductNum":"fdbc268",
            "Name":"正宗福鼎白茶明前白毫银针 礼盒装200g",
            "HeadImg":"https://gw.alicdn.com/tps/TB1exaOLVXXXXXeXFXXXXXXXXXX-183-129.png?imgtag=avatar",
            "Describe":"",
            "AllStock":588,
            "Price":588,
            "ProductUrl":"",
            "State":1,
            "IsDelete":0,
            "Template":"",
            "ProductClassifyId":"7c3f558606074157b9ee4f131c073e3a",
            "CreateTime":"2017-11-17 17:36:08",
            "Remark":"",
            "SaleComment":"",
            "ProductTagIds":"ff918702ac314ee98b26172d35815360,291fdbb0c13b437c85a1214391a22fca,068cf06410bd48629a01a98fd514e9bc,ed23bfc478454e158fedf02f1722f1d9,93843e7fcccd4ffa9ede6ad3b20aac2c,095280620b5e4a99982bf16032da3d78",
            "MerchantId":"",
            "Sort":0,
            "IsPromotion":1,
            "SubTitle":"首日芽 弥足珍贵 花香银针 送礼佳品",
            "IsMall":1,
            "PerPrice":670,
            "PropertyValueIds":"[26],[31],[34],[22],[45]",
            "Score":0,
            "Sketch":"",
            "Grade":40,
            "GradeIsDetail":1,
            "SaleSum":172,
            "RealSales":172,
            "IsExtra":1,
            "ClickNum":0,
            "DiscussNum":0,
            "IsMain":0,
            "IsHot":0,
            "ProductSubClassifyId":"a4904858fb8a46c29f0e4c9612ce5712",
            "TeaToolClassifyIds":"",
            "CPSDiscount":75
        },
        {
            "SalePrice":"食品饮品",
            "ClassName":"[mall]信阳毛尖",
            "PVName":"登堂入室",
            "ProductId":"737a975ae61245e4b2586a2fb4360d88",
            "ProductNum":"xymj99",
            "Name":"拍一发二 共250g 信阳毛尖早春新茶",
            "HeadImg":"https://img.alicdn.com/tps/TB1GzMJLXXXXXXoXXXXXXXXXXXX-183-129.png",
            "Describe":"",
            "AllStock":298,
            "Price":298,
            "ProductUrl":null,
            "State":1,
            "IsDelete":0,
            "Template":"",
            "ProductClassifyId":"7c3f558606074157b9ee4f131c073e3a",
            "CreateTime":"2017-07-08 13:34:17",
            "Remark":"【99元特价尝鲜活动】 买125g送125g，铁罐装共250g 每日限量500份！",
            "SaleComment":null,
            "ProductTagIds":"77d8f21ccb774fd3843767d57ebb527d,291fdbb0c13b437c85a1214391a22fca,c996e6f4a4614793a42f89428eab7039,e72bbaa5b578449a8a42def3ef086599",
            "MerchantId":"",
            "Sort":82,
            "IsPromotion":0,
            "SubTitle":"信阳原产 纯手工好茶 ",
            "IsMall":1,
            "PerPrice":198,
            "PropertyValueIds":"[26],[29],[32],[21],[52]",
            "Score":0,
            "Sketch":"",
            "Grade":38,
            "GradeIsDetail":0,
            "SaleSum":325,
            "RealSales":91,
            "IsExtra":1,
            "ClickNum":0,
            "DiscussNum":0,
            "IsMain":0,
            "IsHot":0,
            "ProductSubClassifyId":"545e36d86cd1460ca3b6c25015130d45",
            "TeaToolClassifyIds":null,
            "CPSDiscount":75
        },
        {
            "SalePrice":"服装鞋包",
            "ClassName":"[mall]寿眉",
            "PVName":"略有小成",
            "ProductId":"fc8139723b2d4bf09aacc486332e0744",
            "ProductNum":"lsm99",
            "Name":"2012年福鼎白茶老寿眉350g",
            "HeadImg":"http://gw.alicdn.com/tps/TB1LNMxPXXXXXbhaXXXXXXXXXXX-183-129.png",
            "Describe":"",
            "AllStock":228,
            "Price":228,
            "ProductUrl":"",
            "State":1,
            "IsDelete":0,
            "Template":"",
            "ProductClassifyId":"7c3f558606074157b9ee4f131c073e3a",
            "CreateTime":"2017-08-04 18:17:49",
            "Remark":"",
            "SaleComment":"",
            "ProductTagIds":"ff918702ac314ee98b26172d35815360,77d8f21ccb774fd3843767d57ebb527d,291fdbb0c13b437c85a1214391a22fca,c996e6f4a4614793a42f89428eab7039,93843e7fcccd4ffa9ede6ad3b20aac2c",
            "MerchantId":"",
            "Sort":78,
            "IsPromotion":1,
            "SubTitle":"馥古老茶 沉香四溢 煮茶必选 待客佳品 ",
            "IsMall":1,
            "PerPrice":142,
            "PropertyValueIds":"[27],[29],[32],[23],[45]",
            "Score":0,
            "Sketch":"",
            "Grade":39,
            "GradeIsDetail":1,
            "SaleSum":271,
            "RealSales":37,
            "IsExtra":1,
            "ClickNum":0,
            "DiscussNum":0,
            "IsMain":0,
            "IsHot":0,
            "ProductSubClassifyId":"70b7e66ccbe5479f8aad254b3acc19a8",
            "TeaToolClassifyIds":"",
            "CPSDiscount":75
        },
        {
            "SalePrice":"3C数码",
            "ClassName":"[mall]信阳毛尖",
            "PVName":"已臻大成",
            "ProductId":"2bfde085eafd4442a28ba353a09d2a44",
            "ProductNum":"xymj158",
            "Name":"2017新茶 信阳毛尖雨前茶礼盒250g",
            "HeadImg":"https://gw.alicdn.com/tps/TB1cniBJpXXXXataXXXXXXXXXXX-183-129.png?imgtag=avatar",
            "Describe":"",
            "AllStock":398,
            "Price":398,
            "ProductUrl":"",
            "State":1,
            "IsDelete":0,
            "Template":"",
            "ProductClassifyId":"7c3f558606074157b9ee4f131c073e3a",
            "CreateTime":"2017-07-20 10:29:20",
            "Remark":"全国包邮 货到付款",
            "SaleComment":"",
            "ProductTagIds":"ff918702ac314ee98b26172d35815360,77d8f21ccb774fd3843767d57ebb527d,291fdbb0c13b437c85a1214391a22fca,a1b6016e900f4a3fa3fde0ddc4389824,068cf06410bd48629a01a98fd514e9bc,74b4775490124c7abe58672c1fe7d0a1",
            "MerchantId":"",
            "Sort":44,
            "IsPromotion":1,
            "SubTitle":"雨前新茶 手工礼盒",
            "IsMall":1,
            "PerPrice":316,
            "PropertyValueIds":"[26],[31],[33],[22],[52]",
            "Score":0,
            "Sketch":"",
            "Grade":41,
            "GradeIsDetail":0,
            "SaleSum":224,
            "RealSales":224,
            "IsExtra":0,
            "ClickNum":0,
            "DiscussNum":0,
            "IsMain":0,
            "IsHot":0,
            "ProductSubClassifyId":"545e36d86cd1460ca3b6c25015130d45",
            "TeaToolClassifyIds":"",
            "CPSDiscount":75
        },
        {
            "SalePrice":"电脑办公",
            "ClassName":"[mall]碧螺春",
            "PVName":"渐入佳境",
            "ProductId":"b6cec4a9bcf9457eb86c77065968743d",
            "ProductNum":"blc228",
            "Name":"洞庭碧螺春绿茶雨前特级400g礼盒",
            "HeadImg":"https://img.alicdn.com/tfs/TB1Kxe8QFXXXXbSXVXXXXXXXXXX-183-129.png",
            "Describe":"",
            "AllStock":478,
            "Price":478,
            "ProductUrl":"",
            "State":1,
            "IsDelete":0,
            "Template":"",
            "ProductClassifyId":"7c3f558606074157b9ee4f131c073e3a",
            "CreateTime":"2017-07-24 16:18:41",
            "Remark":"",
            "SaleComment":"",
            "ProductTagIds":"ff918702ac314ee98b26172d35815360,291fdbb0c13b437c85a1214391a22fca,a1b6016e900f4a3fa3fde0ddc4389824,068cf06410bd48629a01a98fd514e9bc,74b4775490124c7abe58672c1fe7d0a1,e72bbaa5b578449a8a42def3ef086599",
            "MerchantId":"",
            "Sort":34,
            "IsPromotion":1,
            "SubTitle":"清香回甘 味浓醇正 正品实惠 ",
            "IsMall":1,
            "PerPrice":288,
            "PropertyValueIds":"[27],[31],[34],[22],[49]",
            "Score":0,
            "Sketch":"",
            "Grade":40,
            "GradeIsDetail":0,
            "SaleSum":279,
            "RealSales":279,
            "IsExtra":1,
            "ClickNum":0,
            "DiscussNum":0,
            "IsMain":0,
            "IsHot":0,
            "ProductSubClassifyId":"cc7afd36f1a04df68a9dc857af6442c2",
            "TeaToolClassifyIds":"",
            "CPSDiscount":75
        },
        {
            "SalePrice":'家用电器',
            "ClassName":"[mall]铁观音",
            "PVName":"渐入佳境",
            "ProductId":"dae874c59c56448f99c8045753b5cf0f",
            "ProductNum":"tgy198",
            "Name":"【买一送一】东方韵200g铁观音铁罐装",
            "HeadImg":"https://gw.alicdn.com/tps/i1/TB1c1FMIpXXXXawXpXXN4ls0XXX-183-129.png?imgtag=avatar",
            "Describe":"",
            "AllStock":396,
            "Price":396,
            "ProductUrl":"",
            "State":1,
            "IsDelete":0,
            "Template":"",
            "ProductClassifyId":"7c3f558606074157b9ee4f131c073e3a",
            "CreateTime":"2017-07-14 10:40:19",
            "Remark":"",
            "SaleComment":"",
            "ProductTagIds":"d9ee90be22804598add60ca9ece469e5,ff918702ac314ee98b26172d35815360,77d8f21ccb774fd3843767d57ebb527d,291fdbb0c13b437c85a1214391a22fca,ca482e57ed0e434f935e47872f69614a,068cf06410bd48629a01a98fd514e9bc,973b4f8f39b947edad3f072abc32b60d,21e97d03d88f4330851",
            "MerchantId":"",
            "Sort":32,
            "IsPromotion":1,
            "SubTitle":"香气高 音韵显",
            "IsMall":1,
            "PerPrice":248,
            "PropertyValueIds":"[26],[29],[30],[33],[21],[44]",
            "Score":0,
            "Sketch":"",
            "Grade":40,
            "GradeIsDetail":1,
            "SaleSum":292,
            "RealSales":58,
            "IsExtra":1,
            "ClickNum":0,
            "DiscussNum":0,
            "IsMain":0,
            "IsHot":1,
            "ProductSubClassifyId":"131daf282cc04e68aa58290570fc51c2",
            "TeaToolClassifyIds":"",
            "CPSDiscount":75
        }
    	]
      }
    },
    computed: {    //计算属性
      pages (){
        const pages=[]
        this.iconList.forEach((item,index)=>{
          const page=Math.floor(index/10)
          if(!pages[page]){
            pages[page]=[]
          }
          pages[page].push(item)
        })
        return pages;
      }
    },

     components: {
    MmodeIcon
  },
  }
</script>
<!--<style lang="stylus" scoped>
  @import '~style/varibles.styl'
  @import '~style/mixins.styl'
  .icons >>> .swiper-container
    height: 0
    padding-bottom: 54%
    background:#fff
    border-bottom:1px solid #E8E8E8

  .icons
    margin-top: .1rem
    .icon
      position: relative
      /*overflow: hidden*/
      float: left
      width: 20%
      height: 0
      padding-bottom: 25%
      .icon-img
        position: absolute
        top: 0
        left: 0
        right: 0
        bottom: 0rem
        box-sizing: border-box
        padding: .4rem
        .icon-img-content
          display: block
          margin: 0 auto
          height: 100%
      .icon-desc
        position: absolute
        left: 0
        right: 0
        bottom: 0
        height: .84rem
        line-height: .84rem
        text-align: center
        font-size:16px
        color: $darkTextColor
        ellipsis()
</style>-->

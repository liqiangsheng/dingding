<template>
  <div>
    <div class="cont"  >
      <div class="top">
        <span>{{orderProductList.sellerName}}</span>
        <span class="top_span" v-show="orderProductList.orderStatus==3"  @click="cancelOrder(item.ProductOrderId)">订单取消</span>
        <span class="top_span" v-show="orderProductList.orderStatus==18"  @click="cancelOrder(item.ProductOrderId)">已完成</span>
        <span class="top_span" v-show="orderProductList.orderStatus==4"  @click="cancelOrder(item.ProductOrderId)">超时支付取消</span>
        <span class="top_span" v-show="orderProductList.orderStatus==6"  @click="cancelOrder(item.ProductOrderId)">待商家发货</span>
      </div>
      <router-link :to="{path:'/OrderDetails/'+path}">
      <div class="mid" v-for="(items,index) in orderProductList.shopInfoList" :key="items.index">
        <div>
          <span><img alt="" v-lazy="imgBaseUrl+items.goodImg"></span>
          <div class="mid-cont">
            <span class="product-name">{{ items.goodsName }}</span>
            <span class="product-name lm-text-grey lm-font-xs lm-margin-t-xs attrConcat">{{ items.attrConcat }}</span>
            <span class="product-score">增送 <span class="product-score_span">{{ items.score }}</span>积分额度</span>
            <p class="product_p">
              <span class="product">￥{{ items.appPrice }}</span> <span class="number">x{{ items.total}}</span>
            </p>
          </div>
        </div>
      </div>
        </router-link>
      <div class="btn-group">
        <div class="cancel">
          <slot name="cancel"></slot>
        </div>
        <div class="btn">
          <slot name="btn"></slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

  export default {
    props: {
      path:'',
      orderList: '',
      OrderDetailsData: '',
      orderProductList:'',
    },
    methods: {

    }
  }
</script>

<style scoped>
  html{background: #f4f4f4}
  .top{font-size: 0.6rem;color: #999;
    padding-left: .4rem}
  .top_span{color: #c40241;}
  .product_p {
    width: 100%;
    height: 1.4rem;
    line-height: 1.4rem;
    display: flex
  }

  .product_p .product {
    flex: 2;
    color: #e50039;
    font-weight: 600;
    padding: 0;
    text-align: left;
  }

  .number {
    display: inline-block;
    color: #333;
    float: right;
    font-weight: 300
  }

  .product-score {;
    background: #f6bf5b;
    color: #fff;
    padding: .1rem;
    font-size: 0.55rem;
    border-radius: .2rem;
  }

  .attrConcat {
    font-size: 0.55rem;
  }

  .cont {
    margin-bottom: 0.5rem;
    background-color: #ffffff;
    border-bottom: 1px solid #eeeeee;
  }

  .mid {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0.4rem ;
    background: #fafafa;
    /*border-top:1px solid #eee;*/
  }

  .mid > div:first-child {
    width: 100%;
    display: flex;
    align-items: flex-start;
  }

  .mid img {
    width: 5rem;
    height: 5rem;
    margin-right: 0.5rem;
  }

  .mid .mid-cont {
    width: 100%;

  }

  .top, .btm {
    /*border-top:1px solid #eee;*/
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0.4rem ;
  }

  .btn-group {
    /*border-top:1px solid #eee;*/
    padding: 0.4rem ;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: flex-end;
  }

  .product-name {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    margin: .4rem 0;
  }

  .btn-group > div > span {
    min-width: 3rem;
    height: 1.3rem;
    line-height: 1.3rem;
    text-align: center;
    border: 1px solid;
    padding: 0 0.36rem;
    margin-left: 0.5rem;
  }

  .btn-group .cancel > span {
    color: #9d9d9d;
    border-color: #9d9d9d;
  }

  .btn-group .btn > span {
    font-size: 0.55rem;
    color: #999999;
    border-color: #999999;
    border-radius: .2rem;
  }
</style>

<template>

        <div >
          <router-link :to="{path:'/Seller/'+path}">
            <div class="sellerMode">
              <div class="sellmode-img">
                <img v-lazy="imgBaseUrl+imgSrc"/>
              </div>
              <div class="sellDiv">
                <p>{{ productName }}</p>
                <p  class="sellDiv_p"> 销量 {{ productSale }}</p>
              </div>

            </div>
          </router-link>
        </div>

</template>

<script>
	export default {
		props:{
			path:'',
      imgSrc:'',
      productName:'',
      productSale:'',
      productCPSDiscount:'',
      index:''
    }
  }
</script>

<style scoped>
  .sellerMode{display: flex;border-bottom: 1px solid #eee;margin-bottom: .3rem;background: #fff}
  .sellerMode div{margin-bottom:  .3rem;}
  /*.sellmode-img img{width: 100%;height: 4rem}*/
  .sellmode-img{width: 6rem;height: 4rem}
  .sellDiv{padding-left: .6rem}
  .sellDiv p{height: 2rem;line-height: 2rem}
  .sellDiv_p{color: #999}
</style>

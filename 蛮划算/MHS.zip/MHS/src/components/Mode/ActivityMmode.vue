<template>
  <div class="mode-listActicity" :class="{'mode-left_listActicity' : index % 2 !== 0}">
    <!--<router-link :to="{path:'/IconDetails/'+path}">-->
    <div  @click="one(target)">
      <div class="mode-listActicity_txt">
        <b>{{activityName}}</b>
        <span>{{activitySubhead}}</span>
      </div>
      <div class="mode-img_listActicity">
        <img v-lazy="imgBaseUrl+activityImg"/>
        <!--<img v-lazy="img"/>-->
      </div>
    </div>

    <!--</router-link>-->
  </div>

</template>

<script>
  import { Toast } from 'mint-ui'
  export default {
    props:{
      target:'',
      path:'',
      activityImg:'',
      img:'',
      activityName:'',
      activitySubhead:'',
      index:''
    },
    data() {
      return {
        tagId:'',

      }
    },
    methods:{
      one(target){
        console.log(target.uri,'target')
        if(target.uri=='score_trans_gift'||target.uri=='goods_to_goods'){
          Toast("敬请期待")
        }else{
          sessionStorage.setItem("target", JSON.stringify(target.params));
          this.$router.push({
            path: '/IconDetails',
          })
        }

      }

    }
  }
</script>
<style scoped>
  .mode-listActicity{width:60%;border-right: 1px solid #efefef;padding: .4rem;
    background-color: #fff;}
  .mode-left_listActicity{width: 40%;border-right: none;padding-left: .3rem}
  .mode-left_listActicity img{}
  .mode-img_listActicity{width: 90%;text-align: center}
  .mode-img_listActicity img{width:90%;}
  .mode-listActicity_txt b{font-size: 0.65rem;display: block;font-weight: 600}
  .mode-listActicity_txt span{font-size: 0.55rem;color: #999;}

</style>

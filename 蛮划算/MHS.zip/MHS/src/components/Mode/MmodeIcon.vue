<template>
        <div class="mode-listIcon" :class="{'mode-left' : index % 2 !== 0}">
          <!--<router-link :to="{ name: 'IconDetails', params: { target: target }}">-->
          <div @click="one(target)">
            <div class="mode-img">
              <img v-lazy="portalImage"/>
            </div>
            <!--<div class="mode-dp">{{ item.SaleComment }}</div>-->
            <div class="mode-title ">{{ portalName }}</div>
            <div class="mode-price">
              <span class="lm-text-red mode-price">{{ productPrice }}</span>
              <!--<span class="mode-btn" :to="{path:'/ProductDetails/'+path}">立即购买</span>-->
            </div>

          </div>

          <!--</router-link>-->
        </div>

</template>

<script>
  import { Toast } from 'mint-ui'

  export default {
		props:{
      path:'',
          portalImage:'',
          portalName:'',
		      productPrice:'',
          portalId:'',
          index:'',
          target:'',
    },
    data() {
      return {
        tagId:'',

      }
    },
    methods:{
      one(target){
        console.log(target.uri,'target')
        if(target.uri=='score_trans_gift'||target.uri=='goods_to_goods'||target.uri=='very_cal'||target.uri=='i_want_shop'  ){
          Toast("敬请期待")
        }else if(target.uri=='activity'){
          this.$router.push({
            path: '/TcHome',
          })
        }else if(target.uri=='i_want_recommend'){
          this.$router.push({
            path: '/Myrecommend',
          })
        }else if(target.uri=='score_trans' ){
          this.$router.push({
            path: '/TransferredHome',
          })
        }
        else{
          sessionStorage.setItem("target", JSON.stringify(target.params));
          this.$router.push({
            path: '/IconDetails',
          })
        }

      }

    }
  }
</script>

<style scoped>
	.mode-listIcon{width:20%;background: #fff;text-align: center;font-size: 0.55rem}
  .mode-listIcon img{width: 58%}
  .mode-box .mode-left{margin-left: 0}
	.lm-text-red{
		overflow: hidden;
		text-overflow:ellipsis;
		white-space: nowrap;
		color: #888888 !important;
		font-size: 0.55rem;
    font-weight: 100;
    font-family: "微软雅黑";

	}
  .mode-title{margin-top: .4rem}
  .mode-price{text-align: center;}
	.mode-img{border-radius: 2rem;}
</style>

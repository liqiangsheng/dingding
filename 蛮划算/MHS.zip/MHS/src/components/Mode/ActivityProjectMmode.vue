<template>

        <div class="ActivityProjectMmode_mode-list" :class="{'mode-left' : index % 2 !== 0}">
          <router-link :to="{path:'/ProductDetails/'+path}">
            <div class="mode-img">
              <img v-lazy="imgBaseUrl+imgUrl"/>
            </div>
            <!--<div class="mode-dp">{{ item.SaleComment }}</div>-->
            <div class="mode-title">
              <p class="mode-title_txt">{{ goodsName }}</p>
              </div>
            <div class="mode-price">
              <b class="tex">￥{{ price }}元</b>
            </div>
          </router-link>
        </div>

  <!--<div class="Proprietary_mode-list" :class="{'Proprietary_mode-left' : index % 2 !== 0}">-->
  <!--<router-link :to="{path:'/ProductDetails/'+path}">-->
      <!--<div class="Proprietary_box">-->
        <!--<div class="Proprietary_box_left">-->
          <!--<img v-lazy="imgSrc"/>-->
        <!--</div>-->
        <!--<div class="Proprietary_box_right">-->
          <!--<p>{{productName}}</p>-->
            <!--<div class="Proprietary_box_right_div">-->
              <!--<b>￥{{productPrice}}</b>-->
              <!--<span>销量：{{productSales}}</span>-->
            <!--</div>-->
        <!--</div>-->
      <!--</div>-->
  <!--</router-link>-->
  <!--</div>-->

</template>


<script>
	export default {
		props:{
			path:'',
      imgUrl:'',
      goodsName:'',
      price:'',
      productSales:"",
      index:''
    }
  }
</script>

<style scoped>
  .ActivityProjectMmode_mode-list img{width: 100px!important;height: 100px !important;}
  .ActivityProjectMmode_mode-list{width: 33.3%;font-size: 0.55rem;padding: .4rem;background: #fff}
  .ActivityProjectMmode_mode-list .mode-title{padding: .3rem .1rem}
  .mode-box .mode-left{margin-left: 0}
  .mode-title_txt{overflow: hidden;text-overflow:ellipsis;white-space: nowrap; }
  .tex{color: #e40139;font-weight: 600}
  .mode-img{border: 1px solid #f4f4f4}

</style>

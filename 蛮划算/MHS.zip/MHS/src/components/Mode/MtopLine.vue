<template>
    <!--<div id="topLine">-->
      <!--<span class="icon"></span>-->
      <!--<div class="move">-->
        <!--<ul class="animate" v-for="(item,index) in datas" :class="{'aShow':index===0,'bShow':index===1,'cShow':index===2}"  ref="ul">-->
          <!--<li class="border">{{item.name}}</li>-->
          <!--<li class="text">{{item.text}}</li>-->
        <!--</ul>-->
      <!--</div>-->
    <!--</div>-->
  <div class="moveList">
    <div class="move_left"><img src="../../assets/images/index_home/gonggao@2x.png" alt=""></div>
    <div class="move_center"><span class=""></span></div>
    <div class="move_right">
      <vue-seamless-scroll :data="News" :class-option="classOption" class="warp">
        <ul class="item">
          <li v-for="(value, index) in News">
            <span class="title" v-html="value"></span>
          </li>
        </ul>
      </vue-seamless-scroll>
    </div>

  </div>
</template>
<script>
  import axios from 'axios'
  import vueSeamlessScroll from 'vue-seamless-scroll'
    export default{
      props: {
        News: Array
      },
      data(){
        return {
          datas: [],
          pages:[
            {"name":"居家","text":"冰箱门上夹张纸，每个月竟能省下一半冰箱门上夹张纸，每个月竟能省下一半电费电费"},
            {"name":"汽车","text":"刹车失灵不要慌，冰箱门上夹张纸，每个月竟能省下一半电费车上还有第二套刹车系统"},
            {"name":"热文","text":"小米员工用苹果手机？雷军这回答666刹车失灵不要慌刹车失灵不要慌"}
            ],
        }
      },

      components: {
        vueSeamlessScroll
      },
      computed: {
        classOption: function () {
          return {
            step: 0.1,
            limitMoveNum: 3,
            waitTime: 30000
          }
        }
      }
      }

</script>
<style>
  .moveList{width: 100%;display: flex;background: #fff}
  .move_left{width:4rem;padding-left: .4rem;
    color: #e8a31a;}
  .move_left b{display: inline-block;margin: 0 .4rem;height: .8rem;line-height: .8rem;background: #ffb558;color: #fff;}

  .move_right{flex: 1;overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap; }
  .warp {
    height: 1.5rem;
    width: 100%;
    overflow: hidden;

  }
  .warp ul {
    list-style: none;
    padding: 0;
    margin: 0 auto;

  }
  .warp li {
    height: 1.5rem;
    line-height: 1.5rem;
    display: flex;
    justify-content: space-between;
    font-size:  0.55rem;


  }
  .title{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
  }
</style>

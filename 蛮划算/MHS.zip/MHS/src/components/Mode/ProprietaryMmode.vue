<template>

        <!--<div class="mode-list" :class="{'mode-left' : index % 2 !== 0}">-->
          <!--<router-link :to="{path:'/ProductDetails/'+path}">-->
            <!--<div class="mode-img">-->
              <!--<img v-lazy="imgSrc"/>-->
            <!--</div>-->
            <!--&lt;!&ndash;<div class="mode-dp">{{ item.SaleComment }}</div>&ndash;&gt;-->
            <!--<div class="mode-title">{{ productName }}</div>-->
            <!--<div class="mode-price">-->
              <!--<span class="lm-text-red">￥{{ productPrice }}元</span>-->
              <!--<span class="mode-btn" :to="{path:'/ProductDetails/'+path}">立即购买</span>-->
            <!--</div>-->
          <!--</router-link>-->
        <!--</div>-->

  <div class="mode-list" :class="{'Proprietary_mode-left' : index % 2 !== 0}">
  <router-link :to="{path:'/ProductDetails/'+path}">
      <div class="Proprietary_box">

          <div class="Proprietary_box_left">
            <img v-lazy="imgBaseUrl+imgUrl" onerror="defaultImg"/>
          </div>
          <div class="Proprietary_box_right">
            <p >{{goodsName}}</p>


            <div class="Proprietary_box_right_div">
              <b>￥{{price}}</b>
              <span>销量：{{salesVolume}}</span>
            </div>
          </div>

      </div>
  </router-link>
  </div>

</template>


<script>
	export default {
		props:{
			path:'',
      imgUrl:'',
      goodsName:'',
      price:'',
      salesVolume:"",
      index:''
    },
    data(){
      return{
        defaultImg: 'this.src="' + require('../../assets/images/login&register/login_03.png') + '"'
      }
    }

  }
</script>

<style scoped>
  .mode-list{width: 100%;background: #fff}
  .Proprietary_mode-list{padding: .1rem .4rem;}
  .Proprietary_box{width: 100%;background: #f8f8f8;font-size: 0.55rem;}
  .Proprietary_box_left{width: 30%;float: left;padding-left: .4rem}
  .Proprietary_box_left img{width: 100px;height: 100px !important;}
  .Proprietary_box_right{float: left;width: 60%;padding: .4rem 0 .4rem .2rem;}
  .Proprietary_box_right_div{width: 100%;}
  .Proprietary_box_right p{;margin-bottom: .5rem;}
  .Proprietary_box_right_div b{width: 40%;color: #e50039;font-weight: 600;}
  .Proprietary_box_right_div span{width: 40%;float: right;color: #999}

</style>

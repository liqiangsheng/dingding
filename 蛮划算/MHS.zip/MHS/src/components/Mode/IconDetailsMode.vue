<template>

        <div class="mode-list" :class="{'mode-left' : index % 2 !== 0}">
          <router-link :to="{path:'/ProductDetails/'+path}">
            <div class="mode-img" >
              <img v-lazy="imgBaseUrl+imgUrl" @onerror="imgError(item)"/>
            </div>
            <!--<div class="mode-dp">{{ item.SaleComment }}</div>-->
            <div class="mode-title">{{ goodsName }}</div>
            <div class="mode-price2">
              <span class="tex">
               <b>￥{{ appPrice }}元</b>
                <!--<span>{{positiveRate}}</span>-->
                <!--<span class="integral">赠送{{productCPSDiscount}}积分</span>-->
              </span>
              <div class="tex_bootn">
                <span class="texSpan">0条评论</span>
                <span class="texSpan">{{positiveRate}}%好评</span>
              </div>
              <!--<span class="mode-btn" :to="{path:'/ProductDetails/'+path}">立即购买</span>-->
            </div>
          </router-link>
        </div>

</template>

<script>
	export default {
		props:{
			path:'',
      goodsId:'',
      imgUrl:'',
      goodsName:'',
      appPrice:'',
      positiveRate:'',
      commentNumber:'',
      index:''
    },
    data(){
		  return{
        errorImg01:'http://pic.yupoo.com/zooron/31c734c4/ea45a2e2.jpg'
      }
    },
    mounted () {

    },

    methods:{
      imgError(){
        alert(1111)
      }
    }
	}
</script>

<style scoped>
  .mode-list{background: #fff}
  .tex{color: #e70039;font-weight: 600;font-size: 0.65rem}
  .texSpan{font-size: 0.55rem}
  .mode-title{font-size: 0.55rem}
  /*.mode-img img{width: 190px;height: 190px}*/
  .tex_bootn{display: flex;padding: .2rem;color: #b2b2b2}
  .tex_bootn span{flex: 1}
  .integral{font-size: 0.4rem;color: #feba4d;display: inline-block;border:1px solid #feba4d;border-radius: .4rem;padding: .1rem;font-weight: 100;margin-left: .4rem}
</style>

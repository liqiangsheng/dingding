<template>

        <div class="mode-list" :class="{'mode-left' : index % 2 !== 0}">
          <router-link :to="{path:'/ProductDetails/'+path}">
            <div class="mode-img">
              <img v-lazy="imgBaseUrl+imgSrc"/>
            </div>
            <!--<div class="mode-dp">{{ item.SaleComment }}</div>-->
            <div class="mode-title">{{ productName }}</div>
            <div class="mode-price">
              <span class="tex">
               <b>￥{{ productPrice }}元</b>
                <span class="integral_mode">赠送{{productCPSDiscount}}积分</span>
              </span>
              <span></span>
              <!--<span class="mode-btn" :to="{path:'/ProductDetails/'+path}">立即购买</span>-->
            </div>
          </router-link>
        </div>

</template>

<script>
	export default {
		props:{
			path:'',
      imgSrc:'',
      productName:'',
      productPrice:'',
      productCPSDiscount:'',
      index:''
    }
  }
</script>

<style scoped>
  .mode-list{background: #fff}
  .tex{color: #e70039;font-weight: 600}
  .mode-title{font-size: 0.55rem}
  .integral_mode{
    font-size: 0.4rem;color: #feba4d;display: inline-block;border:1px solid #feba4d;
    border-radius: .4rem;padding: .1rem;font-weight: 100;margin-left: .4rem}
</style>

<template>
  <div class="mode-Producty" :class="{'mode-left_Producty' : index % 2 !== 0}">
    <!--<router-link :to="{path:'/productDetails/'+path}">-->
    <div @click="one(target)">
      <div class="mode-Producty_txt">
        <b>{{activityName}}</b>
        <span>{{activitySubhead}}</span>
      </div>
      <div class="mode-img_Producty">
        <img v-lazy="imgBaseUrl+activityImg"/>
      </div>
    </div>



    <!--</router-link>-->
  </div>

</template>

<script>
  import { Toast } from 'mint-ui'
  export default {
    props:{
      target:'',
      path:'',
      activityImg:'',
      img:'',
      activityName:'',
      activitySubhead:'',
      index:''
    },
    data() {
      return {
        tagId:'',

      }
    },
    methods:{
      one(target){
        console.log(target.uri,'target')
        if(target.uri=='score_trans_gift'||target.uri=='goods_to_goods'){
          Toast("敬请期待")
        }else{
          console.log(target.params,'target.params')
          sessionStorage.setItem("target", JSON.stringify(target.params));
          this.$router.push({
            path: '/IconDetails',
          })
        }

      }

    }
  }
</script>
<style scoped>
  .mode-Producty{width:50%;border: 1px solid #efefef;border-bottom: none;padding: .4rem;background: #fff}
  .mode-left_Producty{width: 50%;border-top: 1px solid #efefef;border-left:none;padding-left: .3rem}
  .mode-img_lProducty{width: 90%;margin: 0 auto}
  .mode-img_Producty img{width:50%;float: right;margin-right: .8rem}
  .mode-Producty_txt b{font-size: 0.65rem;display: block;font-weight: 600}
  .mode-Producty_txt span{font-size: 0.55rem;color: #999;}

</style>
